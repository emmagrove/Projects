let data;
let isReady = false;
let isPlayRequested = false;
$(document).ready(function () {
	const tmdbID = window.location.href.split("/").pop().match(/\d+/g).join("");
	var apiData;
	// REQUEST AND SHOW MOVIE DATA WITH TMDBID
	$.ajax({
		url: "https://api.themoviedb.org/3/movie/" + tmdbID + "?api_key=e47a385fbe50d749ea94bcb4ef1e0fe9&language=en-US",
		type: "GET",
		dataType: "JSON",
		beforeSend: function () {
			console.log("Page not ready yet");
		},
		success: function (tmdbResult) {
			var title = tmdbResult["title"];
			var year = tmdbResult["release_date"].split("-")[0];
			var posterPath = tmdbResult["poster_path"];
			var backdropPath = tmdbResult["backdrop_path"];
			var overview = tmdbResult["overview"];
			var genres = tmdbResult.genres.map((genre) => genre.name);

			$(".title").text(title);
			$(".year").text(year);
			$(".poster .ratio-img").attr("src", "https://www.themoviedb.org/t/p/w400" + posterPath);
			$(".backdrop .ratio-img").attr("src", "https://www.themoviedb.org/t/p/w1280" + backdropPath);
			$(".overview").text(overview);

			for (var i = 0; i < Math.min(genres.length, 4); i++) {
				var span = $("<span></span>").text(genres[i]);
				$(".genres").append(span);
			}

			/* Matching and getting the movie APIMOVIEID from the api */
			$.ajax({
				url: "https://fliiixv2.vercel.app/movies/flixhq/" + title,
				dataType: "json",
				success: function (apiSearchResult) {
					// Once both sets of data are available, compare and match the movies
					var grabbedMovie = [];
					for (var i = 0; i < apiSearchResult.results.length; i++) {
						var loopedApiSearchResult = apiSearchResult.results[i];
						// Compare the movie titles and release years to see if they match
						if (loopedApiSearchResult.title === tmdbResult.title && loopedApiSearchResult.releaseDate === tmdbResult.release_date.slice(0, 4)) {
							grabbedMovie.push(loopedApiSearchResult);
							break;
						}
					}

					/* Getting movie apiData with the APIMOVIEID */
					var apiMovieID = grabbedMovie[0].id;
					$.ajax({
						url: "https://fliiixv2.vercel.app/movies/flixhq/watch?episodeId=" + apiMovieID.split("-").pop() + "&mediaId=" + apiMovieID,
						dataType: "json",
						success: function (apiStreamingLinks) {
							console.log("Streaming Links Here");
							apiData = apiStreamingLinks;
							isReady = true;
							isPlayRequested && loadPlayer();
						},
					});
				},
			});
		},
		complete: function () {
			console.log("Page ready");
		},
	});

	// Load Player
	$("#play-movie").on("click", function () {
		loadPlayer();
	});
	// Load Player Function
	function loadPlayer() {
		// console.log(JSON.stringify(naiveSubtitlesListFormatter(apiData)));
		if (!isReady) {
			$("#videoBeingLoaded").css("display", "flex").fadeIn(300);
			console.log("Not Ready");
			isPlayRequested = true;
			return;
		}
		$("#videoBeingLoaded").fadeOut(300);
		$.get("player/index.html", function (player) {
			document.open();
			document.write(player);
			document.close();
			/* Page is Player Now */

			// process apiData
			data = {
				sources: apiData.sources.map((source) => ({
					url: source.url,
					quality: source.quality,
				})),
				subtitles: naiveSubtitlesListFormatter(apiData),
			};

			// add quality list to html
			var sources = data.sources;
			for (let i = 0; i < sources.length; i++) {
				var quality = sources[i].quality;
				if (quality === "auto") {
					continue; // skip adding span for "auto" quality
				}
				$(".quality-list").append(`<p class="quality-option" quality="${quality}">${quality}</p>`);
			}

			// add subtitles list to html
			data.subtitles.forEach((subtitle) => {
				const subUrl = subtitle.url;
				const subLang = subtitle.lang;
				$(".cc-list").append(`<p class="cc-option" language="${subLang}">${subLang}</p>`);
			});

			// apply JS
			var script = document.createElement("script");
			script.src = "../player/player.js";
			document.head.appendChild(script);
		});
	}
});

//  This function is just some bulshit work to add a number to the duplicate subtitle language
function naiveSubtitlesListFormatter(apiData) {
	let subsObj = {};
	// {English: 2, Arabic: 2, French: 1}
	apiData.subtitles.forEach((sub) => {
		let subLanguage = sub.lang.split(" ")[0];
		subsObj[subLanguage] = (subsObj[subLanguage] || 0) + 1;
	});
	// {English: 0, Arabic: 0}
	for (let sub in subsObj) {
		if (subsObj.hasOwnProperty(sub) && subsObj[sub] === 1) {
			delete subsObj[sub];
		} else {
			subsObj[sub] = 0;
		}
	}

	let data = apiData.subtitles.map((sub) => {
		let subLanguage = sub.lang.split(" ")[0];
		if (subsObj[subLanguage] !== undefined) {
			subsObj[subLanguage]++;
			return {
				url: sub.url,
				lang: subLanguage + " " + subsObj[subLanguage],
			};
		} else {
			return {
				url: sub.url,
				lang: subLanguage,
			};
		}
	});
	return data;
}
