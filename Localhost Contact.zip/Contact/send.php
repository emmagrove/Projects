<?php
require 'PHPMailerAutoload.php';

if (isset($_POST['btn'])) {
	$mail = new PHPMailer;
	$fn = $_POST['fn'];
	$email = $_POST['email'];
	$msg = htmlspecialchars($_POST['msg']);
	$msg0 = str_replace("\n", "<br>", $msg);
	$message = "
	<h2>New Registration</h2>
	<br>
	<br>
	<b>Full Name: $fn</b>
	<br>
	<b>Email: $email</b>
	<br><br>
	<p>Message: $msg0</b>";

	//$mail->SMTPDebug = 3;                               // Enable verbose debug output

	$mail->isSMTP();                                      // Set mailer to use SMTP
	$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
	$mail->SMTPAuth = true;                               // Enable SMTP authentication
	$mail->Username = 'nocxsploit@gmail.com';                 // SMTP username
	$mail->Password = 'medyac2002';                           // SMTP password
	$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
	$mail->Port = 587;                                    // TCP port to connect to

	$mail->setFrom($email, $fn);
	$mail->addAddress('mohammedyacouty@gmail.com');     // Add a recipient

	$mail->isHTML(true);                                  // Set email format to HTML

	$mail->Subject = "IZA BULLETIN FEBRUARY 2020";
	$mail->Body    = $message;

	if(!$mail->send()) {
	    echo 'Message could not be sent.';
	    echo 'Mailer Error: ' . $mail->ErrorInfo;
	    //header("Location: index.php");
	} else {
	    echo 'Message has been sent';
	    //header("Location: index.php");
	}
}