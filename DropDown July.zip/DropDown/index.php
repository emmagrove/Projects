<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>DropDown</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&family=Open+Sans:wght@300;400;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/normalize.css">
	<script type="text/javascript" src="assets/js/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="assets/js/index.js"></script>
</head>
<body>

<div id="container">
	<div class="dd-head" data-click-state="0">
		<h2>Choose</h2>
		<img src="assets/img/chevron-down.svg" alt="">
	</div>
	<div class="dd-details">
		<p>Option 1</p>
		<p>Option 2</p>
		<p>Option 3</p>
		<p>Option 4</p>
		<p>Option 5</p>
		<p>Option 6</p>
		<p>Option 7</p>
	</div>
	<input type="hidden" name="dd-result" id="dd-result">
</div>

</body>
</html>