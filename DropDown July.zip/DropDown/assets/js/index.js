$(document).ready(function(){


$('.dd-head').on('click',function(){
	if($(this).attr('data-click-state') == 0) {
		$(this).attr('data-click-state', 1);
		$('.dd-details').addClass('dd-active');
	}else{
		$(this).attr('data-click-state', 0);
		$('.dd-details').removeClass('dd-active');
	}
});

$('.dd-details p').on('click',function(){
	var text = $(this).text();
	var value = text.replace(/\s+/g, '');
	$('.dd-head h2').text(text);
	$('#dd-result').attr('value', value);
	$('.dd-head').attr('data-click-state', 0);
	$('.dd-details').removeClass('dd-active');
});


});