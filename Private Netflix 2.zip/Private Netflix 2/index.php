<?php


if (isset($_GET["search"])) {


$keyword = rawurlencode($_GET["search"]);

function scrape($keyword){
	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, 'https://movs.to/en/quick-search?q=' . $keyword);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

	$result = curl_exec($ch);

	preg_match_all('/<a class="link-black" href=".*?">(.*?)<\/a>/', $result, $dataTitle);
	preg_match_all('/<img class="post-minimal-image" src="(.*?) alt=/', $result, $dataPoster);
	preg_match_all('/<a class="link-black" href="\/en\/movie\/(.*?)\//', $result, $dataLink);

	curl_close($ch);

	$count = count($dataTitle[1]);

	for ($i=0; $i < $count; $i++) { 
		$dataPoster1[] = end(explode("/", $dataPoster[1][$i]));
	}

	return array($count, $dataTitle[1], $dataPoster1, $dataLink[1]);
}

list($count, $dataTitle, $dataPoster, $dataLink) = scrape($keyword);


$bigData = "";
for ($i=0; $i < $count; $i++) { 
	$bigData .= '<a href="watch/index.php?q=' . $dataLink[$i] . '"><div><img src="https://image.tmdb.org/t/p/w300/' . $dataPoster[$i] . '" alt=""></div></a>';
}


}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Private Netflix</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<link href="https://fonts.googleapis.com/css2?familyfamily=Open+Sans:wght@300;400;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/normalize.css">
	<script type="text/javascript" src="assets/js/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="assets/js/index.js"></script>
</head>
<body>

<img src="assets/img/logo.svg" class="logo" alt="">
<form action="" method="GET">
	<input type="text" class="search" id="search" name="search" placeholder="Search">
</form>

<div class="movies">

<?php

if ($bigData) {
	echo $bigData;
}else{
	echo '	<a href="#"><div>
		<img src="posters/v.jpg" alt="">
	</div></a>
	<a href="#"><div>
		<img src="posters/b.jpg" alt="">
	</div></a>
	<a href="#"><div>
		<img src="posters/m.jpg" alt="">
	</div></a>
	<a href="#"><div>
		<img src="posters/p.jpg" alt="">
	</div></a>
	<a href="#"><div>
		<img src="posters/c.jpg" alt="">
	</div></a>
	<a href="#"><div>
		<img src="posters/k.jpg" alt="">
	</div></a>';
}

?>

</div>

</body>
</html>