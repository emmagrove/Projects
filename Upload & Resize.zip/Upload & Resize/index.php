<?php

if (isset($_POST["upload"])) {
	if (isset($_FILES["pic"]) && $_FILES['pic']['size'] > 0) {

		$pic_name = $_FILES["pic"]["name"];
		$pic_size = $_FILES["pic"]["size"];
		$pic_tmp = $_FILES["pic"]["tmp_name"];
		$pic_type = $_FILES["pic"]["type"];
		$pic_ext = strtolower(end(explode(".", $pic_name)));

		$allowed_ext = array("jpeg","jpg","png");

		if (in_array($pic_ext, $allowed_ext)){
			if($pic_size < 2097152){

					$pic = rand(1000,9999).".".$pic_ext;
					list($pic_width, $pic_height, $pic_type) = getimagesize($pic_tmp);

					$new_width = 100;
					$new_height = ($pic_height / $pic_width) * $new_width;
					$new_pic_tmp = imagecreatetruecolor($new_width, $new_height);

					if($pic_type == IMAGETYPE_JPEG) {
						$pic_src = imagecreatefromjpeg($pic_tmp);
					}
					elseif($pic_type == IMAGETYPE_PNG) {
						$pic_src = imagecreatefrompng($pic_tmp);
					}

					imagecopyresampled($new_pic_tmp, $pic_src, 0, 0, 0, 0, $new_width, $new_height, $pic_width, $pic_height);

					$original_pic = move_uploaded_file($pic_tmp, "Original/".$pic);
					$thumb_pic = imagejpeg($new_pic_tmp, "Thumb/".$pic, 100);

					if ($original_pic && $thumb_pic) {
						echo "Image Uploaded Successfully";
					}else{
						echo "An Error Occured";
					}

			}
		}

	}
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Upload</title>
</head>
<body>

<form action="" method="POST" enctype="multipart/form-data">
	<input type="file" name="pic"><br>
	<button name="upload">Upload</button>
</form>

</body>
</html>