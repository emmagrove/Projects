$(document).ready(function(){


$('#dd_default').on('click',function(){
	if($(this).attr('data-click-state') == 0) {
		$(this).attr('data-click-state', 1);
		$("#dd_products").addClass("dd_active");
	}else{
		$(this).attr('data-click-state', 0);
		$("#dd_products").removeClass("dd_active");
	}
});

$('*#dd_list').on('click',function(){
	var text = $(this).text();
	var value = $(this).attr("value");
	$("#dd_title").text(text);
	$("#dd_title").attr('value', value);
	$("#category").attr('value', value);
	$("#dd_default").attr('data-click-state', 0);
	$("#dd_products").removeClass("dd_active");
});


});