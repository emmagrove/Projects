<?php

if ($_POST["btn"]) {

	$result = "";

	$keyword = $_POST["keyword"];
	$from = $_POST["from"];
	$to = $_POST["to"];

	for ($i=$from; $i <= $to; $i++) {
		$gen = $keyword . $i;
		$result .= $gen . "<br>";
	}

}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Password Generator</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&family=Poppins:wght@200;300;400&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/normalize.css">
	<script type="text/javascript" src="assets/js/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="assets/js/index.js"></script>
</head>
<body>

<form action="" method="POST">
	<div id="container">
		<h1 id="title">Password Generator</h1>
		<input type="text" name="keyword" id="keyword" placeholder="Enter your keyword">
		<input type="text" name="from" id="keyword" placeholder="Enter the beginning of the count">
		<input type="text" name="to" id="keyword" placeholder="Enter the end of the count">
		<button name="btn" value="submit" id="btn">GENERATE</button>

		<div id="result"><?php echo $result; ?></div>

	</div>
</form>

</body>
</html>