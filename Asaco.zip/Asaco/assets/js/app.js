$(document).ready(function(){

// BURGER
$('.burger').on('click', function(){
	$(this).toggleClass('open');
	$('.sidebar').toggleClass('sidebar-active')
});


});