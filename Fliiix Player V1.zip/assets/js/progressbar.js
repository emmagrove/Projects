// $(document).ready(function(){

    
// $('.progress-thumb').on('input', function(){
// 	var progressThumbTotal = $(this).attr("max");
// 	var progressThumbValue = $(this).val();
// 	/* CHANGE PLAYED PROGRESS */
// 	var progressPlayed = (progressThumbValue / progressThumbTotal) * 100;
// 	$('.progress-played').css("width", progressPlayed + "%");
// });


// $('.progress-thumb').on('mousemove', function(){
// 	var rangeValue = $(this).val();
// 	console.log(rangeValue);
// });
	
// });