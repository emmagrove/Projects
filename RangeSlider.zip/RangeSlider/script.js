console.clear()

$("#range").on("mouseenter mousemove click mouseleave", function(event) {

  // Get the slider's params
  let maxValue = parseInt(event.target.getAttribute('max'))
  let sliderWidth = event.target.clientWidth

  // That is the key value causing offsets in calculations
  let thumbWidth = 16

  // I made a named function just to have the calculation logic apart from the rest.
  let thumbCorrection = getOffsetXcorrection(event.offsetX, sliderWidth, thumbWidth)

  // Using that "thumb correction" in the basic intuitive calculation anyone would expect
  let clickedKnotch = (event.offsetX-thumbCorrection) / sliderWidth
  
  
  // The demo outputs
  var calculatedValue = Math.round(clickedKnotch * maxValue)
  let realValue = $(this).val()
  let difference = calculatedValue - realValue
  let errorPercentage = Math.abs((difference / maxValue) *100)

  // Limit the calculated value inside min and max
  calculatedValue = (calculatedValue>maxValue) ? maxValue : (calculatedValue<0) ? 0 : calculatedValue
  $(".calculated").text("Calculated: " + calculatedValue)
  
  if(event.type==="click"){
    $(".real").text("Real: " + realValue)
    $(".difference").text("Diff: " + difference)
    $(".percentage").text(errorPercentage.toFixed(2) + "%")
    
    // Remove the inactive class
    $(".tooltip").removeClass("inactive")
  }
  
  if(event.type==="mouseenter"){
    $(".tooltip").addClass("inactive")
    $(".calculated").removeClass("inactive")
  }
  
  if(event.type==="mouseleave"){
    $(".tooltip").removeClass("inactive")
    $(".calculated").addClass("inactive")
  }
});


function getOffsetXcorrection(clickedPosition, fullWidth, thumbWidth) {
  
  // The middle is the 0% correction point
  let middle = fullWidth/2
  
  // The "error" always is about half the thumb width
  let halfThumbWidth = thumbWidth/2
  
  // So where occured the click in that context?
  let percentageFromMiddle = (middle - clickedPosition) / middle
  
  // Return the correction about the click position to use in a "linear" calculation
  let correction = percentageFromMiddle * halfThumbWidth
  return Math.round(correction)
}