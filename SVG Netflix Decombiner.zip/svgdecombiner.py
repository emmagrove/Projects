import html5lib
from bs4 import BeautifulSoup as soup

with open("icons.svg", "r") as f:
	svgContent = f.read()

spiritsoup = soup(svgContent, 'html5lib')


symbols = spiritsoup.findAll("symbol")


for symbol in symbols:
    symbolID = symbol["id"].replace("nfplayer", "")
    symbolContent = ""
    for child in list(symbol.descendants):
        symbolContent += str(child).strip()
    with open(f"Icons/{symbolID}.svg", "w") as f:
        svgContent = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28">' + symbolContent + '</svg>'
        f.write(svgContent)