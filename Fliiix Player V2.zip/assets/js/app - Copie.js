$(document).ready(function(){

/*
** INITIALIZE VIDEO
*/
const video = document.querySelector('video');
const flxplayer = $('.flxplayer')[0];


/*
** GLOBAL USED FUNCTIONS
*/

// FUNCTION TO FORMAT TIME TO HH:MM:SS
function hhmmss(seconds){
	var hours = Math.floor(seconds / 3600);
	var minutes = Math.floor( (seconds - (hours * 3600)) / 60 );
	var seconds = Math.floor( seconds - ((hours * 3600) + (minutes * 60)) );

	if (minutes < 10) minutes = '0' + minutes;
	if (seconds < 10) seconds = '0' + seconds;

    if (!hours) {
    	if (minutes == '00') {
    		return '0:' + seconds;
    	}else{
    		return minutes.toString().replace(/^0+/, '') + ':' + seconds;
    	}
    }else{
    	return hours.toString().replace(/^0+/, '') + ':' + minutes + ':' + seconds;
    }

}

// FUNCTION TO OPEN FULLSCREEN MODE
function openFullscreen() {
	if (flxplayer.requestFullscreen) {
		flxplayer.requestFullscreen();
	}else if (flxplayer.mozRequestFullScreen) { /* Firefox */
		flxplayer.mozRequestFullScreen();
	}else if (flxplayer.webkitRequestFullscreen) { /* Chrome, Safari & Opera */
		flxplayer.webkitRequestFullscreen();
	}else if (flxplayer.msRequestFullscreen) { /* IE/Edge */
		flxplayer = window.top.flxplayer.body; //To break out of frame in IE
		flxplayer.msRequestFullscreen();
	}
}
// FUNCTION TO CLOSE FULLSCREEN MODE
function closeFullscreen() {
	if (document.exitFullscreen) {
		document.exitFullscreen();
	}else if (document.mozCancelFullScreen) {
		document.mozCancelFullScreen();
	}else if (document.webkitExitFullscreen) {
		document.webkitExitFullscreen();
	} else if (document.msExitFullscreen) {
		window.top.document.msExitFullscreen();
	}
}
function getOffsetXcorrection(clickedPosition, fullWidth, thumbWidth) {
  
  // The middle is the 0% correction point
  let middle = fullWidth/2
  
  // The "error" always is about half the thumb width
  let halfThumbWidth = thumbWidth/2
  
  // So where occured the click in that context?
  let percentageFromMiddle = (middle - clickedPosition) / middle
  
  // Return the correction about the click position to use in a "linear" calculation
  let correction = percentageFromMiddle * halfThumbWidth
  return Math.round(correction)
}


/*
** CHANGE THE TOTAL VIDEO DURATION HH:MM:SS
** CHANGE THE PROGRESS BAR MAX VALUE
*/
$('video').on('loadedmetadata', function() {
	const videoDuration = Math.round(video.duration);
	const videoDurationFormated = hhmmss(videoDuration);

	$('.video-duration').text(videoDurationFormated)
	$('.progress-thumb').attr('max', videoDuration);
});


/*
** PROGRESS BAR
*/
// APPLY CHANGES ON TIME UPDATE
$('video').on('timeupdate', function(e) {
	const videoDuration = Math.round(video.duration);
	const currentTime = Math.round(video.currentTime);
	const playedProgress = (currentTime / videoDuration) * 100;
	// CHANGE PLAYED PROGRESS
	$('.progress-thumb').css("background", `linear-gradient(to right, #e50914 0%, #e50914 ${playedProgress}%, transparent ${playedProgress}%, transparent 100%)`);
	// CHANGE THUMB POSITION BY CHANGING ITS VALUE
	$('.progress-thumb').val(currentTime);

});
// APPLY CHANGES ON VIDEO RANGE INPUT
$('#videoRange').on('input', function(e) {
	console.log(hhmmss($(this).val()))
	if ($(this).attr('skipto')) {
		var currentTime = parseInt($(this).attr('skipto'));
	}else{
		var currentTime = $(this).val();
	}
	const videoDuration = Math.round(video.duration);
	const playedProgress = (currentTime / videoDuration) * 100;
	// CHANGE PLAYED PROGRESS
	$('.progress-thumb').css("background", `linear-gradient(to right, #e50914 0%, #e50914 ${playedProgress}%, transparent ${playedProgress}%, transparent 100%)`);
	// CHANGE CURRENT TIME TO THE TIME CHOOSED
	video.currentTime = currentTime;
});
// SHOW TOOLTIP ON MOUSEMOVE
$('#videoRange').on('mousemove', function(e) {
	const videoDuration = Math.round(video.duration);
	var tooltipHalfWidth = $('.tooltip').outerWidth() / 2;
	// try to calculate the video time based on the cursor position
	var calcCurrentTime = Math.round((e.offsetX / $(this).width()) * videoDuration);
	// set the calculated time in seconds to skipto attr
	$(this).attr("skipto", calcCurrentTime);
	// update tooltip text
	$('.tp-text').text(hhmmss(calcCurrentTime));
	// calculate the left percentage
	var calcTooltipLeftPercentage = (calcCurrentTime / videoDuration) * 100;
	// change played progress
	$('.tooltip').css("left", `calc(${calcTooltipLeftPercentage}% - ${tooltipHalfWidth}px)`);
});




/*
** PLAY & PAUSE THE VIDEO
** IF THE VIDEO IS PLAYING PAUSE IT VICE VERSA
*/
var isPlaying = false;
$('.cn-play-pause').on('click', function(){
	if (!isPlaying) {
		video.play();
		$(".playBtn, .pauseBtn").toggleClass("hideThisControl");
		isPlaying = true;
	}else{
		video.pause();
		$(".playBtn, .pauseBtn").toggleClass("hideThisControl");
		isPlaying = false;
	}
});


/*
** REWIND THE VIDEO 10 SECONDS
*/
$('.rewindBtn').on('click', function(){
	video.currentTime -= 10;
});
/*
** FORWARD THE VIDEO 10 SECONDS
*/
$('.forwardBtn').on('click', function(){
	video.currentTime += 10;
});


/*
** FULLSCREEN & LOWSCREEN THE VIDEO
** IF LOWSCREEN THEN FULLSCREEN IT VICE VERSA
*/
// TOGGLE FULLSCREEN MODE
var isFullscreen = false;
$('.cn-fullscreen-lowscreen').on('click', function(){
	if (!isFullscreen) {
		openFullscreen();
	}else{
		closeFullscreen();
	}
});
// TOGGLE FULLSCREEN ICON & BOOLEAN VALUE
$(document).on('fullscreenchange mozfullscreenchange webkitfullscreenchange msfullscreenchange', function(){
	isFullscreen = !isFullscreen;
	$(".fullscreenBtn, .lowscreenBtn").toggleClass("hideThisControl");
});



});