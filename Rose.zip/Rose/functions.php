<?php

/*
* ADD THEME SUPPORT
*/
add_theme_support('menus');


/*
* REGISTER A NEW NAVIGATION MENU - NAVBAR
*/
function navbar() {
	register_nav_menu('navbar', __( 'Navigation Bar' ));
}
add_action('init', 'navbar');


/*
* ENQUEUE STYLES AND SCRIPTS
*/
function my_assets() {
    wp_enqueue_style('normalize-css', get_template_directory_uri() . '/assets/css/normalize.css');
    wp_enqueue_style('poppins', 'https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&family=Poppins:wght@300;400;500;600&display=swap');
    wp_enqueue_style('style-css', get_stylesheet_uri());
    wp_enqueue_script('jquery-js', get_template_directory_uri() . '/assets/js/jquery-3.5.1.min.js', array(), false, true);
    wp_enqueue_script('main-js', get_template_directory_uri() . '/assets/js/main.js', array(), false, true);
}
add_action('wp_enqueue_scripts', 'my_assets');


?>
