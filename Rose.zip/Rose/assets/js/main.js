$(document).ready(function(){

// ACTIVATE SEARCH SECTION
$('#searchBtn').on('click', function(){
	$('body').css('overflow', 'hidden');
	$('.search-section').addClass('active');
});
// DEACTIVATE SEARCH SECTION
$('#searchClose').on('click', function(){
	$('body').css('overflow', 'auto');
	$('.search-section').removeClass('active');
});

});