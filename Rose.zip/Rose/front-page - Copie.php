<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Rose</title>
	<link rel="icon" type="image/png" href="https://img.icons8.com/fluent/344/bunch-flowers.png">
	<?php wp_head();  ?>
</head>
<body>

<div class="topnav">
	<div class="topnav-links">
		<ul>
			<li class="topnav-link"><a href="#"></a>Home</li>
			<li class="topnav-link"><a href="#"></a>ABOUT</li>
			<li class="topnav-link"><a href="#"></a>CONTACT US</li>
		</ul>
	</div>
	<div class="topnav-socials">
		<svg class="topnav-social"><use xlink:href="<?php echo get_template_directory_uri() ?>/assets/img/social.svg#instagram"></use></svg>
		<svg class="topnav-social"><use xlink:href="<?php echo get_template_directory_uri() ?>/assets/img/social.svg#twitter"></use></svg>
		<svg class="topnav-social"><use xlink:href="<?php echo get_template_directory_uri() ?>/assets/img/social.svg#facebook"></use></svg>
		<svg class="topnav-social"><use xlink:href="<?php echo get_template_directory_uri() ?>/assets/img/social.svg#pinterest"></use></svg>
	</div>
</div>

<div class="headerLogo">
	<img src="<?php echo get_template_directory_uri() ?>/assets/img/maverick.png" alt="">
</div>

<nav class="navbar">
	<div class="navbar-container">
		<?php
		wp_nav_menu( array('theme_location' => 'navbar' ) ); 
		?>
		<div class="navbar-search">
			<div class="search-left-border"></div>
			<img src="<?php echo get_template_directory_uri() ?>/assets/img/search.svg" id="searchBtn" alt="">
		</div>
	</div>
</nav>

<div class="search-section">
	<img src="<?php echo get_template_directory_uri() ?>/assets/img/close.svg" id="searchClose" alt="">
	<div>
		<img src="<?php echo get_template_directory_uri() ?>/assets/img/search.svg" alt="">
		<input type="text" name="search" placeholder="Search">
	</div>
</div>

	

<?php wp_footer();  ?>
</body>
</html>