$(document).ready(function(){


// HIDE THE NATIVE CONTROLS
const video = document.getElementById('video');
const videoControls = document.getElementById('nayer-controls');

const videoWorks = !!document.createElement('video').canPlayType;
if (videoWorks) {
  video.controls = false;
  videoControls.classList.remove('nayer-hide');
  $('#nayer-controls').show();
}

// TOGGLE CONTROLS STATE
function toggleControl(thiiis){
	$(thiiis).addClass('nayer-hide');
	$(thiiis).siblings().removeClass('nayer-hide');
}

/* PLAYBACK ANIMATION */
function animatePlayback() {
 	$('#playback-animation')[0].animate([{opacity: 1, transform: "scale(1)"}, {opacity: 0, transform: "scale(1.4)"}], {duration: 500});
}

// HIDE THE CONTROLS WHEN NO ACTION
var timeout = null;
$('#nayer').on('mousemove', function() {
	clearTimeout(timeout);
	if($(".video-progress:hover , .control-section:hover").length != 0){
		return;
	}
	$(this).addClass('cursor-pointer');
    $('#nayer-controls').fadeIn(200);
	timeout = setTimeout(function() {
        $('#nayer').removeClass('cursor-pointer');
    	$('#nayer-controls').fadeOut(200);
    }, 2000);
}).mouseleave(function() {
    $('#nayer-controls').fadeOut(200);
});

// EDIT SUBTITLES LINE
function subLine(){
	video.textTracks[0].mode = 'showing';
	video.textTracks[1].mode = 'showing';
	var tracks = video.textTracks;
	setTimeout(function() {
		for (var j = 0; j < tracks.length; j++) {
			var track = tracks[j];
			var cues = track.cues;
			for (var i = 0; i < cues.length; i++) {
				cues[i].line = -2;
			}
		}
	}, 500);
	video.textTracks[1].mode = 'hidden';
}


// TOTAL VIDEO DURATION
var tvd;
$('#video').on('loadedmetadata', function() {

	video.textTracks[0].mode = 'showing';
	video.textTracks[1].mode = 'showing';

	const videoDuration = Math.round(video.duration);

	if (videoDuration <= 3599) {
		tvd = new Date(videoDuration * 1000).toISOString().substr(14, 5);
		$('#duration').text(tvd);
	}else{
		tvd = new Date(videoDuration * 1000).toISOString().substr(11, 8);
		$('#duration').text(tvd);
	}

	$('#progress-range , #progress-bar').attr('max', videoDuration);



	var tracks = video.textTracks;
	setTimeout(function() {
		for (var j = 0; j < tracks.length; j++) {
			var track = tracks[j];
			var cues = track.cues;
			for (var i = 0; i < cues.length; i++) {
				cues[i].line = -2;
			}
		}
	}, 500);
	video.textTracks[1].mode = 'hidden';

});

// REMAINING TIME
$('#video').on('timeupdate', function() {
	const videoDuration = Math.round(video.duration);
	const currentTime = Math.round(video.currentTime);
	const remainingTimeSecond = Math.round(videoDuration - currentTime);

	// PROGRESS BAR
	$('#progress-range').val(currentTime);
	$('#progress-bar').val(currentTime);

	if (remainingTimeSecond <= 3599) {
		var remainingTime = new Date(remainingTimeSecond * 1000).toISOString().substr(14, 5);
		$('#duration').text(remainingTime);
	}else{
		var remainingTime = new Date(remainingTimeSecond * 1000).toISOString().substr(11, 8);
		$('#duration').text(remainingTime);
	}

});

// TOGGLE THE PLAYBACK STATE
function playPause(){
	if (video.paused || video.ended) {
		video.play();
		toggleControl('#play , #pause-animation');
	} else {
		video.pause();
		toggleControl('#pause , #play-animation');
	}
	animatePlayback();
}
$('.play-pause').on('click', function() {
	playPause();
});

$('#video').on('ended', function() {
	$('#pause').addClass('nayer-hide');
	$('#play').removeClass('nayer-hide');
});

// REWIND 10s
$('#rewind').on('click', function() {
	var rewindedTime = Math.round(video.currentTime - 10);
	video.currentTime = rewindedTime;
});

// FORWARD 10s
$('#forward').on('click', function() {
	var forwardedTime = Math.round(video.currentTime + 10);
	video.currentTime = forwardedTime;

});



// VOLUME
var soundTimeout = null;
$('#sound').hover(function(){

	soundTimeout = setTimeout(function() {
		$('.video-progress').fadeOut(200);
		if ($('#volume-section').is(":hidden") == true) {
			$('#volume-section').css("display", "flex").hide().fadeIn(200);
		}
	}, 300);

}, function(){

	if ( $('#volume-section').is(":hover") == false ) {
		$('#volume-section').fadeOut(200);
		$('.video-progress').css("display", "flex").hide().fadeIn(200);
	}else{
		$('#volume-section').hover(function(){}, function(){
			if ($('#sound').is(":hover") == false) {
				$('#volume-section').fadeOut(200);
				$('.video-progress').css("display", "flex").hide().fadeIn(200);
			}
		});
	}
	clearTimeout(soundTimeout);
});



// VOLUME CONTROLS
/* CHANGE VIDEO VOLUME */
$('#volume').on('input', function() {
	var volumeValue = parseInt( $(this).val() * 100);
	$(this).css("background", "linear-gradient(to right, #e50914 0%, #e50914 "+volumeValue+"%, #5b5b5b "+volumeValue+"%, #5b5b5b 100%)");

	if (video.muted) {
		video.muted = false;
	}

	video.volume = $(this).val();

});

/* CHANGE VOLUME ICON */
$('#video').on('volumechange', function() {
	if (video.muted || video.volume === 0) {
		$('#sound').addClass('nayer-hide');
		$('#mute').removeClass('nayer-hide');
	}else{
		$('#sound').removeClass('nayer-hide');
		$('#mute').addClass('nayer-hide');
	}
});


/* VOLUME ICON TOGGLE AND MUTE*/

$('.sound-mute').on('click', function() {
	if (video.muted) {
		var video_volume = parseFloat( $('#sound-control').attr('data-volume') );
		video.volume = video_volume;
		video.muted = false;
		toggleControl(this);
	}else if (video.volume === 0){
		video.volume = 1;
		$('#volume').css('background', '#e50914').val(1);
	}else{
		$('#sound-control').attr('data-volume', video.volume)
		video.muted = true;
		toggleControl(this);
	}
});


// TOGGLE FULLSCREEN
function fullLow(){
	if (document.fullscreenElement) {
		document.exitFullscreen();
	} else {
		toggleControl('#fullscreen');
		$('#nayer')[0].requestFullscreen();
	}
}
$('.full-low').on('click', function() {
	fullLow();
});
$(document).on('fullscreenchange', function() {
	if (!document.fullscreenElement) {
		toggleControl('#lowscreen');
	}
});


// SKIP AHEAD
$('#progress-section').on('mousemove', function() {
	var offsetX = event.offsetX;
	var width = $(this).width();
	const duration = video.duration;
	var skipTo = Math.round(offsetX * duration / width);

	$('#progress-range').attr('skip', skipTo);

	if (skipTo <= 3599) {
		var ctime = new Date(skipTo * 1000).toISOString().substr(14, 5);
		$('#seek-tooltip').text(ctime);
	}else{
		var ctime = new Date(skipTo * 1000).toISOString().substr(11, 8);
		$('#seek-tooltip').text(ctime);
	}

	if (offsetX < 40) {
		$('#seek-tooltip').css('left', '15px');
	}else if (offsetX > (width - 42)){
		$('#seek-tooltip').css('left', (width - 65) + 'px');
	}else{
		$('#seek-tooltip').css('left', offsetX - 22);
	}

	$('#seek-tooltip').css("opacity", "1");
	
}).mouseleave(function() {
    $('#seek-tooltip').css("opacity", "0");
});

$('#progress-range').on('input', function() {
	var skipTime = parseInt( $(this).attr('skip') );

	$('#progress-range').val(skipTime);
	$('#progress-bar').val(skipTime);

	video.currentTime = skipTime;
});


// CLICK THE VIDEO TO PLAY OR PAUSE IT
$('#video').on('click', function() {
	if (video.paused || video.ended) {
		video.play();
		toggleControl('#play , #pause-animation');
	} else {
		video.pause();
		toggleControl('#pause , #play-animation');
	}
	animatePlayback();
});


// KEYBOARD SHORTCUT
$(document).on('keyup', function(event) {
	var key = event.key;
	switch (key) {
	case ' ':
		playPause();
		break;
	case 'Alt':
		$('#rewind').click();
		break;
	case 'ArrowRight':
		$('#forward').click();
		break;
	case 'Control':
		subswitch();
		playPause();
	}
});

// FULLSCREEN LOWSCREEN DOUBLE CLICK
$("#nayer").dblclick(function(e) {
	if ( !$(e.target).hasClass('control-icon') ) {
		fullLow();
	}
});


// SUBTITLES SWITCH
function subswitch(){
	var activesub = $('[data-state="active"]').attr('srclang') == "en" ? 0 : 1

	if (activesub == 0) {
		video.textTracks[0].mode = 'showing';
		$("#video").toggleClass('videocue');
		video.textTracks[1].mode = 'showing';
		$('[label="English"]').attr('data-state', 'inactive');
	}else{
		video.textTracks[1].mode = 'hidden';
		$("#video").toggleClass('videocue')
		video.textTracks[0].mode = 'showing';
		$('[label="English"]').attr('data-state', 'active');
	}
}



// SUBTITLES SRT TO VTT && DROP DRAG

function srt2webvtt(data) {
	// remove dos newlines
	var srt = data.replace(/\r+/g, '');
	// trim white space start and end
	srt = srt.replace(/^\s+|\s+$/g, '');

	// get cues
	var cuelist = srt.split('\n\n');
	var result = "";

	if (cuelist.length > 0) {
	result += "WEBVTT\n\n";
		for (var i = 0; i < cuelist.length; i=i+1) {
			result += convertSrtCue(cuelist[i]);
		}
	}

	return result;
}

function convertSrtCue(caption) {
	// remove all html tags for security reasons
	//srt = srt.replace(/<[a-zA-Z\/][^>]*>/g, '');

	var cue = "";
	var s = caption.split(/\n/);

	// concatenate muilt-line string separated in array into one
	while (s.length > 3) {
		for (var i = 3; i < s.length; i++) {
			s[2] += "\n" + s[i]
		}
		s.splice(3, s.length - 3);
	}

	var line = 0;

	// detect identifier
	if (!s[0].match(/\d+:\d+:\d+/) && s[1].match(/\d+:\d+:\d+/)) {
		cue += s[0].match(/\w+/) + "\n";
		line += 1;
	}

	// get time strings
	if (s[line].match(/\d+:\d+:\d+/)) {
		// convert time string
		var m = s[1].match(/(\d+):(\d+):(\d+)(?:,(\d+))?\s*--?>\s*(\d+):(\d+):(\d+)(?:,(\d+))?/);
		if (m) {
			cue += m[1]+":"+m[2]+":"+m[3]+"."+m[4]+" --> "
			+m[5]+":"+m[6]+":"+m[7]+"."+m[8]+"\n";
			line += 1;
		} else {
			// Unrecognized timestring
			return "";
		}
	} else {
		// file format error or comment lines
		return "";
	}

	// get cue text
	if (s[line]) {
		cue += s[line] + "\n\n";
	}

	return cue;
}

$('body').on('dragover drop', function(event) {
    event.stopPropagation(); 
    event.preventDefault();
    if (event.type == 'drop') {
    	var filesCount = event.originalEvent.dataTransfer.files.length;
    	for (var i = 0; i < filesCount; i++) {
    		var file = event.originalEvent.dataTransfer.files[i];
    		var ext = file.name.split('.').pop();
    		if (ext == 'mp4') {
				var videoPath = URL.createObjectURL(file);
				$('#video').attr('src', videoPath);
    		}else if (ext == 'srt') {
				var reader = new FileReader();
				reader.onload = function(e){          
					var srt = e.target.result;
					var vtt = srt2webvtt(srt, "UTF-8");
					var lang = vtt.includes("the") && vtt.includes("you") ? true : false
	    			if (lang === true) {
						var blob = new Blob( [ vtt ], { type : "text/plain;charset=utf-8" } );
						var enPath = URL.createObjectURL(blob);
						$('#enPath').attr('src', enPath);
						subLine();
	    			}else{
						var blob = new Blob( [ vtt ], { type : "text/plain;charset=utf-8" } );
						var arPath = URL.createObjectURL(blob);
						$('#arPath').attr('src', arPath);
						subLine();
	    			}
				};
				reader.readAsText(file);
    		}
    	}

    }
});


});