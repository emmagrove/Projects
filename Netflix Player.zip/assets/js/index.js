$(document).ready(function(){


// HIDE THE NATIVE CONTROLS
const video = document.getElementById('video');
const videoControls = document.getElementById('nayer-controls');

const videoWorks = !!document.createElement('video').canPlayType;
if (videoWorks) {
  video.controls = false;
  videoControls.classList.remove('nayer-hide');
  $('#nayer-controls').show();
}

// TOGGLE CONTROLS STATE
function toggleControl(thiiis){
	$(thiiis).addClass('nayer-hide');
	$(thiiis).siblings().removeClass('nayer-hide');
}

/* PLAYBACK ANIMATION */
function animatePlayback() {
 	$('#playback-animation')[0].animate([{opacity: 1, transform: "scale(1)"}, {opacity: 0, transform: "scale(1.4)"}], {duration: 500});
}

// HIDE THE CONTROLS WHEN NO ACTION
var timeout = null;
$('#nayer').on('mousemove', function() {
	clearTimeout(timeout);
	if($(".video-progress:hover , .control-section:hover").length != 0){
		return;
	}
	$(this).addClass('cursor-pointer');
    $('#nayer-controls').fadeIn(200);
	timeout = setTimeout(function() {
        $('#nayer').removeClass('cursor-pointer');
    	$('#nayer-controls').fadeOut(200);
    }, 2000);
}).mouseleave(function() {
    $('#nayer-controls').fadeOut(200);
});

// TOTAL VIDEO DURATION
var tvd;
$('#video').on('loadedmetadata', function() {

	video.textTracks[0].mode = 'showing';
	video.textTracks[1].mode = 'showing';

	const videoDuration = Math.round(video.duration);

	if (videoDuration <= 3599) {
		tvd = new Date(videoDuration * 1000).toISOString().substr(14, 5);
		$('#duration').text(tvd);
	}else{
		tvd = new Date(videoDuration * 1000).toISOString().substr(11, 8);
		$('#duration').text(tvd);
	}

	$('#progress-range , #progress-bar').attr('max', videoDuration);



	var tracks = video.textTracks;
	setTimeout(function() {
		for (var j = 0; j < tracks.length; j++) {
			var track = tracks[j];
			var cues = track.cues;
			for (var i = 0; i < cues.length; i++) {
				cues[i].line = -2;
			}
		}
	}, 500);
	video.textTracks[1].mode = 'hidden';

});

// REMAINING TIME
$('#video').on('timeupdate', function() {
	const videoDuration = Math.round(video.duration);
	const currentTime = Math.round(video.currentTime);
	const remainingTimeSecond = Math.round(videoDuration - currentTime);

	// PROGRESS BAR
	$('#progress-range').val(currentTime);
	$('#progress-bar').val(currentTime);

	if (remainingTimeSecond <= 3599) {
		var remainingTime = new Date(remainingTimeSecond * 1000).toISOString().substr(14, 5);
		$('#duration').text(remainingTime);
	}else{
		var remainingTime = new Date(remainingTimeSecond * 1000).toISOString().substr(11, 8);
		$('#duration').text(remainingTime);
	}

});

// TOGGLE THE PLAYBACK STATE
function playPause(){
	if (video.paused || video.ended) {
		video.play();
		toggleControl('#play , #pause-animation');
	} else {
		video.pause();
		toggleControl('#pause , #play-animation');
	}
	animatePlayback();
}
$('.play-pause').on('click', function() {
	playPause();
});

$('#video').on('ended', function() {
	$('#pause').addClass('nayer-hide');
	$('#play').removeClass('nayer-hide');
});

// REWIND 10s
$('#rewind').on('click', function() {
	var rewindedTime = Math.round(video.currentTime - 10);
	video.currentTime = rewindedTime;
});

// FORWARD 10s
$('#forward').on('click', function() {
	var forwardedTime = Math.round(video.currentTime + 10);
	video.currentTime = forwardedTime;

});



// VOLUME
var soundTimeout = null;
$('#sound').hover(function(){

	soundTimeout = setTimeout(function() {
		$('.video-progress').fadeOut(200);
		if ($('#volume-section').is(":hidden") == true) {
			$('#volume-section').css("display", "flex").hide().fadeIn(200);
		}
	}, 300);

}, function(){

	if ( $('#volume-section').is(":hover") == false ) {
		$('#volume-section').fadeOut(200);
		$('.video-progress').css("display", "flex").hide().fadeIn(200);
	}else{
		$('#volume-section').hover(function(){}, function(){
			if ($('#sound').is(":hover") == false) {
				$('#volume-section').fadeOut(200);
				$('.video-progress').css("display", "flex").hide().fadeIn(200);
			}
		});
	}
	clearTimeout(soundTimeout);
});



// VOLUME CONTROLS
/* CHANGE VIDEO VOLUME */
$('#volume').on('input', function() {
	var volumeValue = parseInt( $(this).val() * 100);
	$(this).css("background", "linear-gradient(to right, #e50914 0%, #e50914 "+volumeValue+"%, #5b5b5b "+volumeValue+"%, #5b5b5b 100%)");

	if (video.muted) {
		video.muted = false;
	}

	video.volume = $(this).val();

});

/* CHANGE VOLUME ICON */
$('#video').on('volumechange', function() {
	if (video.muted || video.volume === 0) {
		$('#sound').addClass('nayer-hide');
		$('#mute').removeClass('nayer-hide');
	}else{
		$('#sound').removeClass('nayer-hide');
		$('#mute').addClass('nayer-hide');
	}
});


/* VOLUME ICON TOGGLE AND MUTE*/

$('.sound-mute').on('click', function() {
	if (video.muted) {
		var video_volume = parseFloat( $('#sound-control').attr('data-volume') );
		video.volume = video_volume;
		video.muted = false;
		toggleControl(this);
	}else if (video.volume === 0){
		video.volume = 1;
		$('#volume').css('background', '#e50914').val(1);
	}else{
		$('#sound-control').attr('data-volume', video.volume)
		video.muted = true;
		toggleControl(this);
	}
});


// TOGGLE FULLSCREEN
function fullLow(){
	if (document.fullscreenElement) {
		document.exitFullscreen();
	} else {
		toggleControl('#fullscreen');
		$('#nayer')[0].requestFullscreen();
	}
}
$('.full-low').on('click', function() {
	fullLow();
});
$(document).on('fullscreenchange', function() {
	if (!document.fullscreenElement) {
		toggleControl('#lowscreen');
	}
});


// SKIP AHEAD
$('#progress-section').on('mousemove', function() {
	var offsetX = event.offsetX;
	var width = $(this).width();
	const duration = video.duration;
	var skipTo = Math.round(offsetX * duration / width);

	$('#progress-range').attr('skip', skipTo);

	if (skipTo <= 3599) {
		var ctime = new Date(skipTo * 1000).toISOString().substr(14, 5);
		$('#seek-tooltip').text(ctime);
	}else{
		var ctime = new Date(skipTo * 1000).toISOString().substr(11, 8);
		$('#seek-tooltip').text(ctime);
	}

	if (offsetX < 15) {
		$('#seek-tooltip').css('left', '15px');
	}else if (offsetX > (width - 65)){
		$('#seek-tooltip').css('left', (width - 65) + 'px');
	}else{
		$('#seek-tooltip').css('left', offsetX);
	}

	$('#seek-tooltip').css("opacity", "1");
	
}).mouseleave(function() {
    $('#seek-tooltip').css("opacity", "0");
});

$('#progress-range').on('input', function() {
	var skipTime = parseInt( $(this).attr('skip') );

	$('#progress-range').val(skipTime);
	$('#progress-bar').val(skipTime);

	video.currentTime = skipTime;
});


// CLICK THE VIDEO TO PLAY OR PAUSE IT
$('#video').on('click', function() {
	if (video.paused || video.ended) {
		video.play();
		toggleControl('#play , #pause-animation');
	} else {
		video.pause();
		toggleControl('#pause , #play-animation');
	}
	animatePlayback();
});


// KEYBOARD SHORTCUT
$(document).on('keyup', function(event) {
	var key = event.key;
	switch (key) {
	case ' ':
		playPause();
		break;
	case 'ArrowLeft':
		$('#rewind').click();
		break;
	case 'ArrowRight':
		$('#forward').click();
		break;
	case 'v':
		subswitch();
		if (!video.paused) {
			playPause();
		}
	}
});

// FULLSCREEN LOWSCREEN DOUBLE CLICK
$("#nayer").dblclick(function() {
	fullLow();
});


// SUBTITLES SWITCH
function subswitch(){
	var activesub = $('[data-state="active"]').attr('srclang') == "en" ? 0 : 1

	if (activesub == 0) {
		video.textTracks[0].mode = 'hidden';
		$("#video").toggleClass('videocue')
		video.textTracks[1].mode = 'showing';
		$('[label="English"]').attr('data-state', 'inactive');
		$('[label="Arabic"]').attr('data-state', 'active');
	}else{
		video.textTracks[1].mode = 'hidden';
		$("#video").toggleClass('videocue')
		video.textTracks[0].mode = 'showing';
		$('[label="English"]').attr('data-state', 'active');
		$('[label="Arabic"]').attr('data-state', 'inactive');
	}
}


});