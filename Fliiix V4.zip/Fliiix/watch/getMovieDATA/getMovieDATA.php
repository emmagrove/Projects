<?php


if (isset($_GET["imdbID"])) {

require '../config/config.php';
	

// PREPARE VARIABLES
$imdbID = filter_var($_GET["imdbID"], FILTER_SANITIZE_STRING);


// GET DATA QUERY
$searchSql = "SELECT * FROM movies WHERE imdbID = '$imdbID'";

// GET DATA
$result = $conn->query($searchSql);

// GET DATA
if ($result->num_rows > 0) {
	$data = array();
	while($row = $result->fetch_assoc()) {
		$data[] = $row;
	}

	// GET GENRES
	$movieID = $data[0]["id"];
	// GET GENRES QUERY
	$genresSql = "SELECT genre FROM genres WHERE movieID = '$movieID'";
	// GET DATA
	$result = $conn->query($genresSql);
	// GET DATA
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$genres[] = $row["genre"];
		}

	}

}else{
	header('Location ../index.php');
}


}else{
	header('Location ../index.php');
}


?>