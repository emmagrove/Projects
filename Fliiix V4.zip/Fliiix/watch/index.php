<?php

session_start();

require 'getMovieDATA/getMovieDATA.php';

// PREPARE VARIABLES
$imdbID 		= $data[0]["imdbID"];
$title 			= $data[0]["title"];
$year 			= $data[0]["year"];
$rate 			= $data[0]["rate"];
$views 			= $data[0]["views"];
$poster 		= $data[0]["poster"];
$backdrop 		= $data[0]["backdrop"];
$releaseDate	= $data[0]["releaseDate"];
$trailer 		= $data[0]["trailer"];
$video 			= $data[0]["video"];
$overview 		= $data[0]["overview"];
$tceng 			= $data[0]["tceng"];
$tcara 			= $data[0]["tcara"];

$genresToDisplay = "";
foreach ($genres as $genre) {
	$genresToDisplay .= "<span>$genre</span>";
}

// SET SESSION VARIBLES
$_SESSION["imdbID"]	= $imdbID;
$_SESSION["title"]	= $title;
$_SESSION["year"]	= $year;
$_SESSION["video"]	= $video;
$_SESSION["tceng"]	= $tceng;
$_SESSION["tcara"]	= $tcara;

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<base href="../">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fliiix - <?php echo $title . " " . $year; ?></title>
    <link rel="icon" type="image/png" href="assets/img/favicon.ico">
    <link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/watch.css">
</head>
<body>

<nav>
	<div class="container nav-container">
		<svg class="nav-menu-icon" id="menu"><use xlink:href="assets/img/navbar.svg#menu"></use></svg>
		<svg class="nav-arrowLeft-icon" id="arrowLeft"><use xlink:href="assets/img/navbar.svg#arrowLeft"></use></svg>
		<a href="index.php" class="nav-logo-a"><img src="assets/img/logo.svg" class="nav-logo" alt="Fliiix Logo"></a>
		<a href="index.php" class="nav-nlogo-a"><img src="assets/img/nLogo.svg" class="nav-nlogo" alt="Fliiix Logo"></a>
		<div class="nav-search-input-section">
			<svg class="nav-input-search-icon"><use xlink:href="assets/img/navbar.svg#search"></use></svg>
			<input type="text" class="nav-search-input" placeholder="Search">
			<img src="assets/img/spinner.png" class="search-data-spinner" alt="">
		</div>
		<svg id="search" class="nav-search-icon"><use xlink:href="assets/img/navbar.svg#search"></use></svg>
		<svg class="nav-heart-icon"><use xlink:href="assets/img/botnav.svg#heart"></use></svg>
		<div class="profile">
			<img src="assets/img/profile.jpg" alt="">
			<svg class="profile-sortDown"><use xlink:href="assets/img/navbar.svg#sortDown"></use></svg>
		</div>
	</div>
</nav>
<div class="search-overlay"></div>
<div class="search-results-section container">
	<h2>TV SHOWS & MOVIES</h2>
	<div class="search-results"></div>
	<div class="noResults">The search for <span class="noResultsSearch"></span> did not have any matches</div>
</div>


<div class="sideBar">
	<img src="assets/img/logo.svg" class="sideBar-logo" alt="">
	<ul>
		<a href="#"><li class="sidebar-active-list">Home</li></a>
		<a href="#"><li>TV Shows</li></a>
		<a href="#"><li>Action</li></a>
		<a href="#"><li>Adventure</li></a>
		<a href="#"><li>Animation</li></a>
		<a href="#"><li>Comedy</li></a>
		<a href="#"><li>Crime</li></a>
		<a href="#"><li>Drama</li></a>
		<a href="#"><li>Family</li></a>
		<a href="#"><li>Fantasy</li></a>
		<a href="#"><li>Horror</li></a>
		<a href="#"><li>Mystery</li></a>
		<a href="#"><li>Romance</li></a>
		<a href="#"><li>Sci-Fi</li></a>
		<a href="#"><li>Thriller</li></a>
		<a href=""><li class="sideBar-close">Close</li></a>
	</ul>
</div>
<div class="sideBar-overlay"></div>

<div class="content">
	<div class="header">
		<h1><?php echo $title; ?></h1>
		<div class="year"><?php echo $year; ?></div>
	</div>

	<div class="posterBackdrop">
		<div class="poster">
			<div class="ratio">
				<img src="https://image.tmdb.org/t/p/w400<?php echo $poster; ?>" class="ratio-img" alt="">
			</div>
			<button class="playTrailer">PLAY TRAILER</button>
		</div>
		<div class="backdrop">
			<a href="play">
				<div class="ratio">
					<img src="https://image.tmdb.org/t/p/w1280<?php echo $backdrop; ?>" class="ratio-img" alt="">
					<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
				</div>
			</a>
			<p class="overview"><?php echo $overview; ?></p>
			<div class="movieDetails">
				<?php echo $genresToDisplay; ?>
				<div>
					<img src="assets/img/start.svg" alt="">
					<span><?php echo $rate; ?></span>
				</div>
			</div>
			<button class="playTrailer">PLAY TRAILER</button>
		</div>
	</div>
</div>

<div class="trailerSection">
	<img src="assets/img/close.svg" id="closeTrailer" alt="">
	<div class="ratioSection">
		<div class="ratio">
			<iframe src="https://www.youtube.com/embed/<?php echo $trailer; ?>/?enablejsapi=1" id="trailer" frameborder="0" allowfullscreen></iframe>
		</div>
	</div>
</div>


<div class="botnav">
	<svg><use xlink:href="assets/img/botnav.svg#home"></use></svg>
	<svg id="mobileSearch"><use xlink:href="assets/img/navbar.svg#search"></use></svg>
	<svg><use xlink:href="assets/img/botnav.svg#heart"></use></svg>
	<svg><use xlink:href="assets/img/botnav.svg#user"></use></svg>
</div>




<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/js/lazysizes.min.js" async=""></script>
<script src="https://www.youtube.com/player_api"></script>
<script>
// WATCH TRAILER
var trailer;
function onYouTubeIframeAPIReady() {
	trailer = new YT.Player('trailer');
}
</script>
<script src="assets/js/app.js"></script>
</body>
</html>