<?php

if (isset($_POST["search"])) {

require 'config.php';
	

// PREPARE VARIABLES
$search 		= filter_var($_POST["search"], FILTER_SANITIZE_STRING);
$subSearch 		= metaphone($search);


// PREPARE SEARCH PARTS QUERY
$searchPartsSql = "OR (";
$searchParts 	= explode(" ", $search);
if (count($searchParts) > 1) {
	foreach ($searchParts as $part) {
		$searchPartsSql .= "title LIKE '%" . $part . "%' AND ";
	}
	$searchPartsSql = rtrim($searchPartsSql, " AND ");
	$searchPartsSql .= ')';
}else{
	$searchPartsSql = "";
}


// REMOVE 'OR (' AND ')' FROM SEARCH PARTS QUERY
if (count($searchParts) > 1) {
	$casesSearchParts = ltrim($searchPartsSql, "OR (");
	$casesSearchParts = rtrim($casesSearchParts, ")");
	$casesSearchParts = "WHEN " . $casesSearchParts . " THEN 2";
}else{
	$casesSearchParts = "";
}

// SEARCH SQL QUERY
$searchSql = "SELECT imdbID, poster FROM movies WHERE title LIKE '%$search%' OR subTitle LIKE '%$subSearch%' $searchPartsSql
ORDER BY
CASE
WHEN title LIKE '%$search%' THEN 3
WHEN subTitle LIKE '%$subSearch%' THEN 1
$casesSearchParts
END
DESC , views DESC LIMIT 32";


$result = $conn->query($searchSql);

if ($result->num_rows > 0) {
	$searchData = array();
	while($row = $result->fetch_assoc()) {
		$searchData[] = $row;
	}
	echo json_encode($searchData);
}else{
	$noResults = array("status" => 0);
	echo json_encode($noResults);
}


}

?>