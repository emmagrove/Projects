<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fliiix</title>
    <link rel="icon" type="image/png" href="assets/img/favicon.ico">
    <link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<nav>
	<div class="container nav-container">
		<svg class="nav-menu-icon" id="menu"><use xlink:href="assets/img/navbar.svg#menu"></use></svg>
		<svg class="nav-arrowLeft-icon" id="arrowLeft"><use xlink:href="assets/img/navbar.svg#arrowLeft"></use></svg>
		<a href="index.php" class="nav-logo-a"><img src="assets/img/logo.svg" class="nav-logo" alt="Fliiix Logo"></a>
		<a href="index.php" class="nav-nlogo-a"><img src="assets/img/nLogo.svg" class="nav-nlogo" alt="Fliiix Logo"></a>
		<div class="nav-search-input-section">
			<svg class="nav-input-search-icon"><use xlink:href="assets/img/navbar.svg#search"></use></svg>
			<input type="text" class="nav-search-input" placeholder="Search">
			<img src="assets/img/spinner.png" class="search-data-spinner" alt="">
		</div>
		<svg id="search" class="nav-search-icon"><use xlink:href="assets/img/navbar.svg#search"></use></svg>
		<svg class="nav-heart-icon"><use xlink:href="assets/img/botnav.svg#heart"></use></svg>
		<div class="profile">
			<img src="assets/img/profile.jpg" alt="">
			<svg class="profile-sortDown"><use xlink:href="assets/img/navbar.svg#sortDown"></use></svg>
		</div>
	</div>
</nav>
<div class="search-overlay"></div>
<div class="search-results-section container">
	<h2>TV SHOWS & MOVIES</h2>
	<div class="search-results"></div>
	<div class="noResults">The search for <span class="noResultsSearch"></span> did not have any matches</div>
</div>



<div class="sideBar">
	<img src="assets/img/logo.svg" class="sideBar-logo" alt="">
	<ul>
		<a href="#"><li class="sidebar-active-list">Home</li></a>
		<a href="#"><li>TV Shows</li></a>
		<a href="#"><li>Action</li></a>
		<a href="#"><li>Adventure</li></a>
		<a href="#"><li>Animation</li></a>
		<a href="#"><li>Comedy</li></a>
		<a href="#"><li>Crime</li></a>
		<a href="#"><li>Drama</li></a>
		<a href="#"><li>Family</li></a>
		<a href="#"><li>Fantasy</li></a>
		<a href="#"><li>Horror</li></a>
		<a href="#"><li>Mystery</li></a>
		<a href="#"><li>Romance</li></a>
		<a href="#"><li>Sci-Fi</li></a>
		<a href="#"><li>Thriller</li></a>
		<a href=""><li class="sideBar-close">Close</li></a>
	</ul>
</div>
<div class="sideBar-overlay"></div>

<div class="landing">
	<div class="landing-bg"></div>
	<div class="landing-content">
		<div class="landing-content-detail">
			<img src="assets/img/landingLogo.png" class="landingLogo" alt="">
			<img src="assets/img/snow.png" class="landingLogoMobile" alt="">
			<div class="landing-info">
				<span>2019</span>
				<span>13+</span>
				<span>IMDB 8.5</span>
				<span>1h 37 min</span>
			</div>
			<div class="landing-info-mobile">
				<span class="info-duration">1h 37 min</span>
				<span class="info-age">13+</span>
				<div>
					<svg><use xlink:href="assets/img/landing.svg#imdb"></use></svg>
					<span>8.5</span>
				</div>
			</div>
			<p class="summary">The adventures of a young orphan girl living in the late 19th century. Follow Anne as 
				she learns to navigate her new life on Prince Edward Island, in this new take on L.M. 
				Montgomery's classic novels.</p>
			<p class="genre">2019 · Action · Mystery · Sci-Fi · Thriller</p>
			<hr class="hr">
			<div class="landing-btns">
				<div>
					<svg class="profile-sortDown"><use xlink:href="assets/img/landing.svg#play"></use></svg>
					<span>PLAY</span>
				</div>
				<div>
					<svg class="profile-sortDown"><use xlink:href="assets/img/landing.svg#add"></use></svg>
					<span>ADD LIST</span>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="botnav">
	<svg><use xlink:href="assets/img/botnav.svg#home"></use></svg>
	<svg id="mobileSearch"><use xlink:href="assets/img/navbar.svg#search"></use></svg>
	<svg><use xlink:href="assets/img/botnav.svg#heart"></use></svg>
	<svg><use xlink:href="assets/img/botnav.svg#user"></use></svg>
</div>


<div class="content container">

	<div class="section-title">
		<h2>Popular on Fliiix</h2>
		<div class="angle">
			<svg class="angleLeft angle-disabled"><use xlink:href="assets/img/angle.svg#angleLeft"></use></svg>
			<svg class="angleRight"><use xlink:href="assets/img/angle.svg#angleRight"></use></svg>
		</div>
	</div>
	<div class="section owl-carousel" id="section">
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/fg57nIBn2xQw8JZKIX6AzMa3pEp.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/g6tIKGc3f1H5QMz1dcgCwADKpZ7.jpg" class="lazyload alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/lw70w94nzCmIVSQvtMcuAjWHfWX.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/yxMpoHO0CXP5o9gB7IfsciilQS4.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/5vQlVWkIMPhZ88OWchJsgwGEK9.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/tK1zy5BsCt1J4OzoDicXmr0UTFH.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/sWgBv7LV2PRoQgkxwlibdGXKz1S.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/ewMNLXgDyiyaBGdCzQqCF8hKWy2.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/utYKyP9q7aYxU6LdOwkxRo92XFU.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/pXv4qbWyj6ycMaWkK2LzlizZQjf.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/jlJ8nDhMhCYJuzOw3f52CP1W8MW.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/sy6DvAu72kjoseZEjocnm2ZZ09i.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/di1bCAfGoJ0BzNEavLsPyxQ2AaB.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/8mRgpubxHqnqvENK4Bei30xMDvy.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/q719jXXEzOoYaps6babgKnONONX.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/8xC6QSyxrpm0D5A6iyHNemEWBVe.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
	</div>


	<div class="section-title">
		<h2>Trending Now</h2>
		<div class="angle">
			<svg class="angleLeft angle-disabled"><use xlink:href="assets/img/angle.svg#angleLeft"></use></svg>
			<svg class="angleRight"><use xlink:href="assets/img/angle.svg#angleRight"></use></svg>
		</div>
	</div>
	<div class="section owl-carousel" id="section">
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/di1bCAfGoJ0BzNEavLsPyxQ2AaB.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/fYQCgVRsQTEfUrP7cW5iAFVYOlh.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/wGFUewXPeMErCe2xnCmmLEiHOGh.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/bBBpi5pgOEZlCOgx2q116oPdJnx.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/2BWErT9QcADpf2G4BZ769eSnFTP.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/kivHJpsGFWgqnDMRDnnpOSgLD1s.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/jOY3dDCzjygXzumYeJ9UIyETzuj.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/8F9xUvb1JMWUMkFV2Yq3aiueAbq.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/pXv4qbWyj6ycMaWkK2LzlizZQjf.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/aKnouedcsl506t6qMOcdnrYN5yk.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/z31GxpVgDsFAF4paZR8PRsiP16D.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/2VrvxK4yxNCU6KVgo5TADJeBEQu.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/aINpljdt3VVMrCLtJW4BektwYOp.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/jSqUnWlcb83NyQ4xgu4SLxdOeps.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/m0clsFEXidLVJ0TueqWOvvImOMh.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/xsi8n1TVWwCq5XmID3ia0lIfTUG.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
	</div>



	<div class="section-title">
		<h2>New Releases</h2>
		<div class="angle">
			<svg class="angleLeft angle-disabled"><use xlink:href="assets/img/angle.svg#angleLeft"></use></svg>
			<svg class="angleRight"><use xlink:href="assets/img/angle.svg#angleRight"></use></svg>
		</div>
	</div>
	<div class="section owl-carousel" id="section">
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/reKFmynUd2VpFToo3rLTGk8zVSN.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/cA3rx5rWJ9MKAJm86dbGpywB23f.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/w1fqnG3W2xqCPTvjdPJTcfPMYH1.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/npj8BkboMkTkq6sez4hObTnJrXN.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/zDyT3gIeae39UgL9P6jL5Zc3zyt.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/wdrTYPWH4UJWR2XIwCz85M6GdS3.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/mLXvHMUiob0fgT4G6RazE6X7SY0.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/fbxQ44VRdM2PVzHSNajUseUteem.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/k9hd0dhvRNIQaXuiyniGSa0Mllr.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/kPzcvxBwt7kEISB9O4jJEuBn72t.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/6zbuHXiuCdHZ57fZOlfUknpzCjU.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/pWiALkHml93SWMdq2NSBFkfWOkJ.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/hSfuKPtyEryeFzapZ8UgZd4aESu.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/36a2GG5L0QW7iP2g8OCYoAW9PJ.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/xPLggveNr9DYbP07YDEfg3XRLOc.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/nKgbvxx7JPJntTNQPXpc9rlFVWb.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
	</div>



	<div class="section-title">
		<h2>Action</h2>
		<div class="angle">
			<svg class="angleLeft angle-disabled"><use xlink:href="assets/img/angle.svg#angleLeft"></use></svg>
			<svg class="angleRight"><use xlink:href="assets/img/angle.svg#angleRight"></use></svg>
		</div>
	</div>
	<div class="section owl-carousel" id="section">
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/yf5IuMW6GHghu39kxA0oFx7Bxmj.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/3npygfmEhqnmNTmDWhHLz1LPcbA.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/sC31ja7yVxXwggx3oNuf9hVSg0G.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/mb7wQv0adK3kjOUr9n93mANHhPJ.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/vVusHIRlyyFVS42XnqZso2wGKr.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/vbVomBFh965jxqIa64CnCdg6PVX.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/ssdElR0rHl8iApJKHu1McBl2gPa.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/lX7NtbNWyivO1o92IHdtaEl4AC0.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/gZifw6G1E0fbeR1FvyeLzdySt6m.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/9JrICtsOZWKVGErvsb2TDVvlYk1.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/8gd71hpzHIF3gCkmJBwV5egtu3k.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/stfW5cfX0A5Fvo2SBcXAazlWihg.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/n6UChiAOSTHGih2FBactLjA4Cdt.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/c3jIPDYNRHMJ51CMdZpPAEFb0JP.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/ec8AM30BnLlCoRE1Aw5INo5ubOe.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
		<div class="poster">
			<img data-src="https://image.tmdb.org/t/p/w300/1pnigkWWy8W032o9TKDneBa3eVK.jpg" class="lazyload" alt="">
			<div class="poster-hover">
				<svg><use xlink:href="assets/img/landing.svg#play"></use></svg>
			</div>
		</div>
	</div>



</div>


<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/lazysizes.min.js" async=""></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/carousel.js"></script>
</body>
</html>