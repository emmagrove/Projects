$(document).ready(function(){


// CLOSE STATUS
$('.close-icon').on('click', function(){
	$(this).parent().fadeOut(200);
});



});