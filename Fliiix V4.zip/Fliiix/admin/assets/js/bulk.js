$(document).ready(function(){


// BULK MOVIES
$('.bulk-btn').on('click', function(){

	var finds = $('.find').val().split('\n');

	for (var i = 0; i < finds.length; i++) {
		const find = finds[i];
		GrabAddMovie(find);
	}

	function GrabAddMovie(find){
		$.ajax({
			url : 'grabMovie/grabMovie.php',
			type : 'GET',
			data : {
				'find' : find
			},
			dataType: "JSON",
			beforeSend: function(){
				$('.add-movie-spinner').fadeIn(100);
			},
			success: function(response){
				var imdbID 			= response['imdbID'];
				var title 			= response['title'];
				var year 			= response['year'];
				var rate 			= response['rate'];
				var views 	  		= response['views'];
				var releaseDate 	= response['releaseDate'];
				var overview 		= response['overview'];
				var poster 			= response['poster'];
				var backdrop 		= response['backdrop'];
				var trailer 		= response['trailer'];
				var tceng 			= response['tceng'];
				var tcara 			= response['tcara'];
				var videoID 		= response['videoID'];
				var genres 			= response['genre'].join();
	
				$.ajax({
					url : 'addMovie/addMovie.php',
					type : 'POST',
					data : {
						'imdbID' : imdbID,
						'title' : title,
						'year' : year,
						'rate' : rate,
						'views' : views,
						'releaseDate' : releaseDate,
						'overview' : overview,
						'poster' : poster,
						'backdrop' : backdrop,
						'trailer' : trailer,
						'tceng' : tceng,
						'tcara' : tcara,
						'video' : videoID,
						'genres' : genres,
						'addMovie' : true,
						'bulk' : true
					},
					success: function(response){
						// STATUS
						var success = 
						`<div class="status success">
							<svg class="status-icon"><use xlink:href="assets/img/status.svg#tick"></use></svg>
							<span>${imdbID} ${title}</span>
							<svg class="close-icon"><use xlink:href="assets/img/status.svg#close"></use></svg>
						</div>`;
						var error = 
						`<div class="status error">
							<svg class="status-icon"><use xlink:href="assets/img/status.svg#error"></use></svg>
							<span>${imdbID} ${title}</span>
							<svg class="close-icon"><use xlink:href="assets/img/status.svg#close"></use></svg>
						</div>`;
						var warning = 
						`<div class="status warning">
							<svg class="status-icon"><use xlink:href="assets/img/status.svg#error"></use></svg>
							<span>${imdbID} ${title}</span>
							<a href="../watch/${imdbID}"><span>${imdbID} ${title}</span></a>
							<svg class="close-icon"><use xlink:href="assets/img/status.svg#close"></use></svg>
						</div>`;

						if (response == 1) {
							$('.bulkResults').append(success);
						}else if (response == 2) {
							$('.bulkResults').append(error);
						}else if (response == 3) {
							$('.bulkResults').append(warning);
						}

					}
				});
	
			},
			complete : function(){
				$('.add-movie-spinner').fadeOut(100);
			}
		});
	}


});



});