<?php


if (isset($_POST["addMovie"])) {

require '../../config/config.php';
	

// PREPARE VARIABLES
$imdbID 		= filter_var($_POST["imdbID"], FILTER_SANITIZE_STRING);
$title 			= filter_var($_POST["title"], FILTER_SANITIZE_STRING);
$subTitle 		= metaphone($title);
$year 			= filter_var($_POST["year"], FILTER_SANITIZE_NUMBER_INT);
$rate 			= filter_var($_POST["rate"], FILTER_SANITIZE_STRING, FILTER_FLAG_ALLOW_FRACTION);
$views 			= filter_var($_POST["views"], FILTER_SANITIZE_NUMBER_INT);
$poster 		= filter_var($_POST["poster"], FILTER_SANITIZE_STRING);
$backdrop 		= filter_var($_POST["backdrop"], FILTER_SANITIZE_STRING);
$releaseDate	= filter_var($_POST["releaseDate"], FILTER_SANITIZE_STRING);
$trailer 		= filter_var($_POST["trailer"], FILTER_SANITIZE_STRING);
$video 			= filter_var($_POST["video"], FILTER_SANITIZE_STRING);
$overview 		= filter_var($_POST["overview"], FILTER_SANITIZE_STRING);
$tceng 			= filter_var($_POST["tceng"], FILTER_SANITIZE_NUMBER_INT);
$tcara 			= filter_var($_POST["tcara"], FILTER_SANITIZE_NUMBER_INT);
$genres 		= explode(",", filter_var($_POST["genres"], FILTER_SANITIZE_STRING));


// CHECK IF THE MOVIE IS ALREADY ADDED
$addedCheck = $conn->query("SELECT imdbID FROM movies WHERE imdbID = '$imdbID'");
if ($addedCheck->num_rows > 0) {
	//******* THIS IS FOR BULK REQUESTS *******//
	if (isset($_POST["bulk"])) {
		echo 3;
		exit();
	}
	//******* THIS IS FOR BULK REQUESTS *******//
	header('Location: ../movie.php?status=3&imdbID=' . $imdbID);
	exit();
}


// INSERT DATA TO MOVIES TABLE
$movieSql = "INSERT INTO movies VALUES (NULL, '$imdbID', '$title', '$subTitle', '$year', '$rate', '$views', '$poster', '$backdrop', '$releaseDate', '$trailer', '$video', '$overview', '$tceng', '$tcara')";
$insertMovie = $conn->query($movieSql);


// PREPARE GENRES QUERY
$genreQuery = "";
foreach ($genres as $genre) {
	$genreQuery .= '(' . $conn->insert_id . ', \'' . $genre . '\'), ';
}
$genreQuery = rtrim($genreQuery, ", ");


// INSERT MOVIE GENRES TO GENRES TABLE
$genreSql = "INSERT INTO genres VALUES $genreQuery";
$insertGenre = $conn->query($genreSql);


//******* THIS IS FOR BULK REQUESTS *******//
if (isset($_POST["bulk"])) {
	// CHECK IF MOVIE & GENRES INSERTED
	if ($insertMovie === TRUE && $insertGenre === TRUE) {
		echo 1;
	} else {
		echo 2;
	}
	exit();
}
//******* THIS IS FOR BULK REQUESTS *******//


// CHECK IF MOVIE & GENRES INSERTED
if ($insertMovie === TRUE && $insertGenre === TRUE) {
	header('Location: ../movie.php?status=1');
} else {
	header('Location: ../movie.php?status=2');  
}


}


?>