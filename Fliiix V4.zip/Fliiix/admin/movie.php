<?php require 'status/status.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fliiix - Add a Movie</title>
    <link rel="icon" type="image/png" href="assets/img/favicon.ico">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/movie.css">
</head>
<body>

<nav>
	<div class="container nav-container">
		<a href="index.php"><img src="assets/img/logo.svg" class="nav-logo" alt="Fliiix Logo"></a>
		<div class="profile">
			<img src="assets/img/profile.jpg" alt="">
			<svg class="profile-sortDown"><use xlink:href="assets/img/navbar.svg#sortDown"></use></svg>
		</div>
	</div>
</nav>	

<div class="quick-add">
	<div class="header">
		<h1>Add a Movie</h1>
		<img src="assets/img/spinner.png" class="add-movie-spinner" alt="">
	</div>
	<div class="status success" style="display: <?php echo $successStatus ?? 'none'; ?>">
		<svg class="status-icon"><use xlink:href="assets/img/status.svg#tick"></use></svg>
		<span>Movie Added Successfully</span>
		<svg class="close-icon"><use xlink:href="assets/img/status.svg#close"></use></svg>
	</div>
	<div class="status error" style="display: <?php echo $errorStatus ?? 'none'; ?>">
		<svg class="status-icon"><use xlink:href="assets/img/status.svg#error"></use></svg>
		<span>Unknown Error</span>
		<svg class="close-icon"><use xlink:href="assets/img/status.svg#close"></use></svg>
	</div>
	<div class="status warning" style="display: <?php echo $warningStatus ?? 'none'; ?>">
		<svg class="status-icon"><use xlink:href="assets/img/status.svg#error"></use></svg>
		<a href="../watch/<?php echo filter_var($_GET["imdbID"], FILTER_SANITIZE_STRING) ?? '#'; ?>"><span>Movie Already Added</span></a>
		<svg class="close-icon"><use xlink:href="assets/img/status.svg#close"></use></svg>
	</div>
	<input type="text" id="find" class="add-input" placeholder="Movie Title or IMDb URL">
	<button class="add-btn">QUICK ADD</button>
</div>


<form action="addMovie/addMovie.php" method="POST">

	<div class="add">
		<input type="text" name="imdbID" class="add-input fullWidth" placeholder="IMDB ID">
		<input type="text" name="title" class="add-input" placeholder="Title">
		<input type="text" name="year" class="add-input" placeholder="Year">
		<input type="text" name="rate" class="add-input" placeholder="Rate">
		<input type="text" name="views" class="add-input" placeholder="Views">
		<input type="text" name="poster" class="add-input" placeholder="Poster">
		<input type="text" name="backdrop" class="add-input" placeholder="Backdrop">
		<input type="text" name="releaseDate" class="add-input fullWidth" placeholder="Release Date">
		<div class="posterPreview"><img src="https://image.tmdb.org/t/p/w400/cA3rx5rWJ9MKAJm86dbGpywB23f.jpg" id="posterPreview" alt=""></div>
		<div class="backdropPreview"><img src="https://image.tmdb.org/t/p/w1280/aq2yEMgRQBPfRkrO0Repo2qhUAT.jpg" id="backdropPreview" alt=""></div>
		<input type="text" name="trailer" class="add-input" placeholder="Trailer URL">
		<input type="text" name="video" class="add-input" placeholder="Video URL">
		<textarea name="overview" class="overview add-input" placeholder="Overview"></textarea>
		<input type="text" name="tceng" class="add-input" placeholder="Trailer URL">
		<input type="text" name="tcara" class="add-input" placeholder="Video URL">
		<div class="genre">
			<span data-genre="Action">Action</span>
			<span data-genre="Adventure">Adventure</span>
			<span data-genre="Animation">Animation</span>
			<span data-genre="Comedy">Comedy</span>
			<span data-genre="Crime">Crime</span>
			<span data-genre="Drama">Drama</span>
			<span data-genre="Family">Family</span>
			<span data-genre="Fantasy">Fantasy</span>
			<span data-genre="Horror">Horror</span>
			<span data-genre="Mystery">Mystery</span>
			<span data-genre="Romance">Romance</span>
			<span data-genre="Sci-Fi">Sci-Fi</span>
			<span data-genre="Thriller">Thriller</span>
		</div>
		<input type="hidden" name="genres">
		<button class="add-btn" name="addMovie">ADD MOVIE</button>
	</div>
	

</form>


<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/movie.js"></script>
</body>
</html>