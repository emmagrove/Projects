<?php

if (isset($_GET["status"])) {
	$status = filter_var($_GET["status"], FILTER_SANITIZE_NUMBER_INT);
	if ($status == 1) {
		$successStatus = "flex";
	}elseif ($status == 2) {
		$errorStatus = "flex";
	}elseif ($status == 3) {
		$warningStatus = "flex";
	}
}

?>