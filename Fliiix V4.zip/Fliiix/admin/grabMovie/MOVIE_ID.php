<?php


class MovieID {

	public $imdbID;
	public $videoID;

	function __construct($imdbID){

		$this->imdbID = $imdbID;
		$this->getVideoID();

	}

	// GET MOVIE ID
	public function getVideoID(){
		$url = "https://trailers.to/watch/imdb/" . $this->imdbID;

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

		$result = curl_exec($ch);

		$EFFECTIVE_URL = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);

		preg_match('/https:\/\/trailers.to\/en\/movie\/(.*?)\//', $EFFECTIVE_URL, $preg_videoID);
		$this->videoID = $preg_videoID[1];

		curl_close($ch);
	}


}


?>