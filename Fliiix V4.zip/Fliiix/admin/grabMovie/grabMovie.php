<?php


if (isset($_GET["find"])) {

$find = trim($_GET["find"]);

require 'IMDB.php';
require 'TMDB.php';
require 'SUBTITLES.php';
require 'MOVIE_ID.php';


header('Content-Type: application/json');


$grabMovie = new stdClass();


$imdb = new Imdb($find);
$grabMovie->imdbID 		= $imdb->getID();
$grabMovie->title 		= $imdb->getTitle();
$grabMovie->year 		= $imdb->getYear();
$grabMovie->rate 		= $imdb->getRate();
$grabMovie->views 		= $imdb->getViews();
$grabMovie->releaseDate = $imdb->getReleaseDate();
$grabMovie->overview 	= $imdb->getOverview();
$grabMovie->genre 		= $imdb->getGenre();


$tmdb = new Tmdb($grabMovie->imdbID);
$grabMovie->poster 		= $tmdb->getPoster();
$grabMovie->backdrop 	= $tmdb->getBackdrop();
$grabMovie->trailer 	= $tmdb->getTrailer();


$subtitles_eng = new Subtitles($grabMovie->imdbID, 'eng');
$grabMovie->tceng 		= $subtitles_eng->trackCount;
$subtitles_ara = new Subtitles($grabMovie->imdbID, 'ara');
$grabMovie->tcara 		= $subtitles_ara->trackCount;

$movie_ID = new MovieID($grabMovie->imdbID);
$grabMovie->videoID 	= $movie_ID->videoID;





echo json_encode($grabMovie);

}


?>