<?php require 'status/status.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fliiix - Bulk Movies Adder</title>
    <link rel="icon" type="image/png" href="assets/img/favicon.ico">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bulk.css">
</head>
<body>

<nav>
	<div class="container nav-container">
		<a href="index.php"><img src="assets/img/logo.svg" class="nav-logo" alt="Fliiix Logo"></a>
		<div class="profile">
			<img src="assets/img/profile.jpg" alt="">
			<svg class="profile-sortDown"><use xlink:href="assets/img/navbar.svg#sortDown"></use></svg>
		</div>
	</div>
</nav>	

<div class="bulk-add">
	<div class="header">
		<h1>Bulk Movies Adder</h1>
		<img src="assets/img/spinner.png" class="add-movie-spinner" alt="">
	</div>
	<textarea class="find" placeholder="Movie Title or IMDb URL"></textarea>
	<button class="bulk-btn">BULK ADDER</button>
	<div class="bulkResults"></div>
</div>

<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/bulk.js"></script>
</body>
</html>