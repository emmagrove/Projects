$(document).ready(function () {
  $(".links-content").click(function () {
    // Fetch data from links.json file
    $(".shared-media").fadeOut(100);
    $(".shared-links").fadeIn(300);
    $(".links-content").addClass("active");
    $(".media-content").removeClass("active");
    $.getJSON("links.json", function (data) {
      renderLinks(data);
    });
  });

  // Function to render the links data
  function renderLinks(links) {
    links.forEach(function (linkData) {
      // Create HTML for each link item
      const linkHtml = `
                <div class="link-box" data-index="${linkData.index}">
                    <div class="link-image">
                        <img src="${
                          linkData.image
                            ? "links/" + linkData.image
                            : "assets/0.png"
                        }" alt="" />
                    </div>
                    <div class="link-details">
                        <p class="link-title">${linkData.title || ""}</p>
                        <p class="link-host">${getDomain(linkData.link)}</p>
                    </div>
                </div>
            `;

      // Append to the container
      $(".shared-links").append(linkHtml);
    });
  }

  // Function to extract domain from URL
  function getDomain(url) {
    try {
      const domain = new URL(url).hostname;
      return domain;
    } catch (e) {
      return "Invalid URL";
    }
  }
});
