$(document).ready(function () {
  // Constants and initial variables
  let user =
    sessionStorage.getItem("user") === null
      ? 1
      : parseInt(sessionStorage.getItem("user")); // Default is 1
  let chat = []; // Array to hold all the chat messages
  let loading = false; // Prevent multiple simultaneous loads
  let loadIndex = 0; // Index for the next set of messages to load
  let isSearchMode = false; // Flag for search mode
  let isProfileMode = false; // Flag for search mode
  let prevTimestamp = 0;
  let lightbox = GLightbox(); // Lightbox

  // Function to update the profile based on user sessionStorage
  function updateProfile() {
    if (user === 1) {
      $(".profile-name").text("Dannie");
      $(".profile-image").attr("src", "assets/dannie.jpg");
    } else {
      $(".profile-name").text("ＭＯ ッ");
      $(".profile-image").attr("src", "assets/mo.jpg");
    }
  }
  // Set initial profile image and name based on sessionStorage
  updateProfile();

  // Toggle user state when the profile is clicked
  $(".profile-box").click(function () {
    user = user === 0 ? 1 : 0; // Toggle between 0 and 1
    sessionStorage.setItem("user", user); // Store the user state in sessionStorage
    location.reload(); // Refresh the page
  });

  // Show profile layer
  $(".profile").click(function () {
    $(".profile-layer").show();
    isProfileMode = true;
    history.pushState(null, "", ""); // Add fake state when opening the overlay
  });

  // Close the search layer when the back button is clicked
  $(".profile-back").click(function () {
    $(".profile-layer").hide();
    isProfileMode = false;
  });

  // Load chat messages from a JSON file and store them in chat variable
  $.ajax({
    url: "chat.json",
    dataType: "json",
    success: function (data) {
      chat = data.messages; // Store all messages
      loadMessages(); // Load the first set of messages (50)
    },
    error: function () {
      console.error("Failed to load chat data."); // Handle failure to load data
    },
  });

  /**
   * Load more messages when the user scrolls.
   * Handles loading messages in case of search as well
   */
  $(".messages").on("scroll", function () {
    const scrollHeight = $(".messages")[0].scrollHeight; // Total content height
    const scrollTop = $(".messages").scrollTop(); // Current scroll position
    const containerHeight = $(".messages")[0].offsetHeight; // Visible container height

    // Regular Load
    // Load older messages when scrolling near the top
    if (
      -scrollTop + containerHeight + 200 >= scrollHeight &&
      !loading &&
      !isSearchMode &&
      !isProfileMode
    ) {
      // Prevent loading if already in progress
      loading = true;
      loadMessages();
    }
  });

  /**
   * Function to load messages from the `chat` array.
   */
  function loadMessages() {
    // Get the next 50 messages to display
    const messagesToLoad = chat.slice(loadIndex, loadIndex + 250);
    // Append each message to the chat UI
    messagesToLoad.forEach(function (message) {
      insertMessage(message);
    });
    // Reinitialize the lightbox
    initializeLightbox();
    loadIndex += 250; // Move the starting index for the next load
    loading = false;
  }

  /**
   * Insert a single message to the chat UI, handling different content types (text, media).
   */
  function insertMessage(message) {
    const messageStatus = message.sender_name == user ? "sent" : "received"; // sent/received for css class name use
    const currentTimestamp = message.timestamp_ms;
    let messageHtml = "";

    // Check if a date separator needs to be inserted
    if (prevTimestamp - currentTimestamp > 3600000) {
      messageHtml += insertDateSeparator(prevTimestamp);
    }
    prevTimestamp = currentTimestamp; // Update previous timestamp

    // Handle media content (text, photos, videos, audio, link)
    let messageType = "text"; // Default message type is text
    if (message.photos) {
      messageType = "photo";
    } else if (message.videos) {
      messageType = "video";
    } else if (message.audio_files) {
      messageType = "audio";
    } else if (message.share) {
      messageType = "link";
    }

    // Construct the HTML for the message
    messageHtml += `<div class="message ${messageType} ${messageStatus}" data-index="${message.index}">`;
    if (messageType == "text") {
      messageHtml += `<div>${message.content}</div>`;
    } else if (message.photos) {
      messageHtml += `<a href="media/${message.photos}" class="glightbox"><img src="media/${message.photos}" alt=""/></a>`;
    } else if (message.videos) {
      messageHtml += `<video controls src="media/${message.videos}#t=0.001" class="video-message"></video>`;
    } else if (message.audio_files) {
      messageHtml += `<audio controls src="media/${message.audio_files}"></audio>`;
    } else if (messageType == "link") {
      messageHtml += `<a href="${message.share}" target="_blank">${message.share}</a>`;
    }
    messageHtml += `</div>`;

    // Append message to the chat
    $(".messages").append(messageHtml);
  }

  // ------------------------------
  // Search functionality
  // ------------------------------

  // Open the search layer when the search button is clicked
  $(".search").click(function () {
    $(".search-layer").show();
    $(".search-input").focus();
    isSearchMode = true; // Enable search mode
    history.pushState(null, "", ""); // Add fake state when opening the overlay
  });

  // Close the search layer when the back button is clicked
  $(".search-back").click(function () {
    $(".search-layer").hide();
    isSearchMode = false; // Disable search mode
    console.log("Search mode is off");
  });

  // Search on input functionality
  // Filter messages based on the search input
  // Display the filtered search results in the search layer.
  $(".search-input").on("input", function () {
    const query = $(this).val().toLowerCase(); // Get the lowercase search query

    // Filter messages by content
    const filteredMessages = chat
      .filter(
        (message) =>
          message.content && message.content.toLowerCase().includes(query)
      )
      .slice(0, 200); // Limit to the first 100 matching results

    $(".search-results").empty(); // Clear previous search results

    // Display "No results" if no messages match the search query
    if (filteredMessages.length === 0) {
      $(".search-results").append(
        "<div class='no-results'>No results found</div>"
      );
    } else {
      // Display each matching message
      filteredMessages.forEach(function (filteredMessage) {
        const senderName =
          filteredMessage.sender_name == 1 ? "ＭＯ ッ" : "Dannie";
        const senderImage = filteredMessage.sender_name == 1 ? "mo" : "dannie";
        let highlightedMessage = filteredMessage.content.replace(
          new RegExp(`(${query})`, "gi"), // Search case-insensitively for "apple"
          "<span>$1</span>" // Wrap the matched word with <strong>
        );

        const messageHtml = `
                        <div
      class="search-result"
      data-index="${filteredMessage.index}"
    >
      <div class="search-profile">
        <img src="assets/${senderImage}.jpg" alt="" />
      </div>
      <div class="search-details">
        <p class="search-sender">${senderName}</p>
        <p class="search-message">${highlightedMessage}</p>
        <p class="search-date">
          ${searchDateFormatter(filteredMessage.timestamp_ms)}
        </p>
      </div>
    </div>`;
        $(".search-results").append(messageHtml);
      });
    }
  });

  // Handle click on a search result to load the surrounding messages
  $(document).on("click", ".search-result", function () {
    const selectedSearchResult = chat.length - $(this).data("index") - 1;
    const searchQuery = $(".search-input").val().trim().toLowerCase();

    // Load surrounding messages based on the selected result
    const surroundingMessages = chat.slice(
      Math.max(0, selectedSearchResult - 250), // Ensure no negative index
      Math.min(chat.length, selectedSearchResult + 250) // Ensure we don't exceed chat length
    );

    // Clear current chat and append surrounding messages
    $(".messages").empty();
    surroundingMessages.forEach(function (surroundingMessage, index) {
      insertMessage(surroundingMessage);
      // Reinitialize the lightbox
      initializeLightbox();

      // Highlight only the searched word in the selected message
      if (index === 250) {
        let targetMessage = $(".messages .message").last(); // Better naming
        let messageText = targetMessage.html();

        if (searchQuery.length > 0) {
          const regex = new RegExp(`(${searchQuery})`, "gi");
          messageText = messageText.replace(
            regex,
            '<span class="highlight-message">$1</span>'
          );
          targetMessage.html(messageText);
        }
      }
    });

    // Hide the search layer
    $(".search-layer").hide();

    // Scroll the chat to the searched message (center it)
    const messagesContainer = $(".messages");
    const targetMessage = messagesContainer.find(
      `[data-index="${$(this).data("index")}"]`
    );

    if (targetMessage.length) {
      const scrollPosition =
        targetMessage.offset().top -
        messagesContainer.offset().top +
        messagesContainer.scrollTop() -
        messagesContainer.height() / 2 +
        targetMessage.outerHeight() / 2;

      messagesContainer.scrollTop(scrollPosition);
    }
  });

  // Handle click on a link box to load the surrounding messages
  $(document).on("click", ".link-box", function () {
    const selectedLink = chat.length - $(this).data("index") - 1;

    // Load surrounding messages based on the selected result
    const surroundingMessages = chat.slice(
      Math.max(0, selectedLink - 250), // Ensure no negative index
      Math.min(chat.length, selectedLink + 250) // Ensure we don't exceed chat length
    );

    // Clear current chat and append surrounding messages
    $(".messages").empty();
    surroundingMessages.forEach(function (surroundingMessage, index) {
      insertMessage(surroundingMessage);
      // Reinitialize the lightbox
      initializeLightbox();
    });

    // Hide the search layer
    $(".profile-layer").hide();

    // Scroll the chat to the searched message (center it)
    const messagesContainer = $(".messages");
    const targetMessage = messagesContainer.find(
      `[data-index="${$(this).data("index")}"]`
    );

    if (targetMessage.length) {
      const scrollPosition =
        targetMessage.offset().top -
        messagesContainer.offset().top +
        messagesContainer.scrollTop() -
        messagesContainer.height() / 2 +
        targetMessage.outerHeight() / 2;

      messagesContainer.scrollTop(scrollPosition);
    }

    // Add highlight
    targetMessage.find("a").addClass("highlight-message");
  });

  // Handle click on a shared media boxto load the surrounding messages
  $(document).on("click", ".media-box", function () {
    const selectedMedia = chat.length - $(this).data("index") - 1;

    // Load surrounding messages based on the selected result
    const surroundingMessages = chat.slice(
      Math.max(0, selectedMedia - 250), // Ensure no negative index
      Math.min(chat.length, selectedMedia + 250) // Ensure we don't exceed chat length
    );

    // Clear current chat and append surrounding messages
    $(".messages").empty();
    surroundingMessages.forEach(function (surroundingMessage, index) {
      insertMessage(surroundingMessage);
      // Reinitialize the lightbox
      initializeLightbox();
    });

    // Hide the profile layer
    $(".profile-layer").hide();

    // Scroll the chat to the searched message (center it)
    const messagesContainer = $(".messages");
    const targetMessage = messagesContainer.find(
      `[data-index="${$(this).data("index")}"]`
    );

    if (targetMessage.length) {
      const scrollPosition =
        targetMessage.offset().top -
        messagesContainer.offset().top +
        messagesContainer.scrollTop() -
        messagesContainer.height() / 2 +
        targetMessage.outerHeight() / 2;

      messagesContainer.scrollTop(scrollPosition);
    }
  });

  function insertDateSeparator(timestamp) {
    const now = dayjs();
    const messageTime = dayjs(timestamp);

    let formattedDate;

    if (now.isSame(messageTime, "day")) {
      formattedDate = `Today at ${messageTime.format("h:mm A")}`;
    } else if (now.subtract(1, "day").isSame(messageTime, "day")) {
      formattedDate = `Yesterday at ${messageTime.format("h:mm A")}`;
    } else if (now.diff(messageTime, "days") < 7) {
      formattedDate = `${messageTime.format("dddd")} at ${messageTime.format(
        "h:mm A"
      )}`;
    } else if (now.isSame(messageTime, "year")) {
      formattedDate = `${messageTime.format("MMM D")} at ${messageTime.format(
        "h:mm A"
      )}`;
    } else {
      formattedDate = `${messageTime.format(
        "MMM D, YYYY"
      )} at ${messageTime.format("h:mm A")}`;
    }

    return `<div class="date-separator">${formattedDate}</div>`;
  }

  // Function to format search result date
  function searchDateFormatter(timestamp) {
    const now = dayjs();
    const messageTime = dayjs(timestamp);

    let formattedDate;

    // If the date is this year
    if (now.isSame(messageTime, "year")) {
      formattedDate = messageTime.format("MMMM D");
    } else {
      // If the date is from a previous year
      formattedDate = messageTime.format("MMMM D, YYYY");
    }

    return `${formattedDate}`;
  }

  // Function to initialize the lightbox
  function initializeLightbox() {
    lightbox = GLightbox({
      touchNavigation: true,
      dragToleranceY: 50,
      cssEfects: {
        slide: { in: "slideInLeft", out: "slideOutRight" },
        slideBack: { in: "slideInRight", out: "slideOutLeft" },
      },
    });
  }
  // Listen for the back navigation event
  window.addEventListener("popstate", function () {
    $(".profile-layer").hide();
    $(".search-layer").hide();
  });

  // Hold to download video
  let holdTimer;

  $(document)
    .on("touchstart mousedown", ".video-message", function (e) {
      console.log("click");
      holdTimer = setTimeout(function () {
        let videoSrc = $(e.currentTarget).attr("src").split("#")[0]; // Remove fragment
        let fileName = videoSrc.substring(videoSrc.lastIndexOf("/") + 1);

        fetch(videoSrc)
          .then((response) => response.blob())
          .then((blob) => {
            const url = URL.createObjectURL(blob);
            const a = $("<a>")
              .attr({
                href: url,
                download: fileName,
              })
              .appendTo("body");

            a[0].click();
            a.remove();
            URL.revokeObjectURL(url);
          })
          .catch((error) => console.error("Download failed:", error));
      }, 1000); // 1000ms hold duration to match iPhone behavior
    })
    .on("touchend mouseup mouseleave", ".video-message", function () {
      clearTimeout(holdTimer); // Cancel download if released early
    });
});
