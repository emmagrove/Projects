let mediaData = [];
let currentIndex = 0;
let firstProfileVisit = true;
const batchSize = 54; // Load 6 at a time (2 full rows)

// Function to load media data if not already loaded
function loadMediaData() {
  if (mediaData.length) return;
  $.getJSON("media.json", (data) => {
    mediaData = data;
    loadMoreMedia();
  });
}

$(".profile").click(function () {
  if (!firstProfileVisit) return;
  firstProfileVisit = false; // Prevent reloading
  loadMediaData();
});

// Media preview
$(".media-content").click(function () {
  $(".shared-links").fadeOut(100);
  $(".shared-media").fadeIn(300);
  $(".media-content").addClass("active");
  $(".links-content").removeClass("active");

  loadMediaData();
  console.log("Loading media shared preview content");
});

// Function to render media
function loadMoreMedia() {
  const nextBatch = mediaData.slice(currentIndex, currentIndex + batchSize);
  nextBatch.forEach((media) => {
    $(".shared-media").append(`
      <div class="media-box ${
        media.type === "video" ? "preview-video" : ""
      }" data-index="${media.index}">
        <img src="shared_previews/${media.media}" alt="" />
      </div>
    `);
  });
  currentIndex += batchSize;
}

// Load more on scroll
$(".profile-layer").on("scroll", function () {
  if (
    $(this).scrollTop() + $(this).innerHeight() >=
    $(this).prop("scrollHeight") - 100
  ) {
    console.log("Loading more media...");
    loadMoreMedia();
  }
});
