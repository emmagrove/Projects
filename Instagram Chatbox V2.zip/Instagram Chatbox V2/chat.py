import os
import json
import shutil

class ChatProcessor:
    def __init__(self, folder_path):
        self.folder_path = folder_path
        self.all_messages = []
        self.participants = []
        self.media_folder = os.path.join(folder_path, "media")  # New media folder for saved files
        self.photos_folder = os.path.join(folder_path, "photos")
        self.videos_folder = os.path.join(folder_path, "videos")
        self.audio_folder = os.path.join(folder_path, "audio")

    def merge_messages(self):
        """Merge and clean messages from all JSON files in the folder."""
        for file in self.get_json_files():
            self.add_messages(file)

        self.renumber_and_copy_media_files()

        # Add index to each message, starting with the highest index
        for i, message in enumerate(self.all_messages):
            message['index'] = len(self.all_messages) - 1 - i  # The first message gets the highest index

        self.save_messages()


    def get_json_files(self):
        """Retrieve and sort all JSON files in the folder."""
        return sorted(
            (os.path.join(self.folder_path, file) for file in os.listdir(self.folder_path) if file.endswith('.json')),
            key=lambda f: int(''.join(filter(str.isdigit, os.path.basename(f)))))
        
    def add_messages(self, file_path):
        """Read and process messages from a JSON file."""
        try:
            with open(file_path, 'r', encoding='latin1') as file:  # Open as latin1 to handle encoding issues
                data = json.load(file)
                self.participants = data.get('participants', [])
                for message in data.get('messages', []):
                    cleaned_message = self.process_message(message)
                    if cleaned_message:
                        self.all_messages.append(cleaned_message)
        except Exception as e:
            print(f"Error processing file {file_path}: {e}")

    def process_message(self, message):
        """Clean and standardize the message."""
        # Skip irrelevant messages
        if 'content' in message and (message['content'] == "Liked a message" or
                                     message['content'].startswith("Reacted") or
                                     message.get('content', '').endswith("sent an attachment.")):
            return None

        # Standardize sender name to index
        if 'sender_name' in message:
            sender_index = self.get_sender_index(message['sender_name'])
            if sender_index is not None:
                message['sender_name'] = sender_index

        # Remove unnecessary fields
        for field in ["is_geoblocked_for_viewer", "is_unsent_image_by_messenger_kid_parent", "reactions"]:
            message.pop(field, None)

        # Clean media URIs
        for media_type in ['photos', 'videos', 'audio_files']:
            if media_type in message:
                message[media_type] = self.process_media(message.get(media_type))

        # Handle shared links
        # Handle shared links
        if 'share' in message and 'link' in message['share']:
            link = message['share']['link']
            if "instagram.com" in link or "giphy.com" in link:
                return None  # Skip this message if the link is from Instagram or Giphy
            message['share'] = link
            message.pop('content', None)

        # Decode and re-encode the message content properly
        if 'content' in message:
            message['content'] = message['content'].encode('latin1').decode('utf-8')

        return message

    def get_sender_index(self, sender_name):
        """Return the index of the sender based on the participants list."""
        for i, participant in enumerate(self.participants):
            if participant['name'] == sender_name:
                return i
        return None

    def process_media(self, media):
        """Process and return the URI for media files."""
        if isinstance(media, list) and media:
            uri = media[0].get("uri", "")
            if uri and not os.path.splitext(uri)[1]:
                uri += ".jpg"  # Default to .jpg for photos
            return uri
        return ""

    def renumber_and_copy_media_files(self):
        """Copy and renumber all media files into a 'media' folder in the same directory as the Python script, updating JSON references."""
        # Get the current directory (where the Python script is located)
        current_directory = os.getcwd()  # This will point to the directory from where the script is running
        media_folder = os.path.join(current_directory, "media")
        
        # Ensure the 'media' folder exists
        os.makedirs(media_folder, exist_ok=True)

        # Collect all media files (photos, videos, audio) into one list
        media_files = []

        # Collect photos, videos, and audio files into one list
        for media_type, folder in [("photos", self.photos_folder), ("videos", self.videos_folder), ("audio", self.audio_folder)]:
            for old_filename in sorted(os.listdir(folder)):
                old_path = os.path.join(folder, old_filename)
                if os.path.isfile(old_path):
                    # Add file to media_files list
                    media_files.append((media_type, old_filename, old_path))

        # Renaming and copying media files to the 'media' folder
        media_index = 1
        for media_type, old_filename, old_path in media_files:
            file_extension = os.path.splitext(old_filename)[1].lower()

            # If it's an image and doesn't have an extension, add .jpg
            if media_type == "photos" and not file_extension:
                new_filename = f"{media_index}.jpg"
            else:
                # Rename all media files sequentially (image1.jpg, video1.mp4, etc.)
                new_filename = f"{media_index}{file_extension}"

            # Construct the new path in the 'media' folder
            new_path = os.path.join(media_folder, new_filename)

            # Copy the file to the 'media' folder
            shutil.copy(old_path, new_path)

            # Update the references in JSON
            self.update_media_references(media_type, old_filename, new_filename)

            media_index += 1


    def update_media_references(self, media_type, old_filename, new_filename):
        """Update media references in all messages."""
        if media_type == "audio":
            media_type = "audio_files"
        for message in self.all_messages:
            if media_type in message and old_filename in message[media_type]:
                message[media_type] = new_filename

    def save_messages(self):
        """Save the merged and cleaned messages to a new JSON file."""
        with open('chat.json', 'w', encoding='utf-8') as file:  # Save as utf-8
            json.dump({'messages': self.all_messages}, file, ensure_ascii=False, indent=4)

# Example usage
folder_path = input("Enter the folder path: ")
processor = ChatProcessor(folder_path)
processor.merge_messages()
