import json
import os
import cv2
from PIL import Image

# Paths
CHAT_JSON = "chat.json"
MEDIA_FOLDER = "media"
THUMBNAILS_FOLDER = "shared_previews"

# Ensure the thumbnails directory exists
os.makedirs(THUMBNAILS_FOLDER, exist_ok=True)

def resize_image(input_path, output_path, size=(200, 200)):
    try:
        img = Image.open(input_path)

        # Convert RGBA (with transparency) to RGB (without transparency)
        if img.mode == 'RGBA':
            img = img.convert('RGB')

        # Calculate the crop box to center and fill the 250x250 box
        img_ratio = img.width / img.height
        target_ratio = size[0] / size[1]

        if img_ratio > target_ratio:
            # Image is wider than target, crop the sides
            new_width = int(size[1] * img_ratio)
            img = img.resize((new_width, size[1]), Image.LANCZOS)
            left = (img.width - size[0]) // 2
            img = img.crop((left, 0, left + size[0], size[1]))
        else:
            # Image is taller than target, crop the top/bottom
            new_height = int(size[0] / img_ratio)
            img = img.resize((size[0], new_height), Image.LANCZOS)
            top = (img.height - size[1]) // 2
            img = img.crop((0, top, size[0], top + size[1]))

        img.save(output_path, "JPEG", quality=95)
    except Exception as e:
        print(f"Error resizing {input_path}: {e}")



def generate_video_thumbnail(video_path, thumbnail_path):
    """Extract the first frame from a video, resize it, and save as a JPG thumbnail without skewing."""
    cap = cv2.VideoCapture(video_path)
    success, frame = cap.read()
    cap.release()
    
    if success:
        # Get original frame dimensions
        height, width, _ = frame.shape
        
        # Calculate the center crop coordinates
        min_side = min(height, width)
        center_x, center_y = width // 2, height // 2
        crop_x1 = center_x - min_side // 2
        crop_x2 = center_x + min_side // 2
        crop_y1 = center_y - min_side // 2
        crop_y2 = center_y + min_side // 2
        
        # Crop the image to a square based on the smallest side
        cropped_frame = frame[crop_y1:crop_y2, crop_x1:crop_x2]
        
        # Resize the cropped square frame to 200x200
        thumbnail = cv2.resize(cropped_frame, (200, 200), interpolation=cv2.INTER_AREA)
        
        # Save the thumbnail
        thumbnail_path = thumbnail_path.replace(".mp4", ".jpg")  # Fix the extension
        cv2.imwrite(thumbnail_path, thumbnail)


# Read chat.json
with open(CHAT_JSON, "r", encoding="utf-8") as file:
    chat_data = json.load(file)

media_data = []

for message in chat_data.get("messages", []):
    index = message.get("index")
    if not index:
        continue  # Skip if no index

    for key in ["photos", "videos"]:
        if key in message:
            file_name = message[key]  # Filename from JSON
            media_type = "image" if key == "photos" else "video"
            original_path = os.path.join(MEDIA_FOLDER, file_name)
            new_file_name = f"{index}.jpg" if media_type == "image" else f"{index}.jpg"  # Fix for video thumbnail
            new_path = os.path.join(THUMBNAILS_FOLDER, new_file_name)

            if os.path.exists(original_path):
                if media_type == "image":
                    resize_image(original_path, new_path)  # Resize & save
                else:
                    generate_video_thumbnail(original_path, new_path)  # Generate video thumbnail
            else:
                print(f"File not found: {original_path}, using placeholder.")
                new_path = os.path.join(THUMBNAILS_FOLDER, "0.jpg")  # Placeholder if missing

            media_data.append({
                "index": index,
                "media": new_file_name,
                "type": media_type
            })

# Save to media.json
with open("media.json", "w", encoding="utf-8") as outfile:
    json.dump(media_data, outfile, indent=4)

print("✅ Media processing complete! Check media.json and thumbnails folder.")