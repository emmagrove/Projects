import json
import os
import requests
from bs4 import BeautifulSoup
from PIL import Image
from io import BytesIO
from concurrent.futures import ThreadPoolExecutor

class ChatProcessor:
    def __init__(self, chat_file, output_file, image_folder):
        self.chat_file = chat_file
        self.output_file = output_file
        self.image_folder = image_folder

        # Create the image folder if it doesn't exist
        os.makedirs(self.image_folder, exist_ok=True)

    def extract_links(self):
        """Extracts shared links from chat.json and returns a list of dictionaries."""
        links = []
        with open(self.chat_file, "r", encoding="utf-8") as file:
            chat_data = json.load(file)
        
        messages = chat_data.get("messages", [])  # Get the messages array safely
        
        for entry in messages:
            if "share" in entry:
                links.append({
                    "index": entry["index"],
                    "link": entry["share"]
                })
        return links

    def fetch_metadata(self, url):
        """Fetches the title and preview image URL of a given link."""
        try:
            response = requests.get(url, timeout=5)
            response.raise_for_status()
        except requests.RequestException:
            return None, None

        soup = BeautifulSoup(response.text, "html.parser")

        # Extract title
        title = soup.title.string if soup.title else "No Title"

        # Extract image (og:image meta tag)
        image_tag = soup.find("meta", property="og:image")
        image_url = image_tag["content"] if image_tag else None

        return title, image_url

    def download_image(self, image_url, index):
        """Downloads and saves the image from the URL without skewing the aspect ratio."""
        if not image_url:
            image_url = "assets/0.jpg"  # Placeholder if no image URL

        try:
            response = requests.get(image_url, timeout=5)
            response.raise_for_status()
            image = Image.open(BytesIO(response.content))

            # Resize image while maintaining aspect ratio
            image.thumbnail((150, 150))  # This preserves the aspect ratio

            # Create filename and save
            image_name = f"{index}.jpg"
            image_path = os.path.join(self.image_folder, image_name)
            image.save(image_path, "JPEG", quality=80)
            return image_name
        except:
            # In case of any errors, return 0.jpg as a default placeholder
            return None

    def process_link(self, entry):
        """Processes a single link: fetch metadata, download image, and return data."""
        title, image_url = self.fetch_metadata(entry["link"])
        image_name = self.download_image(image_url, entry["index"])

        return {
            "index": entry["index"],
            "link": entry["link"],
            "title": title,
            "image": image_name
        }

    def process_links(self):
        """Processes all links, fetches metadata, downloads images, and saves to links.json."""
        links = self.extract_links()
        processed_data = []

        # Use ThreadPoolExecutor to process links concurrently
        with ThreadPoolExecutor() as executor:
            processed_data = list(executor.map(self.process_link, links))

        # Save to JSON
        with open(self.output_file, "w", encoding="utf-8") as file:
            json.dump(processed_data, file, indent=4)

if __name__ == "__main__":
    processor = ChatProcessor("chat.json", "links.json", "links")
    processor.process_links()
    print("Processing complete. Data saved in links.json and images in posters folder.")
