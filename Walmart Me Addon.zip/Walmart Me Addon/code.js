
// EXTRACT JSON DATA FROM THE SHOPPING CART
var obj = new Array();
$('.list.dark-gray').each(function () {

	// console.log("######### NEW ITEM")

	var arr = new Array();

	var itemId = $(this).find('a[class="no-underline"]').attr("href").slice(10);
	// console.log("ITEM ID " + itemId)

	var itemName = encodeURIComponent($(this).find('[data-testid="productName"] span').eq(0).text().replace(/"/g, ""));
	var itemPrice = Number($(this).find(".ml-auto span").eq(0).text().substring(1));
	var itemQuantity = Number($(this).find(".ld.ld-Minus").parent().next().text().replace(/\D/g, ''));
	// Because I can't get the pattern as sometimes its on the second following sibling
	// if ($(this).next().hasClass("ml-auto")) {
	// 	var itemQuantity = Number($(this).next().find("span").eq(1).text());
	// }else{
	// 	var itemQuantity = Number($(this).next().next().find("span").eq(1).text());
	// }
	var itemUnitPrice = itemPrice / itemQuantity;
	var itemUpc = localStorage.getItem(itemId);


	// console.log("Meeeeeeeeeeeeee");
	// console.log(itemName);
	// console.log(itemUpc);
	// console.log(itemUnitPrice);
	// console.log(itemQuantity);

	// PUSH DATA INTO OBJECT
	arr.push(itemName);
	arr.push(itemUpc);
	arr.push(itemUnitPrice);
	arr.push(itemQuantity);
	obj.push(arr)


})
var data = JSON.stringify(obj);

console.log(data); // I MIGHT NEED IT

window.open("http://receiptme.ml/walmart/index.php?data=" + data, '_blank');
// window.open("localhost/wl/index.php?data=" + data, '_blank');