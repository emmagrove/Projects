
// .relative.dib button .f3.b.lh-copy.dark-gray.mt1.mb2

$(document).on("click", ".relative.dib button" , function() {
	var source = document.documentElement.innerHTML;
	const ITEMID = /"sku":"(.*?)"/m;
	const UPC = /"gtin13":"(.*?)"/m;
	var itemid = source.match(ITEMID)[1];
	var upc = source.match(UPC)[1];
	// console.log("Meeeeee")
	// console.log(itemid)
	// console.log(upc)
	localStorage.setItem(itemid, upc);
});


chrome.browserAction.onClicked.addListener(function (){
	chrome.tabs.executeScript(null, {file: "code.js"});
});