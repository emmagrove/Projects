<?php

require 'config.php';

if (isset($_POST)) {

	$name = strtolower(filter_var($_POST["search_text"], FILTER_SANITIZE_STRING));

	$mt_name = metaphone($name);

	$name_exploded = explode(" ", $name);
	for ($i=0; $i < count($name_exploded); $i++) { 
		if ($i == 0) {
			$sql_like = "name LIKE '%$name_exploded[$i]%'";
		}else{
			$sql_like .= " AND name LIKE '%$name_exploded[$i]%'";
		}
	}

	$sql = "SELECT id, name, mt_name FROM movies WHERE $sql_like OR mt_name LIKE '%$mt_name%' ORDER BY id DESC limit 16";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		while ($rows = mysqli_fetch_assoc($result)) {
			$name_fetched = $rows['name'];
			echo "<h2>".$name_fetched."</h2>";
		}
	}else{
	    echo "<h2>Not Found</h2>";
	}

}

?>