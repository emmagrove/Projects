<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Advanced Search Engine</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<link href="https://fonts.googleapis.com/css?family=Montserrat|Roboto&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/normalize.css">
	<script type="text/javascript" src="assets/js/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="assets/js/index.js"></script>
</head>
<body>

<input type="text" name="search" id="search" placeholder="Search">

<div id="search_section">
</div>

</body>
</html>