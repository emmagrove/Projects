-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 27, 2020 at 09:40 PM
-- Server version: 5.7.17-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ase`
--

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mt_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`id`, `name`, `mt_name`) VALUES
(1, 'The Green Mile', '0KRNML'),
(2, 'Throne of Blood', '0RNFBLT'),
(3, 'Jurassic Park', 'JRSKPRK'),
(4, 'Batman Begins', 'BTMNBJNS'),
(5, 'Goodfellas', 'KTFLS'),
(6, 'The Great Escape', '0KRTSKP'),
(7, 'Full Metal Jacket', 'FLMTLJKT'),
(8, 'The Deer Hunter', '0TRHNTR'),
(9, 'The Lion King', '0LNKNK'),
(10, 'Raging Bull', 'RJNKBL'),
(11, 'Unforgiven', 'UNFRJFN'),
(12, 'Toy Story', 'TSTR'),
(13, 'Shutter Island', 'XTRSLNT'),
(14, 'Braveheart', 'BRFHRT'),
(15, 'Papillon', 'PPLN'),
(16, 'Die Hard', 'THRT'),
(17, 'Groundhog Day', 'KRNTHKT'),
(18, 'The Elephant Man', '0LFNTMN'),
(19, 'Seven Samurai', 'SFNSMR'),
(20, 'Django Unchained', 'TJNKNXNT'),
(21, 'Inception', 'INSPXN'),
(22, 'Gladiator', 'KLTTR'),
(23, 'Inside Out', 'INSTT'),
(24, 'The Shining', '0XNNK'),
(25, 'Mary and Max', 'MRNTMKS'),
(26, 'Apocalypse Now', 'APKLPSN'),
(27, 'The Help', '0HLP'),
(28, 'Citizen Kane', 'STSNKN'),
(29, 'Star Wars', 'STRWRS'),
(30, 'Life of Brian', 'LFFBRN'),
(31, 'The Dark Knight', '0TRKKNFT'),
(32, 'The Prestige', '0PRSTJ'),
(33, 'Das Boot', 'TSBT'),
(34, 'Rear Window', 'RRWNT'),
(35, 'Reservoir Dogs', 'RSRFRTKS'),
(36, 'Spirited Away', 'SPRTTW'),
(37, 'Pulp Fiction', 'PLPFKXN'),
(38, 'Blade Runner', 'BLTRNR'),
(39, 'Before Sunrise', 'BFRSNRS'),
(40, 'Paths of Glory', 'P0SFKLR'),
(41, 'Toy Story 3', 'TSTR'),
(42, 'Interstellar', 'INTRSTLR'),
(43, 'Double Indemnity', 'TBLNTMNT'),
(44, 'Hotel Rwanda', 'HTLRWNT'),
(45, 'L.A. Confidential', 'LKNFTNXL'),
(46, 'The Gold Rush', '0KLTRX'),
(47, 'Trainspotting', 'TRNSPTNK'),
(48, 'Roman Holiday', 'RMNHLT'),
(49, 'Chinatown', 'XNTN'),
(50, 'The Apartment', '0PRTMNT'),
(51, 'Into the Wild', 'INT0WLT'),
(52, 'The Kissing Booth', '0KSNKB0'),
(53, 'Downfall', 'TNFL'),
(54, 'Oldeuboi', 'OLTB'),
(55, 'The Wages of Fear', '0WJSFFR'),
(56, 'La Haine', 'LHN'),
(57, 'Stand by Me', 'STNTBM'),
(58, 'Game Of Thrones', 'KMF0RNS'),
(59, 'Underground', 'UNTRKRNT'),
(60, 'Cool Hand Luke', 'KLHNTLK'),
(61, 'Incendies', 'INSNTS'),
(62, 'Barry Lyndon', 'BRLNTN'),
(63, 'The Pianist', '0PNST'),
(64, 'On the Waterfront', 'ON0WTRFRNT'),
(65, 'All About Eve', 'ALBTF'),
(66, 'V for Vendetta', 'FFRFNTT'),
(67, 'Paris, Texas', 'PRSTKSS'),
(68, 'Prisoners', 'PRSNRS'),
(69, 'A Beautiful Mind', 'ABTFLMNT'),
(70, 'Metropolis', 'MTRPLS'),
(71, 'Notorious', 'NTRS'),
(72, 'Sunset Blvd.', 'SNSTBLFT'),
(73, 'The Thing', '00NK'),
(74, 'Scarface', 'SKRFS'),
(75, 'Good Will Hunting', 'KTWLHNTNK'),
(76, 'Diabolique', 'TBLK'),
(77, 'The Wizard of Oz', '0WSRTFS'),
(78, 'The Terminator', '0TRMNTR'),
(79, 'Fight Club', 'FFTKLB'),
(80, 'The 400 Blows', '0BLS'),
(81, 'Cinema Paradiso', 'SNMPRTS'),
(82, 'Wild Strawberries', 'WLTSTRBRS'),
(83, 'The Big Lebowski', '0BKLBSK'),
(84, 'Relatos salvajes', 'RLTSSLFJS'),
(85, 'Infernal Affairs', 'INFRNLFRS'),
(86, '12 Years a Slave', 'YRSSLF'),
(87, 'Gone Girl', 'KNJRL'),
(88, 'Touch of Evil', 'TXFFL'),
(89, 'Rashômon', 'RXMN'),
(90, 'The General', '0JNRL'),
(91, 'City Lights', 'STLFTS'),
(92, 'Finding Nemo', 'FNTNKNM'),
(93, 'Vikings', 'FKNKS'),
(94, 'The Truman Show', '0TRMNX'),
(95, 'Sin City', 'SNST'),
(96, 'Whiplash', 'WPLX'),
(97, 'The Avengers', '0FNJRS'),
(98, 'The Seventh Seal', '0SFN0SL'),
(99, '12 Angry Men', 'ANKRMN'),
(100, 'The Big Sleep', '0BKSLP'),
(101, 'Monsters, Inc.', 'MNSTRSNK'),
(102, 'Donnie Darko', 'TNTRK'),
(103, 'Life Is Beautiful', 'LFSBTFL'),
(104, 'Kill Bill: Vol. 1', 'KLBLFL'),
(105, 'The Sixth Sense', '0SKS0SNS'),
(106, 'Gran Torino', 'KRNTRN'),
(107, 'Princess Mononoke', 'PRNSSMNNK'),
(108, 'Before Sunset', 'BFRSNST'),
(109, 'City of God', 'STFKT'),
(110, 'Forrest Gump', 'FRSTKMP'),
(111, 'The Hustler', '0HSTLR'),
(112, 'The Matrix', '0MTRKS'),
(113, 'American Beauty', 'AMRKNBT'),
(114, 'Taxi Driver', 'TKSTRFR'),
(115, 'The Third Man', '00RTMN'),
(116, 'The Godfather', '0KTF0R'),
(117, 'Casablanca', 'KSBLNK'),
(118, 'Amores Perros', 'AMRSPRS'),
(119, 'The Departed', '0TPRTT'),
(120, 'Dial M for Murder', 'TLMFRMRTR'),
(121, 'Bicycle Thieves', 'BSKL0FS'),
(122, 'La Strada', 'LSTRT'),
(123, 'High Noon', 'HFNN'),
(124, '3 Idiots', 'ITTS'),
(125, 'The Graduate', '0KRTT'),
(126, 'Annie Hall', 'ANHL'),
(127, 'Twelve Monkeys', 'TWLFMNKS'),
(128, 'Some Like It Hot', 'SMLKTHT'),
(129, 'The Intouchables', '0NTXBLS'),
(130, 'The Sting', '0STNK'),
(131, 'Modern Times', 'MTRNTMS');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `movies`
--
ALTER TABLE `movies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
