$(document).ready(function(){


$("#search").keyup(function(){
	var search_text = $(this).val();
	
	if ($(this).val().length >= 1) {
		var data = "search_text="+search_text;
		$.ajax({
			url : 'search.php',
			type : 'POST',
			data : data,
			success: function(response){
				$("#search_section").html(response);
			},
			complete : function(){}
		});
	}else{
		$("#search_section").empty();
	}
	
});


});