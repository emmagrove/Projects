<?php

$servername = "localhost";
$username = "root";
$password = "1234567890";
$dbname = "ase";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: ");
}

?>