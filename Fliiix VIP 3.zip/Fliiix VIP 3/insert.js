var src = $(".vjs-tech").attr("src");
var pageID = $(".borderless.smooth-go-to img").attr("id");

var player = chrome.extension.getURL("player.html");
$.ajax({
	url: player,
	success: function(result){
		document.write(result);
	},
	complete: function(){
		$('#video').attr('src', src);
		$('#video').attr('pageID', pageID);
		var spinner = chrome.extension.getURL("assets/img/spinner.png");
		$('.loading-spinner').attr('src', spinner);
	}
});