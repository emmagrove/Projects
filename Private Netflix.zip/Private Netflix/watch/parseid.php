<?php

function parseId($data){

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://vidcloud9.com' . $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

$result = curl_exec($ch);

preg_match('/<iframe src="\/\/vidnext\.net\/streaming\.php\?id=(.*?)&/', $result, $dataId);

curl_close($ch);

return $dataId[1];

}


?>