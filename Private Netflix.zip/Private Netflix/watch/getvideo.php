<?php

function getvideo($id){

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://vidnext.net/ajax.php?id=' . $id);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

$headers = array();
$headers[] = 'X-Requested-With: XMLHttpRequest';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);

$decode = json_decode($result, true);

curl_close($ch);

return $decode["source"][0]["file"];

}


?>