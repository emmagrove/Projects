<?php

include_once 'imdb.class.php';

if (isset($_GET["search"])) {


$keyword = $_GET["search"];

function scrape($keyword){
	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, 'https://vidcloud9.com/ajax-search.html?keyword=' . $keyword);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

	$headers = array();
	$headers[] = 'X-Requested-With: XMLHttpRequest';
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

	$result = stripslashes(curl_exec($ch));

	preg_match_all('/ss-title">(.*?)<\/a>/', $result, $dataTitle);
	preg_match_all('/<a href="(.*?)"/', $result, $dataLink);

	curl_close($ch);

	return array($dataTitle , $dataLink);
}

list($dataTitle , $dataLink) = scrape($keyword);


$bigData = "";
for ($i=0; $i < count($dataTitle[1]) ; $i++) { 
	if (count($dataTitle[1]) <= 1) {
		$IMDB = new IMDB($keyword);
	}else{
		$IMDB = new IMDB($dataTitle[1][$i]);
	}
	if ($IMDB->isReady) {
		$src = $IMDB->getPoster($sSize = 'perfect', $bDownload = false);
		$bigData .= '<a href="watch/index.php?q=' . $dataLink[1][$i] . '"><div><img src="' . $src . '" alt=""></div></a>';
	}
}

}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Private Netflix</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<link href="https://fonts.googleapis.com/css2?familyfamily=Open+Sans:wght@300;400;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/normalize.css">
	<script type="text/javascript" src="assets/js/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="assets/js/index.js"></script>
</head>
<body>

<img src="assets/img/logo.svg" class="logo" alt="">
<form action="" method="GET">
	<input type="text" class="search" id="search" name="search" placeholder="Search">
</form>

<div class="movies">
	<a href="#"><div>
		<img src="posters/v.jpg" alt="">
	</div></a>
	<a href="#"><div>
		<img src="posters/b.jpg" alt="">
	</div></a>
	<a href="#"><div>
		<img src="posters/m.jpg" alt="">
	</div></a>
	<a href="#"><div>
		<img src="posters/p.jpg" alt="">
	</div></a>
	<a href="#"><div>
		<img src="posters/c.jpg" alt="">
	</div></a>
	<a href="#"><div>
		<img src="posters/k.jpg" alt="">
	</div></a>
	<?php echo $bigData; ?>
</div>

</body>
</html>