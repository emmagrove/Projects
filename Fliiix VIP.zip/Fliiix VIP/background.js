chrome.browserAction.onClicked.addListener(function (){
	chrome.tabs.executeScript(null, {file: "insert.js"});
	setTimeout(function(){
		chrome.tabs.executeScript(null, {file: "assets/js/app.js"});
	}, 5000);
});
