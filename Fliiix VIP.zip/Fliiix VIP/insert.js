var src = $(".vjs-tech").attr("src");

var player = chrome.extension.getURL("player.html");
$.ajax({
	url: player,
	success: function(result){
		document.write(result);
	},
	complete: function(){
		$('#video').attr('src', src);
		var spinner = chrome.extension.getURL("assets/img/spinner.png");
		$('.loading-spinner').attr('src', spinner);
	}
});