<?php

// GET ALL THE ITEMS AS HTML AND PUSHING EVERY ITEM TO ITS item ARRAY
$items = "";
for ($i=0; $i < count($json); $i++) { 
    $itemDiv = '<div class="item">';
    $itemDiv .= '<span class="item-name receipt-text">' . namegen($json[$i][0]) . '</span>';
    $itemDiv .= '<span class="item-upc receipt-text">' . $json[$i][1] . '&nbsp;&nbsp;F</span>';
    $itemDiv .= '<span class="item-price receipt-text">' . pricegen($json[$i][2]) . '</span>';
    $itemDiv .= '</div>';
    for ($j=0; $j < $json[$i][3]; $j++) { 
        $items .= $itemDiv;
    }
}

// FUNCTION TO GENERATE RECEIPT ITEM NAME
function namegen($name){

    $specialChars = array("?", "[", "]", "/", "\\", "=", "<", ">", ":", ";", ",", "'", "\"", "&", "$", "#", "*", "(", ")", "|", "~", "`", "!", "{", "}");
    $specialCharsFilter = str_replace($specialChars, '', $name);

    $pieces = explode(" ", $specialCharsFilter);
    $oneWord = $pieces[0];
    $twoWords = $pieces[0] . " " . $pieces[1];
    if (strlen($oneWord) >= 7) {
        return $oneWord;
    }else if (strlen($twoWords) <= 14) {
        return $twoWords;
    }else if (strlen($twoWords) > 14) {
        $specialLetters = array("a", "i", "e", "o");
		$specialLettersFilter = str_replace($specialLetters, '', $twoWords);
        return $specialLettersFilter;
    }
}

// FUNCTION TO ADD TWO ZEROS AT THE START AND REMOVE TWO NUMBERS FROM THE END
function upcgen($upc){
    $lastTwo = substr($upc, 0, -2);
    return "00" . $lastTwo;
}

// FORMAT PRICE TO TWO DECIMAL PLACES
function pricegen($price){
    return number_format((float)$price, 2, '.', '');
}


// SALES
// EXTRACT THE SUBTOTAL PRICE
$subtotalPrice = null;
for ($i=0; $i < count($json); $i++) { 
    $subtotalPrice += $json[$i][2] * $json[$i][3];
}
$totalPrice = pricegen($subtotalPrice);

$itemsSold = null;
for ($i=0; $i < count($json); $i++) { 
    $itemsSold += $json[$i][3];
}