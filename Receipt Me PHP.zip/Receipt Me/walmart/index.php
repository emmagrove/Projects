<?php

header('Access-Control-Allow-Origin: *');

if (isset($_GET["data"])) {
    $json = json_decode($_GET["data"], 1);
    require 'backend.php';
    date_default_timezone_set("America/New_York");
}else{
    echo "Nothing to see here!";
    return;
}

ob_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <base href="../">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt Me</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<center>
        <div class="receipt-paper">
            <img src="assets/img/walmartReceiptLogo.png" alt="">
            <p class="city-number receipt-text">617-745-4390 Mgr:ERNEST</p>
            <p class="expiry receipt-text">301 FALLS BLVD</p>
            <p class="expiry receipt-text">QUINCY MA 02169</p>
            <p class="expiry receipt-text">ST# 02341 OP# 009047 TE# 47 TR# 06292</p>
            <div class="items">
                <?php echo $items; ?>
            </div>
            <div class="sales">
                <div class="subtotal">
                    <span class="subtotal-text receipt-text">SUBTOTAL</span>
                    <span class="subtotal-number receipt-text"><?php echo $totalPrice; ?></span>
                </div>
                <div class="total">
                    <span class="total-text receipt-text">TOTAL</span>
                    <span class="total-number receipt-text"><?php echo $totalPrice; ?></span>
                </div>
                <div class="payment-method">
                    <span class="payment-method-text receipt-text">DISCV TEND</span>
                    <span class="payment-method-number receipt-text"><?php echo $totalPrice; ?></span>
                </div>
            </div>
            <div class="bottomlines">
                <p class="receipt-text leftAlign textTransformNone nowrap">Discover Credit&nbsp;&nbsp;&nbsp;&nbsp;**** **** **** 8802 I 1</p>
                <p class="receipt-text leftAlign">APPROVAL # 02194R</p>
                <p class="receipt-text leftAlign">REF # 120200575775</p>
                <p class="receipt-text leftAlign">AID A0000001324013</p>
                <p class="receipt-text leftAlign">AAC 032829321f90c55f</p>
                <p class="receipt-text leftAlign">TERMINAL # 19217622</p>
                <p class="receipt-text centerAlign"><?php echo date('m/d/y'); ?> <?php echo date("h:i:s"); ?></p>
                <p class="receipt-text rightAlign">CHANGE DUE 0.00</p>
                <p class="receipt-text centerAlign"># ITEMS SOLD <?php echo $itemsSold; ?></p>
                <p class="receipt-text centerAlign">TC# 6343 8593 9482 0238 1298</p>
                <img src="assets/img/barcode.png" alt="" class="barcode">
                <p class="receipt-text centerAlign textTransformNone">Low Prices You can Trust. Every Day.</p>
                <p class="receipt-text centerAlign"><?php echo date('m/d/y'); ?> <?php echo date("h:i:s"); ?></p>
                <p class="receipt-text centerAlign">***CUSTOMER COPY***</p>
            </div>
        </div>
    </center>
</body>
</html>
<?php
    $my_var = ob_get_clean();
    $filename = date('m-d-Y') . " - " . date("h-i A") . " - $" . $totalPrice . ".html";
    file_put_contents('receipts/' . $filename, $my_var);
    $receiptUrl = "receipts/" . $filename;
    header("Location: $receiptUrl");
?>