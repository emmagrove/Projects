<?php


class Tmdb {

	public $imdbID;
	public $result;
	public $tmdbID;

	function __construct($imdbID){

		$this->imdbID = $imdbID;
		$this->result = $this->getResult();
		$this->tmdbID = $this->result->movie_results[0]->id;

	}

	// GET RESULT FROM TMDB API
	public function getResult(){
		$url = "https://api.themoviedb.org/3/find/" . $this->imdbID . "?api_key=2928752078efeffe366313412b4a5c1e&language=en-US&external_source=imdb_id";

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

		$result = curl_exec($ch);
		curl_close($ch);

		return json_decode($result);
	}


	// GET POSTER
	public function getPoster(){
		return $this->result->movie_results[0]->poster_path;
	}

	// GET BACKDROP
	public function getBackdrop(){
		return $this->result->movie_results[0]->backdrop_path;
	}

	// GET TRAILER
	public function getTrailer(){
		$url = "https://api.themoviedb.org/3/movie/" . $this->tmdbID . "/videos?api_key=2928752078efeffe366313412b4a5c1e&language=en-US";

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

		$result = json_decode(curl_exec($ch));
		curl_close($ch);

		return $result->results[0]->key;
	}

}


$tmdb = new Tmdb('tt3907584');

echo $tmdb->getPoster() . "<br>";
echo $tmdb->getBackdrop() . "<br>";
echo $tmdb->getTrailer() . "<br>";


?>