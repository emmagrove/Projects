<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>iDesignator</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&family=Poppins:wght@200;300;400&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/normalize.css">
	<link rel="stylesheet" type="text/css" href="assets/css/animate.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/burger.css">
	<link rel="stylesheet" type="text/css" href="assets/css/morphext.css">
	<link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css">
</head>
<body>

<div id="sidebar">
	<div id="sidebar_section">
		<div id="sidebar_item">
			<svg id="sidebar_svg"><use xlink:href="assets/img/vectors.svg#home" xmlns:xlink="http://www.w3.org/1999/xlink"></use></svg>
			<span id="sidebar_span">HOME</span>
		</div>
		<div id="sidebar_item">
			<svg id="sidebar_svg"><use xlink:href="assets/img/vectors.svg#me" xmlns:xlink="http://www.w3.org/1999/xlink"></use></svg>
			<span id="sidebar_span">ABOUT ME</span>
		</div>
		<div id="sidebar_item">
			<svg id="sidebar_svg"><use xlink:href="assets/img/vectors.svg#services" xmlns:xlink="http://www.w3.org/1999/xlink"></use></svg>
			<span id="sidebar_span">SERVICES</span>
		</div>
		<div id="sidebar_item">
			<svg id="sidebar_svg"><use xlink:href="assets/img/vectors.svg#clients" xmlns:xlink="http://www.w3.org/1999/xlink"></use></svg>
			<span id="sidebar_span">Clients & Reviews</span>
		</div>
		<div id="sidebar_item">
			<svg id="sidebar_svg"><use xlink:href="assets/img/vectors.svg#pricing" xmlns:xlink="http://www.w3.org/1999/xlink"></use></svg>
			<span id="sidebar_span">PRICING PLANS</span>
		</div>
		<div id="sidebar_item">
			<svg id="sidebar_svg"><use xlink:href="assets/img/vectors.svg#contact" xmlns:xlink="http://www.w3.org/1999/xlink"></use></svg>
			<span id="sidebar_span">CONTACT</span>
		</div>
	</div>
</div>

<div class="burger burger-squeeze">
	<div class="burger-lines"></div>
</div>

<div id="landing">
	<div id="landing_section">
		<img src="assets/img/pic.jpg" id="landing_avatar" alt="">
		<h5 id="landing_hi">HI THERE !</h5>
		<span id="landing_who_am_i">I'm <span id="who_am_i">Mohammed, a UI/UX Designer, a Full Stack Dev</span></span>
		<div id="landing_buttons">
			<span id="landing_hire_me" to="to_plans">Hire Me</span>
			<span id="landing_about_me" to="to_about_me">About Me</span>
		</div>
	</div>
	<div id="scroll_down" to="to_about_me"></div>
	<div id="bubbles_container"></div>
</div>

<div id="container">

	<h2 class="general_title" id="to_about_me">ABOUT ME</h2>
	<div id="about_me">
		<div id="about_me_info">
			<img src="assets/img/profile.jpg" alt="Mohammed Yacouty" id="about_me_info_img">
			<div id="about_me_info_sub">
				<div id="about_me_info_text">I am Mohammed Yacouty, Creative designer and developer from Norway, I have been building UI/UX designs and websites for years, Which comply with the latest design trends. I love simplicity in things and crafts beautiful user interfaces with love.</div>
				<span id="about_me_info_btn">DOWNLOAD CV</span>
			</div>
		</div>
		<div id="about_me_facts">
			<div id="fact_item">
				<svg id="fact_icon"><use xlink:href="assets/img/vectors.svg#completed" xmlns:xlink="http://www.w3.org/1999/xlink"></use></svg>
				<section>
					<p id="fact_num" class="fact_num">219</p>
					<p id="fact_title">Completed Projects</p>
				</section>
			</div>
			<div id="fact_item">
				<svg id="fact_icon"><use xlink:href="assets/img/vectors.svg#clock" xmlns:xlink="http://www.w3.org/1999/xlink"></use></svg>
				<section>
					<p id="fact_num" class="fact_num">4275</p>
					<p id="fact_title">Working Hours</p>
				</section>
			</div>
			<div id="fact_item">
				<svg id="fact_icon"><use xlink:href="assets/img/vectors.svg#happy" xmlns:xlink="http://www.w3.org/1999/xlink"></use></svg>
				<section>
					<p id="fact_num" class="fact_num">325</p>
					<p id="fact_title">Happy Clients</p>
				</section>
			</div>
			<div id="fact_item">
				<svg id="fact_icon"><use xlink:href="assets/img/vectors.svg#coffee" xmlns:xlink="http://www.w3.org/1999/xlink"></use></svg>
				<section>
					<p id="fact_num" class="fact_num">280</p>
					<p id="fact_title">Cup of coffee</p>
				</section>
			</div>
		</div>
	</div>

	<h2 class="general_title second_title">SKILLS</h2>
	<div id="skills">
		<div id="skill_item">
			<p id="skill_title">UI/UX DESIGN</p>
			<p id="skill_progress_value">86%</p>
			<div id="skill_progress"></div>
		</div>
		<div id="skill_item">
			<p id="skill_title">HTML5 & CSS3</p>
			<p id="skill_progress_value">97%</p>
			<div id="skill_progress"></div>
		</div>
		<div id="skill_item">
			<p id="skill_title">JAVASCRIPT</p>
			<p id="skill_progress_value">82%</p>
			<div id="skill_progress"></div>
		</div>
		<div id="skill_item">
			<p id="skill_title">JQUERY</p>
			<p id="skill_progress_value">95%</p>
			<div id="skill_progress"></div>
		</div>
		<div id="skill_item">
			<p id="skill_title">PHP</p>
			<p id="skill_progress_value">88%</p>
			<div id="skill_progress"></div>
		</div>
		<div id="skill_item">
			<p id="skill_title">MYSQL</p>
			<p id="skill_progress_value">80%</p>
			<div id="skill_progress"></div>
		</div>
	</div>

	<h2 class="general_title second_title">SERVICES</h2>
	<div id="services">
		<div id="service_item">
			<img src="assets/img/services_creative.svg" id="service_icon" alt="">
			<h3 id="service_title">Creative Design</h3>
			<p id="service_details">We create more than just pretty interfaces, We amalgamate beauty with functionality.</p>
		</div>
		<div id="service_item">
			<img src="assets/img/services_responsive.svg" id="service_icon" alt="">
			<h3 id="service_title">Fully Responsive</h3>
			<p id="service_details">Your website will adapt to the size of any screen.</p>
		</div>
		<div id="service_item">
			<img src="assets/img/services_seo.svg" id="service_icon" alt="">
			<h3 id="service_title">SEO Friendly</h3>
			<p id="service_details">Our websites are built with the right tools and techniques to help your website rank higher.</p>
		</div>
		<div id="service_item">
			<img src="assets/img/services_optimization.svg" id="service_icon" alt="">
			<h3 id="service_title">Speed Optimization</h3>
			<p id="service_details">Your website will be fine-tuned to load as quickly as possible.</p>
		</div>
		<div id="service_item">
			<img src="assets/img/services_delivery.svg" id="service_icon" alt="">
			<h3 id="service_title">Fast Delivery</h3>
			<p id="service_details">Our experience allows us to deliver the website in a timely and quality manner.</p>
		</div>
		<div id="service_item">
			<img src="assets/img/services_support.svg" id="service_icon" alt="">
			<h3 id="service_title">Top Notch Support</h3>
			<p id="service_details">We love our customers! We provide professional support whenever you need a hand.</p>
		</div>
	</div>

	<h2 class="general_title second_title">Clients & Reviews</h2>
	<div id="reviews" class="owl-carousel">
		<div id="review_item">
			<img src="assets/img/client1.jpg" id="review_profile" alt="">
			<h3 id="review_name">Iskra Lawrence</h3>
			<p id="review_details">Awesome experience working with them! Very fast to respond and made sure my website was 100% perfect before handing it over to me! Will definitely work with them in the future!</p>
		</div>
		<div id="review_item">
			<img src="assets/img/client2.jpg" id="review_profile" alt="">
			<h3 id="review_name">Emma Grove</h3>
			<p id="review_details">Working with iDesignator was very enjoyable. They built a very nice product, answered all of my questions throughout the entire project and went above and beyond in design and implementation. I'am very satisfied and would use them again.</p>
		</div>
		<div id="review_item">
			<img src="assets/img/client3.jpg" id="review_profile" alt="">
			<h3 id="review_name">Eliza Taylor</h3>
			<p id="review_details">The work was done well within the timeframe, communication was great, and would definitely recommend.</p>
		</div>
	</div>

	<h2 class="general_title second_title" id="to_plans">PRICING PLANS</h2>
	<div id="plans">
		<div id="plan_item" class="first_plan">
			<h2 id="plan_title">Basic</h2>
			<p id="plan_for_who">Ideal solution for beginners</p>
			<h3 id="plan_price">80</h3>

			<div id="plan_details_section">
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">1 Page</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">Responsive Design</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">SEO & Speed Optimisation</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/close.svg" alt="">
					<span id="plan_text">Contect Upload</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/close.svg" alt="">
					<span id="plan_text">Carousel Slider</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/close.svg" alt="">
					<span id="plan_text">Google Map Integration</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/close.svg" alt="">
					<span id="plan_text">Google Analytics</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/close.svg" alt="">
					<span id="plan_text">Contact Form</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">1 Revision</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">5 Days Delivery</span>
				</div>
			</div>
			<span class="plan_btn">GET STARTED</span>
		</div>


		<div id="plan_item" class="popular_plan">
			<div id="popular_banner">MOST POPULAR</div>
			<h2 id="plan_title">Standard</h2>
			<p id="plan_for_who">Great for startup businesses</p>
			<h3 id="plan_price">120</h3>

			<div id="plan_details_section">
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">3 Pages</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">Responsive Design</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">SEO & Speed Optimisation</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/close.svg" alt="">
					<span id="plan_text">Contect Upload</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">Carousel Slider</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/close.svg" alt="">
					<span id="plan_text">Google Map Integration</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/close.svg" alt="">
					<span id="plan_text">Google Analytics</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">Contact Form</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">5 Revisions</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">7 Days Delivery</span>
				</div>
			</div>
			<span class="plan_btn active">GET STARTED</span>
		</div>


		<div id="plan_item" class="last_plan">
			<h2 id="plan_title">Premium</h2>
			<p id="plan_for_who">Perfect for businesses</p>
			<h3 id="plan_price">200</h3>

			<div id="plan_details_section">
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">7 Pages</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">Responsive Design</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">SEO & Speed Optimisation</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">Contect Upload</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">Carousel Slider</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">Google Map Integration</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">Google Analytics</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">Contact Form</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">Unlimited Revisions</span>
				</div>
				<div id="plan_details">
					<img src="assets/img/tick.svg" alt="">
					<span id="plan_text">10 Days Delivery</span>
				</div>
			</div>
			<span class="plan_btn">GET STARTED</span>
		</div>
	</div>

	<div id="custom_job">Looking for a custom job? <span to="to_contact">Click here</span> to contact me! 👋</div>

	<h2 class="general_title second_title" id="to_contact">CONTACT US</h2>
	<div id="dont_lik_forms">Don't like forms? Mail me at: <a href="mailto:contact@idesignator.com" target="_blank">contact@idesignator.com</a>. 👋</div>
	<div id="contact">
		<div>
			<input type="text" id="name" placeholder="Name">
			<p id="input_error">Please enter a valid name.</p>
		</div>
		<div>
			<input type="email" id="email" placeholder="Email">
			<p id="input_error">Please enter a valid email address.</p>
		</div>
		<div id="msg_section">
			<textarea id="msg" placeholder="Message"></textarea>
			<p id="input_error"></p>
		</div>
		<button id="contact_btn">SEND MESSAGE</button>
	</div>

</div>

<div id="contact_popup">
	<div id="popup_section">
		<svg id="popup_close"><use xlink:href="assets/img/vectors.svg#popup_close" xmlns:xlink="http://www.w3.org/1999/xlink"></use></svg>
		<img src="assets/img/paper_plane.svg" alt="">
		<h2>Thank You!</h2>
		<span>Your message has been submitted. We will be in touch shortly.</span>
	</div>
</div>

<footer>© 2020 iDesignator. All rights reserved.</footer>

<script type="text/javascript" src="assets/js/jquery-3.4.1.min.js"></script>
<script type="text/javascript" src="assets/js/morphext.min.js"></script>
<script type="text/javascript" src="assets/js/owl.carousel.min.js"></script>
<script type="text/javascript" src="assets/js/particles.min.js"></script>
<script type="text/javascript" src="assets/js/app.js"></script>
<script type="text/javascript" src="assets/js/jquery.waypoints.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.counterup.min.js"></script>
<script type="text/javascript" src="assets/js/validator.js"></script>
<script type="text/javascript" src="assets/js/index.js"></script>
</body>
</html>