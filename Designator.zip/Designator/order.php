<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>iDesignator - Order</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&family=Poppins:wght@200;300;400&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/order.css">
	<link rel="stylesheet" type="text/css" href="assets/css/normalize.css">
	<link rel="stylesheet" type="text/css" href="assets/css/animate.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/burger.css">
	<link rel="stylesheet" type="text/css" href="assets/css/morphext.css">
	<link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css">
</head>
<body>

<div id="order">
	<h1 id="order_title">You're almost there! Complete your order</h1>
	<div id="input_section">
		<label id="input_label" for="website_name">What's your website name?</label>
		<input type="text" name="XXX" class="default_input" id="website_name" placeholder="Enter your email.">
	</div>
	<div id="input_section">
		<label id="input_label" for="website_name">What's your website topic?</label>
		<textarea class="default_input textarea" placeholder="What's your website topic?"></textarea>
	</div>
	<div id="input_section">
		<label id="input_label" for="website_name">What's your email?</label>
		<input type="text" name="XXX" class="default_input" id="website_name" placeholder="Enter your email.">
	</div>
	<div id="input_section">
		<label id="input_label" for="website_name">What's your email?</label>
		<input type="text" name="XXX" class="default_input" id="website_name" placeholder="Enter your email.">
	</div>

	<div id="input_section">
		<label id="input_label" for="website_name">What's your email?</label>
		<textarea class="default_input textarea" placeholder="What's your email?"></textarea>
	</div>

	<div id="input_section">
		<button id="order_btn">PLACE ORDER</button>
	</div>

</div>

</body>
</html>