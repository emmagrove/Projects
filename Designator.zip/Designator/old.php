<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>iDesignator - Order</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&family=Poppins:wght@200;300;400&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/order.css">
	<link rel="stylesheet" type="text/css" href="assets/css/normalize.css">
	<link rel="stylesheet" type="text/css" href="assets/css/animate.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/burger.css">
	<link rel="stylesheet" type="text/css" href="assets/css/morphext.css">
	<link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css">
</head>
<body>

<div id="steps">
	<div id="first_step" class="step">1</div>
	<div id="second_step" class="step inactive_step">2</div>
	<div id="second_progess" class="inactive_progress"></div>
	<div id="third_step" class="step inactive_step">3</div>
	<div id="third_progess" class="inactive_progress"></div>
</div>


<div id="navbottom">
	<span id="cancel">Cancel</span>
	<div id="steps_buttom">
		<div id="previous_btn">
			<img src="assets/img/arrow_left.svg" class="arrow" alt="">
			<span id="previous_text">Previous step</span>
		</div>
		<div id="next_btn">
			<span id="next_text">Next step</span>
			<img src="assets/img/arrow_right.svg" class="arrow" alt="">
		</div>
	</div>
</div>

</body>
</html>