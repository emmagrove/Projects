<?php

session_start();

if (!isset($_SESSION["valid"])) {
	header('Location: login.php');
	exit;
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Models - Puremeon</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;600&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/css/models.css">
	<link rel="stylesheet" type="text/css" href="assets/css/normalize.css">
	<script type="text/javascript" src="assets/js/jquery-3.6.3.min.js"></script>
	<script type="text/javascript" src="assets/js/index.js"></script>
</head>
<body>

<form action="db.php" method="post" enctype="multipart/form-data">
<div class="models">
	<div class="profiles">
		<div class="profiles-model">
			<div class="model-circle">
				<img src="profiles/mainprofile.jpeg" class="model-picture" alt="">
				<img src="assets/img/add.svg" class="model-add" alt="">
			</div>
			<span class="model-name">Me</span>
			<input type="file" name="model_profile" class="model-profile-input" accept="image/*">
		</div>
		<?php
		require 'config.php';
		$result = $conn->query("SELECT * FROM models ORDER BY name");
		if ($result->num_rows > 0) {
			$models = "";
			while($row = $result->fetch_assoc()) {
				$model_name = $row["name"];
				$model_name_exploded = explode(" ", $model_name);
				$model_first_name = reset($model_name_exploded);
				$models .= '<div class="profiles-model" modelid="' . $row["id"] . '" modelname="' . $model_name . '"><div class="model-circle"><img src="profiles/' . $row["profile"] . '" class="model-picture" alt=""><svg viewbox="0 0 100 100"><circle cx="50" cy="50" r="40"/></svg></div><span class="model-name">' . $model_first_name . '</span></div>';
			}
			echo $models;
		}
		?>
		
<!-- 	<div class="profiles-model">
			<div class="model-circle">
				<img src="assets/img/hazel.jpeg" class="model-picture" alt="">
				<svg viewbox="0 0 100 100"><circle cx="50" cy="50" r="40"/></svg>
			</div>
			<span class="model-name">Jordan</span>
		</div> -->

	</div>
</div>

<input type="hidden" name="is_new_model" class="is_new_model">
<input type="hidden" name="model_id" class="model_id">

<input type="text" name="model_name" class="model-name-input" placeholder="Model Name" disabled>
<div class="model-picture-upload">
	<input type="file" name="model_picture" class="model-picture-input" accept="image/*">
	<img src="assets/img/square-add.svg" class="model-picture-add-svg" alt="">
</div>


<div class="preview">
	<div class="preview-header">
		<img src="" class="preview-header-profile" alt="" onerror='this.style.display = "none"'>
		<span class="preview-header-name"></span>
	</div>
	<img src="" class="preview-image-picture" alt="">
</div>


<button type="submit" class="add-model">ADD MODEL</button>
</form>

</body>
</html>