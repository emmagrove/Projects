<?php

require 'config.php';


if (isset($_POST["is_new_model"])) {


// If new model => get name and profile || If old model => get model id && model total pictures
if ($_POST["is_new_model"] == "yes") {
	// Model name
	$model_name 			= strtolower($_POST["model_name"]);
	$model_name_2 			= str_replace(" ", "_", $model_name);
	$model_name_3			= preg_replace("/[^a-zA-Z0-9]+/", "", $model_name_2);
	$the_model_name			= $model_name_3;

	// Model profile
	$profile_name			= $_FILES['model_profile']['name'];
	$profile_tmp 			= $_FILES['model_profile']['tmp_name'];
	$profile_ext			= explode('.', $profile_name);
	$profile_ext			= strtolower(end($profile_ext));
	$model_profile			= $model_name_3 . "." . $profile_ext;

	$profile_check = getimagesize($profile_tmp);
	if ($profile_check !== false) {
		move_uploaded_file($profile_tmp, "profiles/" . $model_profile);
	}else{
		header('Location: https://www.google.com/');
		exit;
	}

	// Insert models info - name and profile
	$conn->query("INSERT INTO models VALUES (NULL, '$model_name', '$model_profile')");
	$model_id 				= $conn->insert_id;
	$model_total_pictures 	= 0;
}else{
	$model_id 				= intval($_POST["model_id"]);
	// Get the model name
	$model_name_result 		= $conn->query("SELECT profile FROM models WHERE id='$model_id'");
	$model_name_fetch		= $model_name_result->fetch_assoc();
	$model_name_sql_1		= explode(".", $model_name_fetch["profile"]);
	$the_model_name			= reset($model_name_sql_1);
	// Count pictures number of an old model
	$model_total_result 	= $conn->query("SELECT COUNT(*) FROM pictures WHERE mid='$model_id'");
	$model_total_pics_fetch	= $model_total_result->fetch_assoc();
	$model_total_pictures	= $model_total_pics_fetch['COUNT(*)'];
}




// Model picture
// Get picture extension
$picture_name			= $_FILES['model_picture']['name'];
$picture_tmp 			= $_FILES['model_picture']['tmp_name'];
$picture_ext			= explode('.', $picture_name);
$picture_ext			= strtolower(end($picture_ext));
// Create a name for the uploaded picture
$model_picture			= $the_model_name . "_" . $model_total_pictures + 1 . "_" . rand(1000,9999) . "." . $picture_ext;

$picture_check = getimagesize($picture_tmp);
if ($picture_check !== false) {
	move_uploaded_file($picture_tmp, "pictures/" . $model_picture);
}else{
	header('Location: https://www.google.com/');
	exit;
}


$conn->query("INSERT INTO pictures VALUES (NULL, $model_id, '$model_picture')");

header('Location: index.php');
exit;

// if module name is empty it means module is already in
// in that case only a mid and picture will be submited
// mid will be gotten from model id
// its either and model name or a model id


}



// Remove post
if ($_POST["postid"]) {
	// Remove data from database
	$postid = intval($_POST["postid"]);
	$conn->query("DELETE FROM pictures WHERE id='$postid'");
	// Delete the picture
	$picturelocation = $_POST["picturelocation"];
	unlink("pictures/" . $picturelocation);
}


?>