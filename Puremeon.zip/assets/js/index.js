$(document).ready(function(){

//********** INDEX **********//

// Show option when post option clicked
var optionedPost = "";
$('.post-header-options').click(function(){
	optionedPost = $(this).parent().parent();
	$(".options-popup").css('display', 'flex').hide().fadeIn(100);
});

// Fade out popup
$('.options-popup-cancel').click(function(){
	$(".options-popup").fadeOut(300);
});

// Delete post stimualtion
$('.delete-this-post').click(function(){
	// Remove post visually
	$(optionedPost).fadeOut(300);
	$(optionedPost).remove();
	$(".options-popup").fadeOut(300);
	// Remove post on server side
	var postid = $(optionedPost).attr("postid");
	var picturelocation = $(optionedPost).attr("picturelocation");
	$.ajax({
		url : 'db.php',
		type : 'POST',
		data : {
			'postid' : postid,
			'picturelocation' : picturelocation
		},
		success: function(response){}
	});

});



//********** NEW **********//

// Choose model
$("[modelid]").on('click', function () {
	$(".model-circle svg").fadeOut(200);
	$(this).find("svg").fadeIn(200);
	var modelID = $(this).attr("modelid");
	var modelName = $(this).attr("modelname");
	var modelProfile = $(this).find(".model-picture").attr("src");
	$(".model_id").val(modelID);
	$(".model-name-input").val(modelName);
	$(".preview-header-profile").attr("src", modelProfile).fadeIn(200);
	$(".preview-header-name").text(modelName);
	// Disable model name input
	$(".model-name-input").attr("disabled", "");
	// Clear profile input
	$(".model-profile-input").val("");
	// Set as not a new model
	$(".is_new_model").val("no");
});


// Preview model profile
$(".model-profile-input").on('change', function () {
	// Clear model cirlce
	$(".model-circle svg").fadeOut(200);
	const file = this.files[0];
	if (file && file['type'].split('/')[0] === 'image'){
		let reader = new FileReader();
		reader.onload = function(event){
			$('.preview-header-profile').attr('src', event.target.result).fadeIn(200);
			$(".model-name-input").val("");
			$(".preview-header-name").text("");
			$(".model-name-input").removeAttr("disabled");
			$(".is_new_model").val("yes");
		}
		reader.readAsDataURL(file);
	}else{
		alert("Not an Image")
	}
});


// Preview model name
var modelName = "";
$(".model-name-input").on('input', function () {
	modelName = $(".model-name-input").val();
	$(".preview-header-name").text(modelName);
});


// Preview model picture
$(".model-picture-input").on('change', function () {
	const file = this.files[0];
	if (file && file['type'].split('/')[0] === 'image'){
		let reader = new FileReader();
		reader.onload = function(event){
			$('.preview-image-picture').attr('src', event.target.result).fadeIn(200);
		}
		reader.readAsDataURL(file);
	}else{
		alert("Not an Image")
	}
});


});


