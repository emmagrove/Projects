$(document).ready(function(){


// Handle focus => be able to choose a box and edit it
$(".code-box").on("focus", function(e){
	if (e.target.value) {
		e.target.select();
	}
});

// Nothing much just making sure box is on focus when clicked
$(".code-box").on("click", function(e){
	$(this).focus();
});

// Handle input
$(".code-box").on("input", function(e){
	if (e.target.value) {
		$(this).next().focus();
	}
	oneCode();
});

// Handle backspace
$(".code-box").on("keyup", function(e){
	if (e.keyCode == 8 && e.target.value == '') {
		$(this).prev().focus();
	}
});

// Handle verification code
function oneCode() {
	var oneCode = "";
	for (var i = 0; i < $(".code-box").length; i++) {
		var oneDigit = $(".code-box").eq(i).val();
		oneCode = oneCode + oneDigit;
	}
	$(".verficationcode").val(oneCode);
	if (oneCode.length == 4) {
		$("#codeform").submit();
	}
}


});


