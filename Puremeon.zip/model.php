<?php

session_start();

if (!isset($_SESSION["valid"])) {
	header('Location: login.php');
	exit;
}

require 'config.php';


$get_model_id = $_GET["id"];
$result = $conn->query("SELECT name FROM models WHERE models.id='$get_model_id'");
$row = $result->fetch_assoc();
$model_name = $row["name"];

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo ucwords($model_name); ?> - Puremeon</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;600&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/normalize.css">
	<script type="text/javascript" src="assets/js/jquery-3.6.3.min.js"></script>
	<script type="text/javascript" src="assets/js/index.js"></script>
</head>
<body>


<div class="navbar">
	<div class="profiles">
		<a href="models.php" class="profiles-model">
			<div class="model-circle">
				<img src="profiles/mainprofile.jpeg" class="model-picture" alt="">
				<img src="assets/img/add.svg" class="model-add" alt="">
			</div>
			<span class="model-name">Me</span>
		</a>


		<?php
		$result = $conn->query("SELECT * FROM models ORDER BY name");
		if ($result->num_rows > 0) {
			$models = "";
			while($row = $result->fetch_assoc()) {
				$model_id = $row["id"];
				$model_name = $row["name"];
				$model_name_exploded = explode(" ", $model_name);
				$model_first_name = reset($model_name_exploded);
				//Only put the model circle on the selected model
				if ($model_id != $get_model_id) {
					$models .= '<a href="model.php?id=' . $model_id . '" class="profiles-model"><div class="model-circle"><img src="profiles/' . $row["profile"] . '" class="model-picture" alt=""></div><span class="model-name">' . $model_first_name . '</span></a>';
				}else{
					$models .= '<a href="model.php?id=' . $model_id . '" class="profiles-model"><div class="model-circle"><img src="profiles/' . $row["profile"] . '" class="model-picture" alt=""><svg viewbox="0 0 100 100"><circle cx="50" cy="50" r="40"/></svg></div><span class="model-name">' . $model_first_name . '</span></a>';
				}
			}
			echo $models;
		}
		?>
<!-- 	<a href="#" class="profiles-model">
			<div class="model-circle">
				<img src="assets/img/hazel.jpeg" class="model-picture" alt="">
				<svg viewbox="0 0 100 100"><circle cx="50" cy="50" r="40"/></svg>
			</div>
			<span class="model-name">Jordan</span>
		</a> -->

	</div>
</div>

<div class="content">


		<?php
		require 'config.php';
		$result = $conn->query("SELECT models.name as name, models.profile as profile, pictures.picture as picture, pictures.id as post_id FROM models JOIN pictures ON models.id=pictures.mid WHERE models.id='$get_model_id' ORDER BY pictures.id DESC");
		if ($result->num_rows > 0) {
			$posts = "";
			while($row = $result->fetch_assoc()) {
				$post_id = $row["post_id"];
				$model_name = $row["name"];
				$model_profile = $row["profile"];
				$model_picture = $row["picture"];
				$posts .= '<div class="post" postid="' . $post_id . '" picturelocation="' . $model_picture . '"><div class="post-header"><img src="profiles/' . $model_profile . '" class="post-header-profile" alt=""><span class="post-header-name">' . $model_name . '</span><img src="assets/img/options.svg" class="post-header-options" alt=""></div><div class="post-image"><img src="pictures/' . $model_picture . '" class="post-image-picture" alt=""></div></div>';
			}
			echo $posts;
		}
		?>


<!-- 		<div class="post">
			<div class="post-header">
				<img src="assets/img/hazel1.webp" class="post-header-profile" alt="">
				<span class="post-header-name">Hazel Moore</span>
				<img src="assets/img/options.svg" class="post-header-options" alt="">
			</div>
			<div class="post-image">
				<img src="assets/img/hazel1.webp" class="post-image-picture" alt="">
			</div>
		</div> -->

</div>


<div class="options-popup">
	<div class="options-popup-box">
		<span class="delete-this-post">Delete</span>
		<span class="options-popup-cancel">Cancel</span>
	</div>
</div>


</body>
</html>