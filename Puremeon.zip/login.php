<?php

session_start();

if (isset($_SESSION["valid"])) {
	header('Location: index.php');
	exit;
}

$wrong = "no";

if ($_POST) {
	$verficationcode = strtolower($_POST["verficationcode"]);
	if ($verficationcode == "open") {
		$_SESSION["valid"] = true;
		header('Location: index.php');
		exit;
	}else{
		$wrong = "yes";
	}
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login - Puremeon</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;600&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/css/login.css">
	<link rel="stylesheet" type="text/css" href="assets/css/normalize.css">
	<script type="text/javascript" src="assets/js/jquery-3.6.3.min.js"></script>
	<script type="text/javascript" src="assets/js/login.js"></script>
</head>
<body>


<form action="" method="post" id="codeform">
<div class="content">
	<div class="profiles-model">
		<div class="model-circle">
			<img src="profiles/mainprofile.jpeg" class="model-picture" alt="">
			<svg viewbox="0 0 100 100"><circle cx="50" cy="50" r="40"/></svg>
		</div>
	</div>
	<h1 class="hold-on-a-second">Hold on a second!</h1>
	<div class="code">
		<input type="text" class="code-box code-box-1" maxlength="1">
		<input type="text" class="code-box code-box-2" maxlength="1">
		<input type="text" class="code-box code-box-3" maxlength="1">
		<input type="text" class="code-box code-box-4" maxlength="1">
	</div>
	<?php if ($wrong == "yes") { echo '<p class="invalid-code">Invalid code, please try again</p>'; } ?>
	<input type="hidden" name="verficationcode" class="verficationcode">
</div>
</form>


</body>
</html>