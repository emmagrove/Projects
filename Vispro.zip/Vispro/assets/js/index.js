$(document).ready(function(){

$("#MenuLogo").click(function(){
	$("#sideMenu").addClass("SidemenuActive");
	$("#overlay").show();
});
$(".sideMenuActive , #overlay").click(function(){
	$("#sideMenu").removeClass("SidemenuActive");
	$("#overlay").hide();
});

$("div[style='text-align: right;position: fixed;z-index:9999999;bottom: 0;width: auto;right: 1%;cursor: pointer;line-height: 0;display:block !important;']").hide();
});