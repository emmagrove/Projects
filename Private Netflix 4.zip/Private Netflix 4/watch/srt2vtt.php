<?php

function srt2vtt($srt){
	$lines = explode(PHP_EOL, $srt);

	$vtt = ["WEBVTT\n"];
	foreach ($lines as $line) {
		if (strpos($line, " --> ") !== false) {
			$line = str_replace(",", ".", $line);
		}
		$vtt[] = $line;
	}

	return implode("\n", $vtt);
}

?>