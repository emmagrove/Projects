<?php

require 'getSub.php';
require 'srt2vtt.php';

$src = "";

if (isset($_GET["m"]) && isset($_GET["i"])) {
	$src = "https://open-load.to/web-sources/mp4/0B778BA51E9B698D/" . htmlspecialchars($_GET["m"]) . "/1";
	$tracks = getSub($_GET["i"], "eng") . getSub($_GET["i"], "ara");
}


?>