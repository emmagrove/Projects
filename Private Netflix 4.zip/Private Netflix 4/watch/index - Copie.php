<?php

require 'getMovieDATA.php';

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Netflix</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/normalize.css">
	<script type="text/javascript" src="assets/js/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="assets/js/index.js"></script>
</head>
<body>

<div id="nayer">
	<video preload="metadata" class="video" id="video" poster="" preload="auto">
		<source src="<?php echo $src; ?>" type="video/mp4" id="videoPath"></source>
			<?php echo $tracks; ?>
	</video>

	<img src="assets/img/spinner.png" id="loading" alt="">

	<div id="playback-animation" class="playback-animation">
		<img src="assets/img/play.svg" id="play-animation" alt="">
		<img src="assets/img/pause.svg" id="pause-animation" alt="">
	</div>

	<div class="nayer-controls nayer-hide" id="nayer-controls">
	<!-- Custom controls are defined here -->

		<div id="seek-tooltip"></div>

		<div class="video-progress">
			<div id="progress-section">
				<input type="range" id="progress-range" value="0" min="0" max="100">
				<progress id="progress-bar" value="0" min="0" max="100"></progress>
				<div id="buffred"></div>		
			</div>
			<time id="duration">00:00</time>
		</div>

		<div id="bottom-controls">
			<div id="play-control" class="control-section">
				<img src="assets/img/play.svg" class="control-icon play-pause" id="play" alt="">
				<img src="assets/img/pause.svg" class="control-icon play-pause nayer-hide" id="pause" alt="">
			</div>
			<div id="rewind-control" class="control-section">
				<img src="assets/img/rewind.svg" class="control-icon" id="rewind" alt="">
			</div>
			<div id="forward-control" class="control-section">
				<img src="assets/img/forward.svg" class="control-icon" id="forward" alt="">
			</div>
			<div id="sound-control" class="control-section">
				<img src="assets/img/sound.svg" class="control-icon sound-mute" id="sound" alt="">
				<img src="assets/img/mute.svg" class="control-icon sound-mute nayer-hide" id="mute" alt="">
				<div id="volume-section"><input type="range" id="volume" value="1" step="0.01" min="0" max="1"></div>
			</div>
			<div id="fullscreen-control" class="control-section">
				<img src="assets/img/fullscreen.svg" class="control-icon full-low" id="fullscreen" alt="">
				<img src="assets/img/lowscreen.svg" class="control-icon full-low nayer-hide" id="lowscreen" alt="">
			</div>
		</div>


	</div>

</div><!-- Nayer -->

</body>
</html>