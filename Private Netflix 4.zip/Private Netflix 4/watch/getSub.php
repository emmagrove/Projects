<?php


########################################
# GET IMDB ID
# RETURN HTML TRACK
########################################

function getSub($imdbid, $lang){

	$imdb = substr($imdbid, 2);

	$url = "https://rest.opensubtitles.org/search/imdbid-" . $imdb . "/sublanguageid-" . $lang;

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	    'User-Agent: TemporaryUserAgent'//TemporaryUserAgent - explosiveskull
	));

	$result = curl_exec($ch);
	curl_close($ch);

	$jsonResult = json_decode($result, true);

	$resultCount = count($jsonResult);


	// GET SubLanguageID - LanguageName - SubFormat - subtitleContent {MAX: 3 Subtitles}
	if ($resultCount > 0) {
		$whileCounter = $trackCount = 0;
		$subLanguageID = $languageName = $subFormat = $subtitleContent = array();
		// Keep Running The Loop Till The Track Count Is Equal To 3
		while ($trackCount < 3) {

			// BREAK The While IF All The Results Have Been Checked
			if ($whileCounter == $resultCount) {
				break;
			}

			// SKIP This LOOP IF The Subtitle Format isn't SRT
			if ($jsonResult[$whileCounter]["SubFormat"] != "srt") {
				$whileCounter++;
				continue;
			}

			// GET THE REQUIRED DATA
			$subLanguageID[]	= $jsonResult[$whileCounter]["SubLanguageID"];
			$languageName[]		= $jsonResult[$whileCounter]["LanguageName"];
			$subtitleContent[]	= srt2vtt(gzdecode(file_get_contents($jsonResult[$whileCounter]["SubDownloadLink"])));

			$whileCounter++;
			$trackCount++;
		}
	}

	$subtitles = "";
	for ($i=1; $i <= count($subLanguageID); $i++) {
		$subFileName = '../Subtitles/' . $imdbid . '-' . $lang . '-' . $i . '.vtt';
		file_put_contents($subFileName, $subtitleContent[$i-1]);
		$subtitles .= '<track src="' . $subFileName .'" kind="subtitles" srclang="' . $subLanguageID[$i-1] . '" label="' . $languageName[$i-1] . ' ' . $i . '">';
	}

	return $subtitles;

}


?>