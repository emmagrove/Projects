$(document).ready(function(){


// HIDE THE NATIVE CONTROLS
const video = document.getElementById('video');
const videoControls = document.getElementById('nayer-controls');

const videoWorks = !!document.createElement('video').canPlayType;
if (videoWorks) {
  video.controls = false;
  videoControls.classList.remove('nayer-hide');
  $('#nayer-controls').show();
}


// MOBILE DEVICES
if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)){
	// TRUE FOR MOBILE DEVICE
	var mobile = true;
	//REMOVE SOUND CONTROL ON MOBILE DEVICES
	$('#sound-control').remove();

	//REMOVE SOUND CONTROL ON MOBILE DEVICES
	$('#vid_left , #vid_right').on('click', function() {
		if ($('#nayer-controls').is(':hidden')) {
			$('#nayer-controls').fadeIn(200);
		} else {
			$('#nayer-controls').fadeOut(200);
		}
	});


	// REWIND 10s
	$('#vid_left').dblclick(function() {
		var rewindedTime = Math.round(video.currentTime - 10);
		video.currentTime = rewindedTime;
	});

	// FORWARD 10s
	$('#vid_right').dblclick(function() {
		var forwardedTime = Math.round(video.currentTime + 10);
		video.currentTime = forwardedTime;
	});

}else{
	// FALSE FOR DESKTOP DEVICE
	var mobile = false;

	// FULLSCREEN LOWSCREEN DOUBLE CLICK
	$("#nayer").dblclick(function(e) {
		if ( !$(e.target).hasClass('control-icon') ) {
			fullLow();
		}
	});

	// CLICK THE VIDEO TO PLAY OR PAUSE IT
	$('#vid_left , #vid_right').on('click', function() {
		if (video.paused || video.ended) {
			video.play();
			toggleControl('#play , #pause-animation');
		} else {
			video.pause();
			toggleControl('#pause , #play-animation');
		}
		animatePlayback();
	});
}

// TOGGLE CONTROLS STATE
function toggleControl(thiiis){
	$(thiiis).addClass('nayer-hide');
	$(thiiis).siblings().removeClass('nayer-hide');
}

/* PLAYBACK ANIMATION */
function animatePlayback() {
 	$('#playback-animation')[0].animate([{opacity: 1, transform: "scale(1)"}, {opacity: 0, transform: "scale(1.4)"}], {duration: 500});
}


// VIDEO LOADING SPINNER
$('#video').on('loadstart seeking waiting', function() {
	$('#loading').fadeIn(100);
});
$('#video').on('canplay', function() {
	$('#loading').hide();
});


// VIDEO BUFFER
$('#video').on('progress', function() {
    var duration =  video.duration;
    if (duration > 0) {
      for (var i = 0; i < video.buffered.length; i++) {
            if (video.buffered.start(video.buffered.length - 1 - i) < video.currentTime) {
                $('#buffred').css('width', ((video.buffered.end(video.buffered.length - 1 - i) / duration) * 100) + '%');
                break;
            }
        }
    }
});


// HIDE THE CONTROLS WHEN NO ACTION
var timeout = null;
$('#nayer').on('mousemove', function() {
	clearTimeout(timeout);
	if($(".video-progress:hover , .control-section:hover").length != 0){
		return;
	}
	$(this).addClass('cursor-pointer');
    if (mobile === false) $('#nayer-controls').fadeIn(200);
	timeout = setTimeout(function() {
        $('#nayer').removeClass('cursor-pointer');
    	$('#nayer-controls').fadeOut(200);
    }, 2000);
}).mouseleave(function() {
    $('#nayer-controls').fadeOut(200);
});


// TOTAL VIDEO DURATION
var tvd;
$('#video').on('loadedmetadata', function() {

	const videoDuration = Math.round(video.duration);

	if (videoDuration <= 3599) {
		tvd = new Date(videoDuration * 1000).toISOString().substr(14, 5);
		$('#duration').text(tvd);
	}else{
		tvd = new Date(videoDuration * 1000).toISOString().substr(11, 8);
		$('#duration').text(tvd);
	}

	$('#progress-range , #progress-bar').attr('max', videoDuration);

});

// REMAINING TIME
$('#video').on('timeupdate', function() {
	const videoDuration = Math.round(video.duration);
	const currentTime = Math.round(video.currentTime);
	const remainingTimeSecond = Math.round(videoDuration - currentTime);

	// PROGRESS BAR
	$('#progress-range').val(currentTime);
	$('#progress-bar').val(currentTime);

	if (remainingTimeSecond <= 3599) {
		var remainingTime = new Date(remainingTimeSecond * 1000).toISOString().substr(14, 5);
		$('#duration').text(remainingTime);
	}else{
		var remainingTime = new Date(remainingTimeSecond * 1000).toISOString().substr(11, 8);
		$('#duration').text(remainingTime);
	}

});

// TOGGLE THE PLAYBACK STATE
function playPause(){
	if (video.paused || video.ended) {
		video.play();
		toggleControl('#play , #pause-animation');
	} else {
		video.pause();
		toggleControl('#pause , #play-animation');
	}
	animatePlayback();
}
$('.play-pause').on('click', function() {
	playPause();
});

$('#video').on('ended', function() {
	$('#pause').addClass('nayer-hide');
	$('#play').removeClass('nayer-hide');
});

// REWIND 10s
$('#rewind').on('click', function() {
	var rewindedTime = Math.round(video.currentTime - 10);
	video.currentTime = rewindedTime;
});

// FORWARD 10s
$('#forward').on('click', function() {
	var forwardedTime = Math.round(video.currentTime + 10);
	video.currentTime = forwardedTime;

});



// VOLUME
var soundTimeout = null;
$('#sound').hover(function(){

	soundTimeout = setTimeout(function() {
		$('.video-progress').fadeOut(200);
		if ($('#volume-section').is(":hidden") == true) {
			$('#volume-section').css("display", "flex").hide().fadeIn(200);
		}
	}, 200);

}, function(){

	if ( $('#volume-section').is(":hover") == false ) {
		$('#volume-section').fadeOut(200);
		$('.video-progress').css("display", "flex").hide().fadeIn(200);
	}else{
		$('#volume-section').hover(function(){}, function(){
			if ($('#sound').is(":hover") == false) {
				$('#volume-section').fadeOut(200);
				$('.video-progress').css("display", "flex").hide().fadeIn(200);
			}
		});
	}
	clearTimeout(soundTimeout);
});



// VOLUME CONTROLS
/* CHANGE VIDEO VOLUME */
$('#volume').on('input', function() {
	var volumeValue = parseInt( $(this).val() * 100);
	$(this).css("background", "linear-gradient(to right, #e50914 0%, #e50914 "+volumeValue+"%, #5b5b5b "+volumeValue+"%, #5b5b5b 100%)");

	if (video.muted) {
		video.muted = false;
	}

	video.volume = $(this).val();

});

/* CHANGE VOLUME ICON */
$('#video').on('volumechange', function() {
	if (video.muted || video.volume === 0) {
		$('#sound').addClass('nayer-hide');
		$('#mute').removeClass('nayer-hide');
	}else{
		$('#sound').removeClass('nayer-hide');
		$('#mute').addClass('nayer-hide');
	}
});


/* VOLUME ICON TOGGLE AND MUTE*/

$('.sound-mute').on('click', function() {
	if (video.muted) {
		var video_volume = parseFloat( $('#sound-control').attr('data-volume') );
		video.volume = video_volume;
		video.muted = false;
		toggleControl(this);
	}else if (video.volume === 0){
		video.volume = 1;
		$('#volume').css('background', '#e50914').val(1);
	}else{
		$('#sound-control').attr('data-volume', video.volume)
		video.muted = true;
		toggleControl(this);
	}
});


// SUBTITLES
/* SUBTITLE BUTTON ON HOVER */
$('#subtitle').hover(function(){
	setTimeout(function(){
		if ($('#subtitle-section').is(':hidden')) {
			$('.video-progress').fadeOut(200);
			$('#subtitle-section').css("display", "flex").hide().fadeIn(200);
		}
	}, 200);
}, function(){
	if ($('.sub-sec').is(":hover") || $('#subtitle-section').is(":hover")) {
		return;
	}
	$('#subtitle-section').fadeOut(200);
	$('.video-progress').css("display", "flex").hide().fadeIn(200);
});


/* SUB-SEC ON HOVER */
$('.sub-sec').hover(function(){
	// DO NOTHING
}, function(){
	if ($('#subtitle').is(":hover") || $('#subtitle-section').is(":hover")) {
		return;
	}
	$('#subtitle-section').fadeOut(200);
	$('.video-progress').css("display", "flex").hide().fadeIn(200);
});


/* SUBTITLES SECTION ON HOVER */
$('#subtitle-section').hover(function(){
	// DO NOTHING
}, function(){
	if ($('#subtitle').is(":hover") || $('.sub-sec').is(":hover")) {
		return;
	}
	$('#subtitle-section').fadeOut(200);
	$('.video-progress').css("display", "flex").hide().fadeIn(200);
});

// COMPOSE SUBTITLES SECTION
for (var i = 0; i < video.textTracks.length; i++) {
	var label = video.textTracks[i].label;
	var srclang = video.textTracks[i].language;
	var sub = `<span class="sub" srclang="${srclang}" language="${label}" texttracknum="${i}">${label}</span>`;
	$('#subs').append(sub);
}

// SELECT SUBTITLE
$('.sub').on('click', function() {

	$('#subtitle-section').fadeOut(200);
	$('.video-progress').css("display", "flex").hide().fadeIn(200);

	if ($(this).hasClass('sub-off')) {
		return;
	}

	if ( $(this).attr("srclang") == "eng") {
		$("#video").removeClass('videocue');
	}else if( $(this).attr("srclang") == "ara"){
		$("#video").addClass('videocue');
	}

	for (var i = 0; i < video.textTracks.length; i++) {
	   video.textTracks[i].mode = 'hidden';
	}
	var textTrackNum = parseInt( $(this).attr('texttracknum') );
	video.textTracks[textTrackNum].mode = 'showing';
	$('.sub').removeClass('sub-active');
	$(this).addClass('sub-active');
});

// TURN OFF ALL SUBTITLES
$('.sub-off').on('click', function() {
	for (var i = 0; i < video.textTracks.length; i++) {
	   video.textTracks[i].mode = 'hidden';
	}
});


// TOGGLE FULLSCREEN
function fullLow(){
	if (document.fullscreenElement) {
		document.exitFullscreen();
	} else {
		toggleControl('#fullscreen');
		$('#nayer')[0].requestFullscreen();
	}
}
$('.full-low').on('click', function() {
	fullLow();
});
$(document).on('fullscreenchange', function() {
	if (!document.fullscreenElement) {
		toggleControl('#lowscreen');
	}
});


// SKIP AHEAD
$('#progress-section').on('mousemove touchmove', function(event) {
	if (event.type === "mousemove") {
		var offsetX = event.offsetX;
	}else if (event.type === "touchmove") {
		var getBoundingClientRect = event.target.getBoundingClientRect();
		var offsetX = event.targetTouches[0].clientX - getBoundingClientRect.x;
	}
	var width = $(this).width();
	const duration = video.duration;
	var skipTo = Math.round(offsetX * duration / width);

	$('#progress-range').attr('skip', skipTo);

	if (skipTo <= 3599) {
		var ctime = new Date(skipTo * 1000).toISOString().substr(14, 5);
		$('#seek-tooltip').text(ctime);
	}else{
		var ctime = new Date(skipTo * 1000).toISOString().substr(11, 8);
		$('#seek-tooltip').text(ctime);
	}

	if (offsetX < 40) {
		$('#seek-tooltip').css('left', '15px');
	}else if (offsetX > (width - 42)){
		$('#seek-tooltip').css('left', (width - 65) + 'px');
	}else{
		$('#seek-tooltip').css('left', offsetX - 22);
	}

	$('#seek-tooltip').css("opacity", "1");
	
}).mouseleave(function() {
    $('#seek-tooltip').css("opacity", "0");
});
$('#progress-section').on('touchend', function() {
	$('#seek-tooltip').css("opacity", "0");
});

$('#progress-range').on('input', function() {
	var skipTo = parseInt($(this).attr('skip')) ? parseInt($(this).attr('skip')) : $(this).val();

	$('#progress-range').val(skipTo);
	$('#progress-bar').val(skipTo);

	video.currentTime = skipTo;
});


// KEYBOARD SHORTCUT
$(document).on('keyup', function(event) {
	var key = event.key;
	switch (key) {
	case ' ':
		playPause();
		break;
	case 'ArrowLeft':
		$('#rewind').click();
		break;
	case 'ArrowRight':
		$('#forward').click();
	}
});


});