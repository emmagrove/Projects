<?php

require 'getMovieID.php';
require 'getImdbID.php';

if (isset($_GET["search"])) {

	$keyword = rawurlencode($_GET["search"]);

	list($count, $dataTitle, $dataPoster, $dataLink, $getImdbID) = getMovieID($keyword);

	// COMPOSE RESULT
	$result = "";
	for ($i=0; $i < $count; $i++) { 
		$result .= '<a href="watch/index.php?m=' . $dataLink[$i] . '&i=' . $getImdbID[$i] . '"><div><img src="https://image.tmdb.org/t/p/w300/' . $dataPoster[$i] . '" alt=""></div></a>';
	}

}

?>