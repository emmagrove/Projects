<?php

function getImdbID($name){

	// CONVERT NAME TO A VALID IMDB NAME	
	$specialChars = array("?", "[", "]", "/", "\\", "=", "<", ">", ":", ";", ",", "'", "\"", "&", "$", "#", "*", "(", ")", "|", "~", "`", "!", "{", "}");

	$specialCharsFilter = str_replace($specialChars, '', $name);
	$specialCharsFilter = str_replace(' ', '_', $specialCharsFilter);

	$imdbName = strtolower($specialCharsFilter);
	$imdbFirstLetter = strtolower($specialCharsFilter[0]);


	$url = "https://v2.sg.media-imdb.com/suggestion/" . $imdbFirstLetter . "/" . $imdbName . ".json";

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	    'User-Agent: TemporaryUserAgent'//TemporaryUserAgent - explosiveskull
	));

	$result = curl_exec($ch);
	curl_close($ch);

	$jsonResult = json_decode($result, true);

	$imdbID = $jsonResult["d"][0]["id"];

	return $imdbID;
}

?>