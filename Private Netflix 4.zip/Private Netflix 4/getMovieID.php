<?php


function getMovieID($keyword){
	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, 'https://movs.to/en/quick-search?q=' . $keyword);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

	$result = curl_exec($ch);

	preg_match_all('/<a class="link-black" href=".*?">(.*?)<\/a>/', $result, $dataTitle);
	preg_match_all('/src="(.*?)"/', $result, $dataPoster);
	preg_match_all('/<a class="link-black" href="\/en\/movie\/(.*?)\//', $result, $dataLink);

	curl_close($ch);

	$count = count($dataTitle[1]);

	// GET TMDB POSTER ID - GET IMDBID
	for ($i=0; $i < $count; $i++) { 
		$dataPoster1[] = end(explode("/", $dataPoster[1][$i]));
		$getImdbID[] = getImdbID($dataTitle[1][$i]);
	}

	return array($count, $dataTitle[1], $dataPoster1, $dataLink[1], $getImdbID);
}


?>