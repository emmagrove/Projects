<?php

require 'getSearchDATA.php';

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Private Netflix</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<link href="https://fonts.googleapis.com/css2?familyfamily=Open+Sans:wght@300;400;600;700&family=Poppins:wght@300;400;500;6000&family=Cairo:wght@600&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/normalize.css">
	<script type="text/javascript" src="assets/js/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="assets/js/index.js"></script>
</head>
<body>

<img src="assets/img/logo.svg" class="logo" alt="">
<form action="" method="GET">
	<input type="text" class="search" id="search" name="search" placeholder="Search">
</form>

<div class="movies">

<?php

if ($result) {
	echo $result;
}else{
	echo '	<a href="watch/index.php?q=3695"><div>
		<img src="https://image.tmdb.org/t/p/w300/fg57nIBn2xQw8JZKIX6AzMa3pEp.jpg" alt="">
	</div></a>
	<a href="watch/index.php?q=23717"><div>
		<img src="https://image.tmdb.org/t/p/w300/7iQXgxAhn1CPVULdMnHXvnljcoy.jpg" alt="">
	</div></a>
	<a href="watch/index.php?q=12013"><div>
		<img src="https://image.tmdb.org/t/p/w300/hkjPDCe6qmPcrkinqTgv0ygcrHg.jpg" alt="">
	</div></a>
	<a href="watch/index.php?q=22047"><div>
		<img src="https://image.tmdb.org/t/p/w300/tDgxknTVwrScxpCYyGUjXSn5NRk.jpg" alt="">
	</div></a>
	<a href="watch/index.php?q=678179"><div>
		<img src="https://image.tmdb.org/t/p/w300/k1rq3uK9i01fqX6a9H1sdqJKzc8.jpg" alt="">
	</div></a>
	<a href="watch/index.php?q=1358494"><div>
		<img src="https://image.tmdb.org/t/p/w300/4SafxuMKQiw4reBiWKVZJpJn80I.jpg" alt="">
	</div></a>
	<a href="watch/index.php?q=15266"><div>
		<img src="https://image.tmdb.org/t/p/w300/qhOhIKf7QEyQ5dMrRUqs5eTX1Oq.jpg" alt="">
	</div></a>
	<a href="watch/index.php?q=302"><div>
		<img src="https://image.tmdb.org/t/p/w300/2rOonEo6b6wENhucsuoXXzoXejM.jpg" alt="">
	</div></a>';
}

?>

</div>

</body>
</html>