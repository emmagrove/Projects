// THIS VERSION IS UNCOMPLETED
// I only have to get pageID and put in the ajax request for getting subtitles

chrome.browserAction.onClicked.addListener(function (){
	chrome.tabs.executeScript(null, {file: "insert.js"});
	setTimeout(function(){
		chrome.tabs.executeScript(null, {file: "assets/js/app.js"});
	}, 5000);
});
