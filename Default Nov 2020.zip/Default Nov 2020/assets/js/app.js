$(document).ready(function(){

    
// CODE HERE...


});