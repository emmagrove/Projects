new Vue({
  el: "#app",
  data: {
    query: "",
    searchResults: [], // Ensure it's an empty array initially
    isLoading: false,
  },
  mounted() {
    this.fetchShowData(); // Fetch show data when the component is mounted
  },
  watch: {
    query(newQuery) {
      if (newQuery.trim() !== "") {
        this.isLoading = true;
        this.searchMovies(newQuery);
      } else {
        this.searchResults = [];
        this.isLoading = false;
      }
    },
  },
  methods: {
    searchMovies(query) {
      const apiKey = "e47a385fbe50d749ea94bcb4ef1e0fe9"; // Replace with your TMDB API key
      const apiUrl = `https://api.themoviedb.org/3/search/multi?api_key=${apiKey}&query=${query}`;

      fetch(apiUrl)
        .then((response) => response.json())
        .then((data) => {
          this.isLoading = false;
          this.searchResults = data.results || []; // Default to empty array if no results
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
          this.isLoading = false;
        });
    },
  },
});
