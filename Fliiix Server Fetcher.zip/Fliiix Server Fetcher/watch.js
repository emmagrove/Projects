new Vue({
  el: "#app",
  data: {
    currentSeason: 1,
    currentEpisode: 1,
    serverList: [1, 2, 3, 4],
    currentServer: 1,
    currentLink: "",
    seasons: [],
    episodes: [],
    movieData: {}, // Store movie/show data
    movieTitle: "",
    movieYear: "",
    movieBackdropUrl: "",
    tmdbId: new URLSearchParams(window.location.search).get("tmdb"),
    type: new URLSearchParams(window.location.search).get("type"), // tv or movie
    isSeries: false, // Will be true for TV series, false for movies
    showServerDropdown: false, // Toggle visibility for the server dropdown
    showSeasonDropdown: false, // Toggle visibility for the season dropdown
    // Actully playing the stream
    hasPlayed: false,
    sources: {},
  },
  created() {
    // movie or tv
    if (this.type === "movie") {
      this.fetchMovieData();
    } else if (this.type === "tv") {
      this.fetchTVShowData();
    }

    this.updateSources();
    this.updateLink();
  },
  methods: {
    // Fetch movie data
    fetchMovieData() {
      const apiKey = "e47a385fbe50d749ea94bcb4ef1e0fe9";
      const apiUrl = `https://api.themoviedb.org/3/movie/${this.tmdbId}?api_key=${apiKey}`;

      fetch(apiUrl)
        .then((response) => response.json())
        .then((data) => {
          this.movieData = data;
          this.movieTitle = data.title;
          this.movieYear = data.release_date.split("-")[0];
          this.movieBackdropUrl = `https://image.tmdb.org/t/p/original${data.backdrop_path}`;
          document.querySelector(".backdrop").classList.add("lazyload"); // Add lazyload class
          this.isSeries = false; // It's a movie, so no seasons
        })

        .catch((error) => {
          console.error("Error fetching movie data:", error);
        });
    },
    // Fetch TV show data
    fetchTVShowData() {
      const apiKey = "e47a385fbe50d749ea94bcb4ef1e0fe9";
      const apiUrl = `https://api.themoviedb.org/3/tv/${this.tmdbId}?api_key=${apiKey}`;

      fetch(apiUrl)
        .then((response) => response.json())
        .then((data) => {
          this.movieData = data;
          this.isSeries = true; // It's a TV show, so there are seasons
          this.movieTitle = data.name;
          this.movieYear = data.first_air_date.split("-")[0];
          this.movieBackdropUrl = `https://image.tmdb.org/t/p/original${data.backdrop_path}`;
          document.querySelector(".backdrop").classList.add("lazyload"); // Add lazyload class
          this.seasons = data.seasons;
          this.changeSeason(1); // Default to Season 1
        })
        .catch((error) => {
          console.error("Error fetching TV show data:", error);
        });
    },
    // Change server function
    changeServer(serverId) {
      this.currentServer = serverId;
      this.updateLink();
    },
    // Change season function
    changeSeason(seasonNumber) {
      this.currentSeason = seasonNumber;
      this.fetchEpisodes(seasonNumber);
    },
    fetchEpisodes(seasonNumber) {
      const apiKey = "e47a385fbe50d749ea94bcb4ef1e0fe9";
      const apiUrl = `https://api.themoviedb.org/3/tv/${this.tmdbId}/season/${seasonNumber}?api_key=${apiKey}`;

      fetch(apiUrl)
        .then((response) => response.json())
        .then((data) => {
          this.episodes = data.episodes;
        })
        .catch((error) => {
          console.error("Error fetching episodes data:", error);
        });
    },
    toggleServerDropdown() {
      this.showServerDropdown = !this.showServerDropdown;
    },
    toggleSeasonDropdown() {
      this.showSeasonDropdown = !this.showSeasonDropdown;
    },
    changeEpisode(episodeNumber) {
      this.currentEpisode = episodeNumber;
      this.updateSources();
      this.updateLink();
      console.log("Selected episode: " + episodeNumber);

      // Scroll to the top smoothly
      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    },
    // This function plays the movie or first episode of tv show by default
    playNow() {
      this.hasPlayed = true;
    },
    updateSources() {
      // intiazlize streams
      if (this.type === "movie") {
        this.sources = {
          sources: {
            1: `https://embed.su/embed/movie/${this.tmdbId}`,
            2: `https://moviesapi.club/movie/${this.tmdbId}`,
            3: `https://vidsrc.net/embed/movie?tmdb=${this.tmdbId}`,
            4: `https://vidsrc.cc/v2/embed/movie/${this.tmdbId}`,
          },
        };
      } else if (this.type === "tv") {
        this.sources = {
          sources: {
            1: `https://embed.su/embed/tv/${this.tmdbId}/${this.currentSeason}/${this.currentEpisode}`,
            2: `https://moviesapi.club/tv/${this.tmdbId}-${this.currentSeason}-${this.currentEpisode}`,
            3: `https://vidsrc.net/embed/tv?tmdb=${this.tmdbId}&season=${this.currentSeason}&episode=${this.currentEpisode}`,
            4: `https://vidsrc.cc/v2/embed/tv/${this.tmdbId}/${this.currentSeason}/${this.currentEpisode}`,
          },
        };
      }
    },
    updateLink() {
      this.currentLink = this.sources.sources[this.currentServer];
    },
    handleImageError(event) {
      event.target.src = "assets/px.png";
    },
  },
});
