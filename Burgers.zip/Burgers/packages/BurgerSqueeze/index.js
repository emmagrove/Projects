import './styles.scss'
import { createBurger } from '../Burger'

export default createBurger('burger-squeeze')
