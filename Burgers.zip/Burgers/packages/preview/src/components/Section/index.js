import createSimpleComponent from '../createSimpleComponent'

import cls from './Section.module.scss'

export default createSimpleComponent({
  displayName: 'Section',
  className: cls.wrapper,
})
