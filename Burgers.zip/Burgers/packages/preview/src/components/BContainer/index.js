import createSimpleComponent from '../createSimpleComponent'

import './b-container.scss'

export default createSimpleComponent({
  displayName: 'TopBar',
  className: 'b-container',
})
