import createSimpleComponent from '../createSimpleComponent'

import cls from './Content.module.scss'

export default createSimpleComponent({
  displayName: 'Content',
  className: cls.wrapper,
})
