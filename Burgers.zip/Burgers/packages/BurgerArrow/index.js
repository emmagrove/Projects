import './styles.scss'
import { createBurger } from '@animated-burgers/burger'

export default createBurger('burger-arrow')
