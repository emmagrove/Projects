# Animated Burgers

Animated burgers available in plain html/css or as React components.

Preview and documentation available at [https://march08.github.io/animated-burgers/](https://march08.github.io/animated-burgers/)
