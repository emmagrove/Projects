<?php

function getSub($query, $lang){

	$name = strtolower(rawurlencode($query));

	$url = "https://rest.opensubtitles.org/search/query-" . $name . "/sublanguageid-" . $lang;

	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	    'User-Agent: TemporaryUserAgent'//TemporaryUserAgent - explosiveskull
	));


	$result = curl_exec($ch);
	curl_close($ch);

	$json = json_decode($result, true);

	$subtitleUrl = $json[0]["SubDownloadLink"];
	$SubFormat = $json[0]["SubFormat"];

	$subtitleContent = gzdecode(file_get_contents($subtitleUrl));

	if ($SubFormat == "vtt") {
		return $subtitleContent;
	}else{
		return srt2vtt($subtitleContent);
	}

}

?>