$(document).ready(function(){


$('#search-icon').on('click', function(){
	$('form').submit();
});


});