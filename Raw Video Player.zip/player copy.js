const player = document.querySelector(".player");
const video = document.querySelector(".video");
const playPauseBtn = document.querySelector(".play-pause");
const fullscreenBtn = document.querySelector(".fullscreen-lowscreen");
const rewindBtn = document.querySelector(".rewind-btn");
const forwardBtn = document.querySelector(".forward-btn");
const currentTime = document.querySelector(".text-time-current");
const remainingTime = document.querySelector(".text-time-remaining");
const progressbar = document.querySelector(".progressbar");
const fillBar = document.querySelector(".progressbar .fillbar");
const barHandle = document.querySelector(".progressbar .barhandle");
const bufferbar = document.querySelector(".bufferbar");
const tooltip = document.querySelector(".tooltip");
const volume = document.querySelector(".volume-slider");
const volumeFillBar = document.querySelector(".volume-slider .fillbar");
const volumeBarHandle = document.querySelector(".volume-slider .barhandle");

/********** PLAY PAUSE **********/
player.addEventListener("click", (e) => {
	if (!e.target.closest(".control-btn-container") && !e.target.closest(".timeline") && !wasScrubbed) {
		togglePlay();
	}
	wasScrubbed = false;
});

playPauseBtn.addEventListener("click", togglePlay);

video.addEventListener("play", () => {
	player.classList.remove("paused");
});

video.addEventListener("pause", () => {
	player.classList.add("paused");
});

document.addEventListener("keydown", (e) => {
	if (e.code === "Space") {
		togglePlay();
	}
});

function togglePlay() {
	video.paused ? video.play() : video.pause();
	console.log("PUASE TOGGLED");
}

/********** FULLSCREEN **********/
fullscreenBtn.addEventListener("click", toggleFullScreenMode);

function toggleFullScreenMode() {
	if (document.fullscreenElement) {
		document.exitFullscreen();
	} else {
		player.requestFullscreen();
	}
}

document.addEventListener("fullscreenchange", () => {
	player.classList.toggle("fullscreen", document.fullscreenElement);
});

/********** REWIND **********/
rewindBtn.addEventListener("click", () => {
	video.currentTime -= 10;
});

document.addEventListener("keydown", (event) => {
	if (event.code === "ArrowLeft") {
		video.currentTime -= 10;
	}
});

/********** FORWARD **********/
forwardBtn.addEventListener("click", () => {
	video.currentTime += 10;
});

document.addEventListener("keydown", (event) => {
	if (event.code === "ArrowRight") {
		video.currentTime += 10;
	}
});

/********** VIDEO DURATION **********/
video.addEventListener("loadeddata", () => {
	remainingTime.textContent = formatTime(video.duration);
});

/********** CURRENT TIME && REMAINING TIME **********/
video.addEventListener("timeupdate", () => {
	currentTime.textContent = formatTime(video.currentTime);
	remainingTime.textContent = formatTime(video.duration - video.currentTime);
});

// TIME FORMAT FUNCTION
function formatTime(totalSeconds) {
	const hours = Math.floor(totalSeconds / 3600);
	const minutes = Math.floor((totalSeconds % 3600) / 60);
	const seconds = Math.floor(totalSeconds % 60);

	let formattedTime = "";

	if (hours > 0) {
		formattedTime += `${hours}:`;
		formattedTime += `${minutes.toString().padStart(2, "0")}:`;
	} else {
		formattedTime += `${minutes}:`;
	}

	formattedTime += `${seconds.toString().padStart(2, "0")}`;

	return formattedTime;
}

/********** PROGRESS BAR **********/

// TOOLTIP
progressbar.addEventListener("mousemove", handleTooltip);

function handleTooltip(event) {
	// We use event.clientX - rect.x because offsetX is relative to the target container
	// We want to get offsetX of the progress bar even when out the progress bar
	const rect = progressbar.getBoundingClientRect();
	const documentProgressbarOffsetX = Math.max(0, event.clientX - rect.x);
	const progressbarWidth = rect.width;

	const percent = Math.min(1, Math.max(0, documentProgressbarOffsetX / progressbarWidth));
	const jumpTime = percent * video.duration;

	const progressbarPercentage = percent * 100;

	tooltip.style.left = `calc(${progressbarPercentage}% - 6rem)`;
	const formattedJumpTime = formatTime(jumpTime);
	tooltip.textContent = formattedJumpTime;
}

// JUMP TO
progressbar.addEventListener("click", jumpTo);

function jumpTo(event) {
	// We use event.clientX - rect.x because offsetX is relative to the target container
	// We want to get offsetX of the progress bar even when out the progress bar
	const rect = progressbar.getBoundingClientRect();
	const documentProgressbarOffsetX = Math.max(0, event.clientX - rect.x);
	const progressbarWidth = rect.width;

	const percent = Math.min(1, Math.max(0, documentProgressbarOffsetX / progressbarWidth));
	const jumpTime = percent * video.duration;

	video.currentTime = jumpTime;
}

// FILL BAR AND BAR HANDLE
video.addEventListener("timeupdate", (event) => {
	const progressbarPercentage = (video.currentTime / video.duration) * 100;

	fillBar.style.width = `${progressbarPercentage}%`;
	barHandle.style.left = `${progressbarPercentage}%`;
});

// BUFFER BAR
video.addEventListener("progress", buffer);
video.addEventListener("timeupdate", buffer);

function buffer() {
	// The problem arises when we jump forward then backward into the video
	// video.buffered.end(video.buffered.length - 1) will be the last buffered second
	// To solve this is to get the buffered range that we are currently on
	// We loop from the end to get the buffer that start from less than currentTime
	for (let i = 0; i < video.buffered.length; i++) {
		if (video.buffered.start(video.buffered.length - 1 - i) <= video.currentTime) {
			const bufferedEnd = video.buffered.end(video.buffered.length - 1 - i);
			const duration = video.duration;
			bufferbar.style.width = `${(bufferedEnd / duration) * 100}%`;
			break;
		}
	}
}

// Scrubbing

// I am using mousedown / mousemove / mouseup
// To check if Scrubbing starts only from the progressbar
// And stays valid throughout the document

let isScrubbing = false;
let wasScrubbed;
let wasPaused;

progressbar.addEventListener("mousedown", function (event) {
	isScrubbing = true;
	wasScrubbed = true;
	wasPaused = video.paused;
	tooltip.classList.add("show-tooltip");
});

document.addEventListener("mousemove", function (event) {
	if (isScrubbing) {
		video.pause();
		handleProgressbar(event);
		handleTooltip(event);
		// console.log("SCRUBBING");
	}
});

document.addEventListener("mouseup", function (event) {
	if (isScrubbing) {
		jumpTo(event);
		!wasPaused && video.play();
		tooltip.classList.remove("show-tooltip");
		fillBar.classList.remove("transition");
		barHandle.classList.remove("transition");
		barHandle.classList.remove("scale");
		barHandle.classList.remove("opacity");
	}
	isScrubbing = false;
});

// HANDLE PROGRESS FILL BAR AND BAR HANDLE WHEN SCRUBBING

function handleProgressbar(event) {
	// We use event.clientX - rect.x because offsetX is relative to the target container
	// We want to get offsetX of the progress bar even when out the progress bar
	const rect = progressbar.getBoundingClientRect();
	const documentProgressbarOffsetX = Math.max(0, event.clientX - rect.x);
	const progressbarWidth = rect.width;

	const percent = Math.min(100, Math.max(0, documentProgressbarOffsetX / progressbarWidth) * 100);

	fillBar.classList.add("transition");
	barHandle.classList.add("scale");
	barHandle.classList.add("transition");
	barHandle.classList.add("opacity");

	fillBar.style.width = `${percent}%`;
	barHandle.style.left = `${percent}%`;
}

// VOLUME
volume.addEventListener("mousemove", (event) => {
	isVolumeScrubbing = event.buttons & 1;
	if (isVolumeScrubbing) {
		const position = Math.min(100, Math.max(0, (event.offsetY / volume.clientHeight) * 100));
		volumeFillBar.style.height = `${position}%`;
		volumeBarHandle.style.top = `calc(${position}% - 2rem)`;
		video.volume = position / 100;
	}
});
