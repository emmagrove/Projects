<?php

header('Content-Type: application/json');

echo '{"imdbID":"tt1217209","title":"Brave","year":"2012","rate":"7.1","views":"370616","releaseDate":"2012-06-19","overview":"Determined to make her own path in life, Princess Merida (Kelly Macdonald) defies a custom that brings chaos to her kingdom. Granted one wish, Merida must rely on her bravery and her archery skills to undo a beastly curse.","genre":["animation","adventure","comedy","family","sff"],"poster":"\/L6qqU6Q3k4MmPojncNbT43FSTL.jpg","backdrop":"\/qx9ts2hBYJrkIQxhryitxnLlm2u.jpg","trailer":"TEHWDA_6e3M","tceng":3,"tcara":3,"videoID":"3695"}';

?>