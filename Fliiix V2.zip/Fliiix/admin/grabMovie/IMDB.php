<?php


class Imdb {

	public $find;
	public $imdbID;
	public $result;

	CONST TITLE 	= '/"name": "(.*?)"/';
	CONST YEAR 		= '/"datePublished": "(.*?)"/';
	CONST RATE 		= '/"ratingValue": "(.*?)"/';
	CONST VIEWS 	= '/"ratingCount": (.*?),/';
	CONST POSTER 	= '/"image": "(.*?)"/';
	CONST OVERVIEW 	= '/<div class="summary_text">(.*?)<\/div>/s';
	CONST GENRE 	= '/"genre": \[(.*?)\]/s';

	function __construct($find){

		$this->find = $find;

		if (preg_match('/^tt\d{5,7}$/', $find)) {
			$this->imdbID = $find;
		}else{
			$this->imdbID = $this->getImdbID();
		}

		$this->result = $this->getResult();

	}


	// GET IMDBID
	public function getImdbID(){
		// CONVERT NAME TO A VALID IMDB NAME	
		$specialChars = array("?", "[", "]", "/", "\\", "=", "<", ">", ":", ";", ",", "'", "\"", "&", "$", "#", "*", "(", ")", "|", "~", "`", "!", "{", "}");

		$specialCharsFilter = str_replace($specialChars, '', $this->find);
		$specialCharsFilter = str_replace(' ', '_', $specialCharsFilter);

		$imdbName = strtolower($specialCharsFilter);
		$imdbFirstLetter = strtolower($specialCharsFilter[0]);


		$url = "https://v2.sg.media-imdb.com/suggestion/" . $imdbFirstLetter . "/" . $imdbName . ".json";

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

		$result = curl_exec($ch);
		curl_close($ch);

		$jsonResult = json_decode($result, true);

		return $jsonResult["d"][0]["id"];
	}


	// GET RESULT FROM IMDB
	public function getResult(){
		$url = "https://www.imdb.com/title/" . $this->imdbID . "/";

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

		$result = curl_exec($ch);
		curl_close($ch);

		return $result;
	}


	// GET IMDBID
	public function getID(){
		return $this->imdbID;
	}

	// GET TITLE
	public function getTitle(){
		preg_match(self::TITLE, $this->result, $title);
		return $title[1];
	}

	// GET YEAR
	public function getYear(){
		preg_match(self::YEAR, $this->result, $year);
		return substr($year[1], 0, 4);
	}

	// GET RATE
	public function getRate(){
		preg_match(self::RATE, $this->result, $rate);
		return $rate[1];
	}

	// GET VIEWS
	public function getViews(){
		preg_match(self::VIEWS, $this->result, $views);
		return $views[1];
	}

	// GET POSTER
	public function getPoster(){
		preg_match(self::POSTER, $this->result, $poster);
		return $poster[1];
	}

	// GET REALEASE DATE
	public function getReleaseDate(){
		preg_match(self::YEAR, $this->result, $releaseDate);
		return $releaseDate[1];
	}


	// GET OVERVIEW
	public function getOverview(){
		preg_match(self::OVERVIEW, $this->result, $overview);
		return trim($overview[1]);
	}

	// GET GENRE
	public function getGenre(){
		preg_match(self::GENRE, $this->result, $genre);
		//REMOVE " FROM THE GENRES
		$genres = str_replace('"', '', $genre[1]);
		// EXPLODE GENRES WITH , DELIMITER
		$genres = explode(',', $genres);
		// TRIM GENRES ARRAY
		$genres = array_map('trim', $genres);

		$imdbGenres = array("animation" => "anime", "Sci-Fi" => "sff", "Fantasy" => "sff");
		// LOOP THROUGH GENRES AND CHANGE THE IMDBGENRES KEY TO IMDBGENRES VALUE IN GENRES
		foreach ($genres as $genre) {
		    if (array_key_exists($genre, $imdbGenres)) {
		        $finalGenres[] = strtolower($imdbGenres[$genre]);
		    }else{
		    	$finalGenres[] = strtolower($genre);
		    }
		}

		return $finalGenres;
	}

}


?>