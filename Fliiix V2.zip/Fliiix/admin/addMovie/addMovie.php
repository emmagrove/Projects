<?php


if (isset($_POST["addMovie"])) {
	

// PREPARE VARIABLES
$title 			= ucfirst(strtolower(filter_var($_POST["title"], FILTER_SANITIZE_STRING)));
$year 			= filter_var($_POST["year"], FILTER_SANITIZE_NUMBER_INT);
$rate 			= filter_var($_POST["rate"], FILTER_SANITIZE_STRING, FILTER_FLAG_ALLOW_FRACTION);
$views 			= filter_var($_POST["views"], FILTER_SANITIZE_NUMBER_INT);
$poster 		= filter_var($_POST["poster"], FILTER_SANITIZE_STRING);
$backdrop 		= filter_var($_POST["backdrop"], FILTER_SANITIZE_STRING);
$releaseDate	= filter_var($_POST["releaseDate"], FILTER_SANITIZE_STRING);
$trailer 		= filter_var($_POST["trailer"], FILTER_SANITIZE_STRING);
$video 			= filter_var($_POST["video"], FILTER_SANITIZE_STRING);
$overview 		= ucfirst(strtolower(filter_var($_POST["overview"], FILTER_SANITIZE_STRING)));
$tceng 			= filter_var($_POST["tceng"], FILTER_SANITIZE_NUMBER_INT);
$tcara 			= filter_var($_POST["tcara"], FILTER_SANITIZE_NUMBER_INT);
$genres 		= explode(",", strtolower(filter_var($_POST["genres"], FILTER_SANITIZE_STRING)));



}



?>