
// EXTRACT JSON DATA FROM THE SHOPPING CART
var obj = new Array();
$('[data-test="cartItem"]').each(function () {

	var arr = new Array();

	var itemUrl = $(this).find('a[data-test="cartItem-title-url"]').attr("href");
	var itemName = encodeURIComponent($(this).find('div[data-test="cartItem-title"]').text().replace(/"/g, ""));
	var itemPrice = $(this).find('[data-test="cartItem-price"]').eq(1).text().substring(1);
	var itemUnitPrice = $(this).find('[data-test="cartItem-unitPrice"]').eq(1).text().substring(6);
	// QUANTITY CHECK
	if (itemUnitPrice == "") {
		itemQuantity = 1;
	}else{
		// itemUnitPrice = itemUnitPrice // JUST FOR CLARIFICATION
		itemQuantity = Math.round(itemPrice / itemUnitPrice);
		itemPrice = itemUnitPrice;
	}
	// PUSH DATA INTO OBJECT
	arr.push(itemUrl);
	arr.push(itemName);
	arr.push(itemPrice);
	arr.push(itemQuantity);
	obj.push(arr)


})
var data = JSON.stringify(obj);

console.log(data); // I MIGHT NEED IT

window.open("http://receiptme.ml/index.php?data=" + data, '_blank');